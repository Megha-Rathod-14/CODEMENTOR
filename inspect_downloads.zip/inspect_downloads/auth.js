/**
 * CodeMentor AI - Authentication & Role Controller
 * Accounts:
 * 1. Admin Side: megha@1409 / 123456 (Role: admin)
 * 2. User Side: darshan@123 / 456789 (Role: student)
 * 3. User Side: Megha@143 / 123456 (Role: student)
 */

const DEFAULT_ACCOUNTS = [
  {
    username: "megha@1409",
    password: "123456",
    name: "Megha (Admin)",
    role: "admin",
    plan: "👑 Administrator",
    avatarLetter: "MA",
    currentCourse: "System Administration",
    level: "Master",
    problemsSolved: 65,
    streak: 14,
    status: "online"
  },
  {
    username: "darshan@123",
    password: "456789",
    name: "Darshan Patel",
    role: "student",
    plan: "student plan",
    avatarLetter: "DP",
    currentCourse: "Python Programming Mastery",
    level: "Level 1: Basics",
    problemsSolved: 18,
    streak: 5,
    status: "online"
  },
  {
    username: "Megha@143",
    password: "123456",
    name: "Megha Sharma",
    role: "student",
    plan: "student plan",
    avatarLetter: "MR",
    currentCourse: "SQL & Database Engineering",
    level: "Level 2: Intermediate",
    problemsSolved: 42,
    streak: 7,
    status: "active"
  },
  {
    username: "rohit@code",
    password: "password123",
    name: "Rohit Verma",
    role: "student",
    plan: "student plan",
    avatarLetter: "RV",
    currentCourse: "Data Structures & Algorithms",
    level: "Level 1: Basics",
    problemsSolved: 9,
    streak: 3,
    status: "offline"
  },
  {
    username: "ananya@tech",
    password: "password123",
    name: "Ananya Rao",
    role: "student",
    plan: "student plan",
    avatarLetter: "AR",
    currentCourse: "JavaScript & Modern Web",
    level: "Level 2: Intermediate",
    problemsSolved: 24,
    streak: 6,
    status: "active"
  }
];

// Initialize Users in LocalStorage
function initAuthStore() {
  const users = getStoredUsers();
  DEFAULT_ACCOUNTS.forEach(acc => {
    const existing = users.find(u => u.username.toLowerCase() === acc.username.toLowerCase());
    if (!existing) {
      users.push(acc);
    } else {
      // Ensure requested credentials are fully synced
      if (acc.username.toLowerCase() === "darshan@123") {
        existing.password = "456789";
        existing.role = "student";
        existing.name = "Darshan Patel";
      } else if (acc.username.toLowerCase() === "megha@1409") {
        existing.password = "123456";
        existing.role = "admin";
        existing.name = "Megha (Admin)";
      }
    }
  });
  localStorage.setItem("codementor_users", JSON.stringify(users));

  // Initialize seed activity logs for Admin view if not present
  if (!localStorage.getItem("codementor_activity_logs")) {
    const seedLogs = [
      {
        id: "log_" + Date.now() + "_1",
        username: "darshan@123",
        role: "student",
        action: "Solved Practice Challenge",
        detail: "Two Sum in Python — Score 95/100",
        timestamp: "Just now",
        type: "practice"
      },
      {
        id: "log_" + Date.now() + "_2",
        username: "darshan@123",
        role: "student",
        action: "Started Level 1 Course",
        detail: "Python Basics: Variables & Data Types",
        timestamp: "12 mins ago",
        type: "course"
      },
      {
        id: "log_" + Date.now() + "_3",
        username: "Megha@143",
        role: "student",
        action: "Tested Code in Debug Compiler",
        detail: "SQL Window Functions query executed",
        timestamp: "35 mins ago",
        type: "compiler"
      },
      {
        id: "log_" + Date.now() + "_4",
        username: "ananya@tech",
        role: "student",
        action: "Completed Focus Session",
        detail: "25 mins Pomodoro Study Block on JS Async",
        timestamp: "1 hour ago",
        type: "focus"
      },
      {
        id: "log_" + Date.now() + "_5",
        username: "rohit@code",
        role: "student",
        action: "Enrolled in Course",
        detail: "Data Structures & Algorithms Track",
        timestamp: "3 hours ago",
        type: "course"
      }
    ];
    localStorage.setItem("codementor_activity_logs", JSON.stringify(seedLogs));
  }
}

function getStoredUsers() {
  try {
    const raw = localStorage.getItem("codementor_users");
    return raw ? JSON.parse(raw) : DEFAULT_ACCOUNTS;
  } catch (e) {
    return DEFAULT_ACCOUNTS;
  }
}

function getCurrentUser() {
  try {
    const raw = localStorage.getItem("codementor_active_user");
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function setCurrentUser(user) {
  if (user) {
    localStorage.setItem("codementor_active_user", JSON.stringify(user));
  } else {
    localStorage.removeItem("codementor_active_user");
  }
}

// Log activity for Admin Dashboard monitoring
function recordUserActivity(action, detail, type = "general") {
  const user = getCurrentUser();
  const username = user ? user.username : "guest";
  const role = user ? user.role : "student";
  
  try {
    const logs = JSON.parse(localStorage.getItem("codementor_activity_logs") || "[]");
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    logs.unshift({
      id: "log_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
      username,
      role,
      action,
      detail,
      timestamp: timeStr,
      type
    });
    
    // Keep last 100 logs
    if (logs.length > 100) logs.pop();
    localStorage.setItem("codementor_activity_logs", JSON.stringify(logs));
  } catch (e) {
    console.warn("Could not save activity log", e);
  }
}

// Switch between User Login and Admin Login panels (Simple & Clean)
function switchLoginSide(side) {
  const studentTab = document.getElementById("tab-student-btn");
  const adminTab = document.getElementById("tab-admin-btn");
  const studentPanel = document.getElementById("auth-panel-student");
  const adminPanel = document.getElementById("auth-panel-admin");

  if (side === "student") {
    if (studentTab) studentTab.classList.add("active");
    if (adminTab) adminTab.classList.remove("active");
    if (studentPanel) studentPanel.classList.remove("hidden");
    if (adminPanel) adminPanel.classList.add("hidden");
  } else {
    if (adminTab) adminTab.classList.add("active");
    if (studentTab) studentTab.classList.remove("active");
    if (adminPanel) adminPanel.classList.remove("hidden");
    if (studentPanel) studentPanel.classList.add("hidden");
  }
}

// Switch between Sign In and Sign Up tabs
function switchAuthTab(tab) {
  const loginBtn = document.getElementById("tab-login-btn");
  const signupBtn = document.getElementById("tab-signup-btn");
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");

  if (tab === "login") {
    if (loginBtn) loginBtn.classList.add("active");
    if (signupBtn) signupBtn.classList.remove("active");
    if (loginForm) loginForm.classList.remove("hidden");
    if (signupForm) signupForm.classList.add("hidden");
  } else {
    if (signupBtn) signupBtn.classList.add("active");
    if (loginBtn) loginBtn.classList.remove("active");
    if (signupForm) signupForm.classList.remove("hidden");
    if (loginForm) loginForm.classList.add("hidden");
  }
}

// Quick Enter for Admin (megha@1409) - without showing password text
function fillAdminCredentials() {
  const adminUser = document.getElementById("login-admin-username") || document.getElementById("login-username");
  const adminPass = document.getElementById("login-admin-password") || document.getElementById("login-password");
  
  if (adminUser) adminUser.value = "megha@1409";
  if (adminPass) adminPass.value = "123456";
  
  showToast("Logging in as Administrator...", "info");
  
  setTimeout(() => {
    const adminForm = document.getElementById("login-form-admin") || document.getElementById("login-form");
    if (adminForm) {
      adminForm.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
    }
  }, 150);
}

// Quick Enter for User / Student (darshan@123) - without showing password text
function fillStudentCredentials() {
  const studentUser = document.getElementById("login-student-username") || document.getElementById("login-username");
  const studentPass = document.getElementById("login-student-password") || document.getElementById("login-password");
  
  if (studentUser) studentUser.value = "darshan@123";
  if (studentPass) studentPass.value = "456789";
  
  showToast("Logging in as User...", "info");
  
  setTimeout(() => {
    const studentForm = document.getElementById("login-form-student") || document.getElementById("login-form");
    if (studentForm) {
      studentForm.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
    }
  }, 150);
}

// Legacy demo quick login
function fillDemoCredentials() {
  const studentUser = document.getElementById("login-student-username") || document.getElementById("login-username");
  const studentPass = document.getElementById("login-student-password") || document.getElementById("login-password");
  
  if (studentUser) studentUser.value = "Megha@143";
  if (studentPass) studentPass.value = "123456";
  
  showToast("Logging in...", "info");
  
  setTimeout(() => {
    const studentForm = document.getElementById("login-form-student") || document.getElementById("login-form");
    if (studentForm) {
      studentForm.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
    }
  }, 150);
}

// Toggle password visibility
function togglePasswordVisibility(inputId) {
  const input = document.getElementById(inputId);
  const eye = document.getElementById(inputId + "-eye");
  if (!input) return;

  if (input.type === "password") {
    input.type = "text";
    if (eye) {
      eye.classList.remove("fa-eye");
      eye.classList.add("fa-eye-slash");
    }
  } else {
    input.type = "password";
    if (eye) {
      eye.classList.remove("fa-eye-slash");
      eye.classList.add("fa-eye");
    }
  }
}

// Dedicated Student Login Handler (darshan@123 / 456789)
function handleStudentLogin(event) {
  event.preventDefault();
  const userInput = document.getElementById("login-student-username") || document.getElementById("login-username");
  const passInput = document.getElementById("login-student-password") || document.getElementById("login-password");
  let usernameVal = userInput ? userInput.value.trim() : "";
  let passwordVal = passInput ? passInput.value : "";

  // If username is darshan@123 and password was empty on submit, use default password
  if (usernameVal.toLowerCase() === "darshan@123" && !passwordVal) {
    passwordVal = "456789";
    if (passInput) passInput.value = "456789";
  }

  const users = getStoredUsers();
  const matchedUser = users.find(u => 
    u.username.toLowerCase() === usernameVal.toLowerCase() && u.password === passwordVal
  );

  if (matchedUser) {
    setCurrentUser(matchedUser);
    recordUserActivity("Student Logged In", `${matchedUser.username} accessed Learner Portal`, "auth");
    showToast(`Signed in successfully! Welcome, ${matchedUser.name}!`, "success");
    transitionToApp(matchedUser);
  } else {
    showToast("Invalid credentials. Please check your username and password.", "error");
  }
}

// Dedicated Admin Login Handler (megha@1409 / 123456)
function handleAdminLogin(event) {
  event.preventDefault();
  const userInput = document.getElementById("login-admin-username") || document.getElementById("login-username");
  const passInput = document.getElementById("login-admin-password") || document.getElementById("login-password");
  let usernameVal = userInput ? userInput.value.trim() : "";
  let passwordVal = passInput ? passInput.value : "";

  // If username is megha@1409 and password was empty on submit, use default password
  if (usernameVal.toLowerCase() === "megha@1409" && !passwordVal) {
    passwordVal = "123456";
    if (passInput) passInput.value = "123456";
  }

  const users = getStoredUsers();
  const matchedUser = users.find(u => 
    u.username.toLowerCase() === usernameVal.toLowerCase() && u.password === passwordVal
  );

  if (matchedUser) {
    if (matchedUser.role !== "admin") {
      showToast("Access restricted: This account does not have Administrator privileges.", "error");
      return;
    }
    setCurrentUser(matchedUser);
    recordUserActivity("Admin Logged In", `${matchedUser.username} accessed Admin Control Center`, "auth");
    showToast(`👑 Welcome Administrator ${matchedUser.name}! Opening Admin Hub...`, "success");
    transitionToApp(matchedUser);
  } else {
    showToast("Invalid admin credentials. Please check your admin username and password.", "error");
  }
}

// Universal Sign In submission fallback
function handleLogin(event) {
  event.preventDefault();
  const usernameVal = (document.getElementById("login-username") || {}).value?.trim() || "";
  const passwordVal = (document.getElementById("login-password") || {}).value || "";

  const users = getStoredUsers();
  const matchedUser = users.find(u => 
    u.username.toLowerCase() === usernameVal.toLowerCase() && u.password === passwordVal
  );

  if (matchedUser) {
    setCurrentUser(matchedUser);
    recordUserActivity("User Logged In", `${matchedUser.username} accessed ${matchedUser.role === 'admin' ? 'Admin Center' : 'Learner Portal'}`, "auth");
    
    if (matchedUser.role === "admin") {
      showToast(`👑 Welcome Administrator ${matchedUser.name}!`, "success");
    } else {
      showToast(`Signed in successfully! Welcome back, ${matchedUser.name}!`, "success");
    }
    
    transitionToApp(matchedUser);
  } else {
    showToast("Invalid credentials. Please verify your username and password.", "error");
  }
}

// Handle Sign Up submission
function handleSignup(event) {
  event.preventDefault();
  const nameVal = document.getElementById("signup-name").value.trim();
  const usernameVal = document.getElementById("signup-username").value.trim();
  const passwordVal = document.getElementById("signup-password").value;
  const confirmPasswordVal = document.getElementById("signup-confirm-password").value;

  if (passwordVal !== confirmPasswordVal) {
    showToast("Passwords do not match!", "error");
    return;
  }

  if (passwordVal.length < 4) {
    showToast("Password must be at least 4 characters", "error");
    return;
  }

  const users = getStoredUsers();
  if (users.some(u => u.username.toLowerCase() === usernameVal.toLowerCase())) {
    showToast("This username already exists. Please sign in.", "error");
    switchAuthTab("login");
    const stuInput = document.getElementById("login-student-username") || document.getElementById("login-username");
    if (stuInput) stuInput.value = usernameVal;
    return;
  }

  const initials = nameVal ? nameVal.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2) : "ST";
  const newUser = {
    username: usernameVal,
    password: passwordVal,
    name: nameVal || usernameVal,
    role: "student",
    plan: "student plan",
    avatarLetter: initials || "ST",
    currentCourse: "Python Programming Mastery",
    level: "Level 1: Basics",
    problemsSolved: 0,
    streak: 1,
    status: "online"
  };

  users.push(newUser);
  localStorage.setItem("codementor_users", JSON.stringify(users));
  setCurrentUser(newUser);

  recordUserActivity("New Student Registered", `${newUser.username} created account`, "auth");
  showToast(`Account created! Welcome ${newUser.name}!`, "success");
  transitionToApp(newUser);
}

// Transition from Login into CodeMentor AI
function transitionToApp(user) {
  const authScreen = document.getElementById("auth-screen");
  const appContainer = document.getElementById("app-container");

  if (authScreen && appContainer) {
    authScreen.classList.add("hidden");
    appContainer.classList.remove("hidden");
  }

  updateUserDisplay(user);

  if (typeof initChatbotApp === "function") {
    initChatbotApp();
  }

  // Role-based UI visibility:
  const adminGroupTitle = document.getElementById("admin-group-title");
  const adminNavGroup = document.getElementById("admin-nav-group");
  if (user && user.role === "admin") {
    if (adminGroupTitle) adminGroupTitle.classList.remove("hidden");
    if (adminNavGroup) adminNavGroup.classList.remove("hidden");
  } else {
    if (adminGroupTitle) adminGroupTitle.classList.add("hidden");
    if (adminNavGroup) adminNavGroup.classList.add("hidden");
  }

  routeInitialView(user);
}

function routeInitialView(user) {
  const path = window.location.pathname.toLowerCase().replace(/\/$/, "");
  if (path === "/explain-concept") {
    if (typeof switchView === "function") switchView("explain", false);
  } else if (path === "/debug-code") {
    if (typeof switchView === "function") switchView("debug", false);
  } else if (path === "/learn-example") {
    if (typeof switchView === "function") switchView("example", false);
  } else if (path === "/practice") {
    if (typeof switchView === "function") switchView("practice", false);
  } else if (path === "/courses") {
    if (typeof switchView === "function") switchView("courses", false);
  } else if (path === "/progress") {
    if (typeof switchView === "function") switchView("progress", false);
  } else if (path === "/library") {
    if (typeof switchView === "function") switchView("library", false);
  } else if (path === "/scheduled") {
    if (typeof switchView === "function") switchView("scheduled", false);
  } else if (path === "/admin") {
    if (user && user.role === "admin") {
      if (typeof switchView === "function") switchView("admin", false);
    } else {
      if (typeof switchView === "function") switchView("chat", false);
    }
  } else if (path === "/dashboard" || path === "/user-dashboard") {
    if (typeof switchView === "function") switchView("user-dashboard", false);
  } else {
    if (user && user.role === "admin") {
      if (typeof switchView === "function") switchView("admin", false);
    } else {
      if (typeof switchView === "function") switchView("chat", false);
    }
  }
}

function showAuthScreen() {
  const authScreen = document.getElementById("auth-screen");
  if (authScreen) {
    authScreen.classList.remove("hidden");
  }
}

function hideAuthScreen() {
  const authScreen = document.getElementById("auth-screen");
  if (authScreen) {
    authScreen.classList.add("hidden");
  }
}

function updateUserDisplay(user) {
  if (!user) return;
  
  // Update avatar pills
  document.querySelectorAll(".user-avatar-pill").forEach(el => {
    el.textContent = user.avatarLetter || "MR";
    el.title = `Logged in as ${user.name} (${user.username}) [${user.role.toUpperCase()}]`;
  });

  // Update plan badges
  document.querySelectorAll(".plan-badge").forEach(badge => {
    if (user.role === "admin") {
      badge.textContent = "👑 Administrator";
      badge.classList.add("admin-badge-gold");
    } else {
      badge.textContent = user.plan || "student plan";
      badge.classList.remove("admin-badge-gold");
    }
  });

  // Update top subtitle date/role
  const dateSub = document.getElementById("top-date-subtitle");
  if (dateSub) {
    if (user.role === "admin") {
      dateSub.textContent = "ADMIN PORTAL • SYSTEM MANAGEMENT & USER ACTIVITY";
    } else {
      dateSub.textContent = `AI WORKSPACE • ${user.name.toUpperCase()} (${user.username})`;
    }
  }

  // Keep chat input placeholder exactly as shown in screenshot
  const chatInput = document.getElementById("chat-input");
  if (chatInput) {
    chatInput.placeholder = "Message your friendly coding tutor...";
  }
}

function handleLogout() {
  const user = getCurrentUser();
  const name = user ? user.name : "User";
  if (confirm(`Sign out of ${name}?`)) {
    if (user) {
      recordUserActivity("User Logged Out", `${user.username} signed out`, "auth");
    }
    setCurrentUser(null);
    const authScreen = document.getElementById("auth-screen");
    const appContainer = document.getElementById("app-container");

    if (authScreen && appContainer) {
      appContainer.classList.add("hidden");
      authScreen.classList.remove("hidden");
    }

    const pw = document.getElementById("login-password");
    if (pw) pw.value = "";
    const stuPw = document.getElementById("login-student-password");
    if (stuPw) stuPw.value = "";
    const admPw = document.getElementById("login-admin-password");
    if (admPw) admPw.value = "";

    showToast("Signed out. Please sign in to continue.", "info");
  }
}

// Toast Notification
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;

  let icon = "fa-circle-info";
  if (type === "success") icon = "fa-circle-check";
  if (type === "error") icon = "fa-circle-exclamation";

  toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// On page load
document.addEventListener("DOMContentLoaded", () => {
  initAuthStore();
  let user = getCurrentUser();
  if (!user) {
    // Default to student demo user so all features are immediately active
    user = DEFAULT_ACCOUNTS[1];
    setCurrentUser(user);
  }
  transitionToApp(user);
});
