"""
SQLite Database Initializer for CodeMentor AI
Executes schema.sql to create codementor.db
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "codementor.db")
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.sql")

def build_database():
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
            print(f"Removed old {DB_PATH} to apply schema updates.")
        except Exception as e:
            print(f"Notice: could not remove old db file: {e}")

    print(f"Connecting to {DB_PATH}...")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    if os.path.exists(SCHEMA_PATH):
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            sql_script = f.read()
        cursor.executescript(sql_script)
        conn.commit()
        print("Database codementor.db created and seeded successfully!")
    else:
        print("Error: schema.sql not found!")

    # Verify seed data
    cursor.execute("SELECT username, role, plan FROM users;")
    users = cursor.fetchall()
    print("Verified accounts in database:")
    for u in users:
        print(f" - User: {u[0]} | Role: {u[1]} | Plan: {u[2]}")

    cursor.execute("SELECT COUNT(*) FROM search_history;")
    count = cursor.fetchone()[0]
    print(f"Total initial search history records: {count}")

    conn.close()

if __name__ == "__main__":
    build_database()
