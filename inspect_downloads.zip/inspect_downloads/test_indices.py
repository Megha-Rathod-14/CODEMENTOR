with open('server.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, l in enumerate(lines):
    if 'parsed.path == "/api/chat":' in l:
        print('Chat route start line:', i)
    if 'parsed.path == "/api/explain":' in l:
        print('Explain route start line:', i)
