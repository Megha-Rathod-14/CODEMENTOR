# -*- coding: utf-8 -*-
"""
Friendly Coding Tutor - Comprehensive Test Suite
Validates all 12 Required Test Cases and Specialized Workspaces against the live server.
"""

import sys
import json
import urllib.request
import urllib.error

# Ensure UTF-8 output
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

BASE_URL = "http://localhost:5000"

def post_json(endpoint, payload):
    url = f"{BASE_URL}{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=35) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, {"error": body}
    except Exception as e:
        return 0, {"error": str(e)}

def run_tests():
    print("=" * 70)
    print("  FRIENDLY CODING TUTOR - AUTOMATED MASTER VERIFICATION TEST SUITE")
    print("=" * 70)

    results = []

    # --------------------------------------------------------------------------
    # TEST 1: Greeting
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Hello, how are you?",
        "language": "Python",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_code = "```" in reply or "def " in reply or "Python Solution" in reply
    passed = status == 200 and any(g in reply.lower() for g in ("hello", "hey", "hi", "how are you", "how about you", "wonderful", "doing", "good")) and not has_code
    results.append(("TEST 1 — Greeting", passed, f"Status: {status}, Has Code: {has_code}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 2: General Knowledge ("Who is Narendra Modi?")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Who is Narendra Modi?",
        "language": "Python",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_code = "```" in reply or "def who" in reply or "def solve" in reply or "Python Solution:" in reply
    has_narendra = "narendra" in reply.lower() and ("prime minister" in reply.lower() or "modi" in reply.lower() or "politician" in reply.lower())
    passed = status == 200 and has_narendra and not has_code
    results.append(("TEST 2 — General Knowledge (Narendra Modi)", passed, f"Status: {status}, Has Code: {has_code}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 3: General Education ("Explain photosynthesis in simple words.")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Explain photosynthesis in simple words.",
        "language": "Python",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_code = "```python" in reply or "def solve" in reply or "def process_data" in reply
    has_concept = "photosynthesis" in reply.lower() and ("glucose" in reply.lower() or "light" in reply.lower() or "plant" in reply.lower() or "sunlight" in reply.lower())
    passed = status == 200 and has_concept and not has_code
    results.append(("TEST 3 — General Education (Photosynthesis)", passed, f"Status: {status}, Has Code: {has_code}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 4: Writing Assistance ("Write a leave application to my professor.")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Write a leave application to my professor.",
        "language": "Python",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_letter = "leave" in reply.lower() and ("subject" in reply.lower() or "sincerely" in reply.lower() or "respected" in reply.lower() or "professor" in reply.lower())
    has_code = "```" in reply
    passed = status == 200 and has_letter and not has_code
    results.append(("TEST 4 — Writing (Leave Application)", passed, f"Status: {status}, Has Letter: {has_letter}, Has Code: {has_code}"))

    # --------------------------------------------------------------------------
    # TEST 5: Programming Concept ("Explain inheritance in Java.")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Explain inheritance in Java.",
        "language": "Java",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_java_code = "```java" in reply or "class " in reply or "extends" in reply or "super" in reply
    has_explanation = "inheritance" in reply.lower() and ("superclass" in reply.lower() or "subclass" in reply.lower() or "parent" in reply.lower() or "child" in reply.lower())
    passed = status == 200 and has_explanation and has_java_code
    results.append(("TEST 5 — Programming Concept (Java Inheritance)", passed, f"Status: {status}, Has Java Code: {has_java_code}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 6: Code Generation ("Write a Java program to reverse a string.")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Write a Java program to reverse a string.",
        "language": "Java",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_java = ("```java" in reply or "public class" in reply) and ("reverse" in reply.lower() or "stringbuilder" in reply.lower() or "char" in reply.lower())
    passed = status == 200 and has_java
    results.append(("TEST 6 — Code Generation (Java String Reversal)", passed, f"Status: {status}, Has Java Code: {has_java}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 7: Code Debugging ("Debug this Python code: print(10 / 0)")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Debug this Python code: print(10 / 0)",
        "language": "Python",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_zerodiv = "zero" in reply.lower() and ("division" in reply.lower() or "zerodivisionerror" in reply.lower() or "divide" in reply.lower())
    has_fix = "try" in reply.lower() or "except" in reply.lower() or "guard" in reply.lower() or "!= 0" in reply
    passed = status == 200 and has_zerodiv and has_fix
    results.append(("TEST 7 — Debugging (Python ZeroDivisionError)", passed, f"Status: {status}, Diagnosis: {has_zerodiv}, Fix Provided: {has_fix}"))

    # --------------------------------------------------------------------------
    # TEST 8: Follow-Up ("Give me another example." following Java inheritance)
    # --------------------------------------------------------------------------
    history_turn = [
        {"role": "user", "content": "Explain inheritance in Java."},
        {"role": "assistant", "content": "Inheritance in Java allows a class to inherit fields and methods from a superclass using extends. For example, ElectricCar extends Vehicle."}
    ]
    status, res = post_json("/api/chat", {
        "message": "Give me another example.",
        "language": "Java",
        "history": history_turn,
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_oop_example = ("class" in reply.lower() or "extends" in reply.lower() or "account" in reply.lower() or "animal" in reply.lower() or "shape" in reply.lower() or "inheritance" in reply.lower() or "employee" in reply.lower())
    passed = status == 200 and has_oop_example
    results.append(("TEST 8 — Follow-Up (Another Java Example)", passed, f"Status: {status}, Follow-up Preserved: {has_oop_example}, Intent: {res.get('intent')}"))

    # --------------------------------------------------------------------------
    # TEST 9: Language Selection (Select C++ and request coding task)
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "Write a program to reverse a string.",
        "language": "C++",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_cpp = "```cpp" in reply or "std::" in reply or "#include" in reply or "cout" in reply or "std::reverse" in reply
    passed = status == 200 and has_cpp
    results.append(("TEST 9 — Language Selection (C++ Code Generation)", passed, f"Status: {status}, Has C++ Code: {has_cpp}"))

    # --------------------------------------------------------------------------
    # TEST 10: General Question with Language Selected (Select Java, ask "What is the capital of France?")
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "What is the capital of France?",
        "language": "Java",
        "history": [],
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_paris = "paris" in reply.lower()
    has_code = "```" in reply or "public class" in reply or "void main" in reply or "Java Solution:" in reply
    passed = status == 200 and has_paris and not has_code
    results.append(("TEST 10 — General Question with Language Selected (Paris/No Java Code)", passed, f"Status: {status}, Answered Paris: {has_paris}, Has Code: {has_code}"))

    # --------------------------------------------------------------------------
    # TEST 11: New Conversation Isolation (Fresh session)
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "What is the capital of Japan?",
        "language": "Python",
        "history": [], # Fresh isolated history
        "mode": "chat"
    })
    reply = res.get("reply", "")
    has_tokyo = "tokyo" in reply.lower()
    has_code = "```" in reply or "Python Solution:" in reply
    has_old_context = "france" in reply.lower() or "paris" in reply.lower() or "modi" in reply.lower()
    passed = status == 200 and has_tokyo and not has_code and not has_old_context
    results.append(("TEST 11 — New Conversation Isolation (Tokyo/No Bleed)", passed, f"Status: {status}, Answered Tokyo: {has_tokyo}, Isolated: {not has_old_context}"))

    # --------------------------------------------------------------------------
    # TEST 12: API Failure Simulation
    # --------------------------------------------------------------------------
    status, res = post_json("/api/chat", {
        "message": "__SIMULATE_API_ERROR__",
        "language": "Python",
        "history": [],
        "simulateError": True,
        "mode": "chat"
    })
    is_error = status == 503 and res.get("status") == "error" and res.get("retryable") is True
    results.append(("TEST 12 — API Failure (Clear Error & Retryable Flag)", is_error, f"Status: {status}, Status: {res.get('status')}, Retryable: {res.get('retryable')}"))

    # --------------------------------------------------------------------------
    # SPECIALIZED WORKSPACE TESTS
    # --------------------------------------------------------------------------
    # Explain a Concept (Programming)
    st_exp, res_exp = post_json("/api/explain", {"topic": "Inheritance", "language": "Java", "level": "Intermediate"})
    exp_pass = st_exp == 200 and "inheritance" in res_exp.get("explanation", "").lower()
    results.append(("WORKSPACE A — Explain Concept (Java Inheritance)", exp_pass, f"Status: {st_exp}"))

    # Explain a Concept (Non-Programming / General Concept)
    st_exp_np, res_exp_np = post_json("/api/explain", {"topic": "Photosynthesis", "language": "Python", "level": "Beginner"})
    np_pass = st_exp_np == 200 and "photosynthesis" in res_exp_np.get("explanation", "").lower() and "def process_data" not in res_exp_np.get("explanation", "")
    results.append(("WORKSPACE A2 — Explain Concept (Photosynthesis / No Code)", np_pass, f"Status: {st_exp_np}"))

    # Debug Workspace (Live Execution)
    st_exe, res_exe = post_json("/api/execute", {"code": "print(15 + 27)", "lang": "Python"})
    exe_pass = st_exe == 200 and "42" in res_exe.get("stdout", "")
    results.append(("WORKSPACE B — Live Python Compiler Execution", exe_pass, f"Output: {res_exe.get('stdout', '').strip()}"))

    # Learn with an Example
    st_exm, res_exm = post_json("/api/example", {"topic": "Arrays", "language": "Python", "level": "Beginner"})
    exm_pass = st_exm == 200 and "lesson" in res_exm
    results.append(("WORKSPACE C — Learn with an Example", exm_pass, f"Status: {st_exm}"))

    # Practice Grader
    st_grd, res_grd = post_json("/api/practice/grade", {
        "language": "Python",
        "code": "def solve(x):\n    return x * 2\n",
        "testCases": [{"input": 5, "expected": 10}, {"input": 7, "expected": 14}]
    })
    grd_pass = st_grd == 200 and res_grd.get("score") == 100 and res_grd.get("passed") is True
    results.append(("WORKSPACE D — Practice Challenge Grader (100% Score)", grd_pass, f"Score: {res_grd.get('score')}%, Passed: {res_grd.get('passed')}"))

    # --------------------------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------------------------
    print("\n" + "-" * 70)
    print("  TEST RESULTS SUMMARY")
    print("-" * 70)
    total = len(results)
    passed_count = sum(1 for _, p, _ in results)
    
    for name, p, details in results:
        status_icon = "✅ PASS" if p else "❌ FAIL"
        print(f"  {status_icon} | {name:<42} | {details}")

    print("-" * 70)
    print(f"  TOTAL: {passed_count}/{total} PASSED ({(passed_count/total)*100:.1f}%)")
    print("=" * 70)

    return passed_count == total

if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
