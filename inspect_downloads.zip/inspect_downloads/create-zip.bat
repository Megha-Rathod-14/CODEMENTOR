@echo off
echo ===================================================
echo   Packaging CodeMentor AI into codementor-ai.zip
echo ===================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path * -DestinationPath ..\codementor-ai.zip -Force"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Zip created successfully!
    echo Location: %~dp0..\codementor-ai.zip
    echo.
) else (
    echo.
    echo [ERROR] Failed to create zip archive.
    echo.
)
pause
