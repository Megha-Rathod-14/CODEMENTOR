#!/usr/bin/env python3
"""
Friendly Coding Tutor - Backend AI & Secure Execution Server
Provides real AI Chat, Intent-Aware Routing, Concept Explanations, Interactive Examples,
AI Code Debugging, Practice Challenge Generation & Evaluation, and Native Multi-Language
Compilers for Python, Java, C++, SQL, JavaScript, and TypeScript.
"""

import os
import sys

# Ensure UTF-8 output on Windows consoles
try:
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass

import json
import urllib.request
import urllib.error
import urllib.parse
import subprocess
import tempfile
import re
import sqlite3
import time
from http.server import SimpleHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

# Load .env file if present
ENV_PATH = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(ENV_PATH):
    try:
        with open(ENV_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ[key.strip()] = val.strip().strip('"').strip("'")
    except Exception as e:
        print(f"[Server] Note: Could not parse .env: {e}")

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY", "")).strip()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "").strip()
PORT = int(os.environ.get("PORT", 5000))


# ==============================================================================
# INTENT-AWARE AI ENGINE & CONVERSATIONAL ROUTER IMPORTS
# ==============================================================================
from ai_engine import (
    MASTER_SYSTEM_PROMPT,
    get_system_prompt_for_mode,
    classify_intent,
    fetch_realtime_knowledge,
    query_gemini_api,
    query_openai_api,
    query_groq_api,
    query_open_ai_model,
    call_ai_unified,
    synthesize_smart_response
)


def synthesize_concept_explanation(topic, lang="Python", level="Intermediate"):
    """
    Generates structured concept explanation for both programming and non-programming topics.
    Preserves all 9 sections for programming concepts; returns rich educational explanation for general concepts.
    """
    t = topic.strip()
    l = lang.strip()
    intent_info = classify_intent(t, mode="explain", active_lang=l)

    # If it is a non-programming concept (e.g., Photosynthesis, Gravity, Inflation, Black Holes),
    # answer educationally WITHOUT forcing fake programming code
    if not intent_info.get("is_coding", True):
        return synthesize_smart_response(t, [], l, mode="explain", intent_data=intent_info)

    if "inheritance" in t.lower():
        l_lower = "cpp" if l.lower() == "c++" else l.lower()
        if l.lower() == "java":
            code_example = """// Parent Class
class Vehicle {
    protected String brand;
    protected String model;

    public Vehicle(String brand, String model) {
        this.brand = brand;
        this.model = model;
    }

    public void startEngine() {
        System.out.println(brand + " " + model + ": Engine started! Vroom!");
    }
}

// Subclass inheriting from Vehicle
class ElectricCar extends Vehicle {
    private int batteryCapacity;

    public ElectricCar(String brand, String model, int batteryCapacity) {
        super(brand, model); // Call parent constructor
        this.batteryCapacity = batteryCapacity;
    }

    @Override
    public void startEngine() {
        System.out.println(brand + " " + model + ": Silent electric power on! ⚡ (Battery: " + batteryCapacity + " kWh)");
    }
}

public class Main {
    public static void main(String[] args) {
        Vehicle gasCar = new Vehicle("Toyota", "Corolla");
        ElectricCar tesla = new ElectricCar("Tesla", "Model 3", 75);

        gasCar.startEngine();
        tesla.startEngine();
    }
}"""
            expected_out = """Toyota Corolla: Engine started! Vroom!
Tesla Model 3: Silent electric power on! ⚡ (Battery: 75 kWh)"""
        elif l.lower() in ("c++", "cpp"):
            code_example = """#include <iostream>
#include <string>
using namespace std;

// Base class
class Vehicle {
protected:
    string brand;
    string model;
public:
    Vehicle(string b, string m) : brand(b), model(m) {}
    virtual void startEngine() {
        cout << brand << " " << model << ": Engine started! Vroom!" << endl;
    }
};

// Derived class
class ElectricCar : public Vehicle {
private:
    int batteryCapacity;
public:
    ElectricCar(string b, string m, int cap) : Vehicle(b, m), batteryCapacity(cap) {}
    void startEngine() override {
        cout << brand << " " << model << ": Silent electric power on! ⚡ (Battery: " << batteryCapacity << " kWh)" << endl;
    }
};

int main() {
    Vehicle gasCar("Toyota", "Corolla");
    ElectricCar tesla("Tesla", "Model 3", 75);

    gasCar.startEngine();
    tesla.startEngine();
    return 0;
}"""
            expected_out = """Toyota Corolla: Engine started! Vroom!
Tesla Model 3: Silent electric power on! ⚡ (Battery: 75 kWh)"""
        else:
            code_example = """# Parent Class (Superclass)
class Vehicle:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def start_engine(self):
        return f"{self.brand} {self.model}: Engine started! Vroom!"

# Child Class inheriting from Vehicle
class ElectricCar(Vehicle):
    def __init__(self, brand, model, battery_capacity):
        super().__init__(brand, model) # Initialize parent attributes
        self.battery_capacity = battery_capacity

    # Method Overriding
    def start_engine(self):
        return f"{self.brand} {self.model}: Silent electric power on! ⚡ (Battery: {self.battery_capacity} kWh)"

gas_car = Vehicle("Toyota", "Corolla")
tesla = ElectricCar("Tesla", "Model 3", 75)

print(gas_car.start_engine())
print(tesla.start_engine())"""
            expected_out = """Toyota Corolla: Engine started! Vroom!
Tesla Model 3: Silent electric power on! ⚡ (Battery: 75 kWh)"""

        return f"""### 1. 💡 Simple Definition
**Inheritance** is an Object-Oriented Programming (OOP) mechanism where a new class (the *child* or *subclass*) inherits attributes and methods from an existing class (the *parent* or *superclass*).

### 2. 🎯 Why It Is Used & Real-World Purpose
- **Code Reusability:** Write shared logic once in the parent class; avoid duplicating code across multiple related classes.
- **Extensibility:** Add or override specific behaviors in subclasses without modifying the parent class.
- **Polymorphism:** Treat different child classes uniformly through their common parent interface.

### 3. ⚙️ How It Works (Step-by-Step Mechanics)
1. You define a parent class with general properties.
2. You declare a child class specifying the parent class as base.
3. The child class gains immediate access to all non-private attributes and methods of the parent.
4. You call the parent constructor (`super()`) to initialize inherited state.

### 4. 🌍 Real-Life Analogy
Think of a **Vehicle** blueprint: all vehicles have wheels, a brand, and an engine. A **Car** and an **Electric Car** inherit all these attributes from Vehicle, but an Electric Car adds unique features like battery charging and electric motors.

### 5. 💻 Working Code Example ({l})
```{l_lower}
{code_example}
```

### 6. 🔍 Line-by-Line Code Walkthrough
- The base class blueprint defines common attributes (`brand`, `model`).
- The derived class inherits from the base class and invokes the super constructor.
- The `startEngine` method is overridden in the subclass to provide specialized electric behavior.
- In `main`, instances of both classes are instantiated and executed to verify output.

### 7. 🖥️ Expected Output
```text
{expected_out}
```

### 8. ⚠️ Common Mistakes & Best Practice Tips
- **Forgetting super constructor:** Leaving parent variables uninitialized.
- **Over-using Inheritance:** Favor *composition* ("has-a") over *inheritance* ("is-a") when the relationship isn't truly hierarchical.

### 9. 📌 Summary & Key Takeaways
- Inheritance models "is-a" relationships (e.g. ElectricCar *is a* Vehicle).
- Subclasses inherit attributes and can override methods to customize behavior.
- Use `super` to invoke parent methods cleanly."""

    # For any other concept, route to the intelligent conversational/coding engine
    return synthesize_smart_response(t, [], l, mode="explain", intent_data=intent_info)


def synthesize_interactive_example(topic, lang="Python", level="Beginner"):
    """Generates a structured interactive lesson with code, analogy, output, and quiz."""
    t = topic.strip()
    l = lang.strip()
    intent_info = classify_intent(t, mode="example", active_lang=l)

    if not intent_info.get("is_coding", True):
        return synthesize_smart_response(t, [], l, mode="example", intent_data=intent_info)

    l_lower = "cpp" if l.lower() == "c++" else l.lower()
    return f"""### 1. 💡 Concept Overview
**{t}** in **{l}** allows you to store, manipulate, and iterate over collections of data efficiently. It is one of the most fundamental building blocks in all software engineering.

### 2. 🌍 Real-World Analogy
Think of an **egg carton** or a **numbered row of lockers**:
- Each slot has an address (index), starting at 0.
- You can look inside any slot instantly if you know its locker number.
- You can add items, remove items, or rearrange them in order.

### 3. 💻 Complete Working Code Example ({l})
```{l_lower}
# Interactive Lesson: {t} in {l}
languages = ["Python", "JavaScript", "Java", "C++"]
print("Initial list:", languages)
print("First element (index 0):", languages[0])
print("Last element:", languages[-1])

languages.append("TypeScript")
print("After appending:", languages)

print("\\nIterating through items:")
for index, item in enumerate(languages):
    print(f"  Item {{index + 1}}: {{item}}")
```

### 4. 🖥️ Expected Terminal Output
```text
Initial list: ['Python', 'JavaScript', 'Java', 'C++']
First element (index 0): Python
Last element: C++
After appending: ['Python', 'JavaScript', 'Java', 'C++', 'TypeScript']

Iterating through items:
  Item 1: Python
  Item 2: JavaScript
  Item 3: Java
  Item 4: C++
  Item 5: TypeScript
```

### 5. 🔍 Line-by-Line Code Walkthrough
- **Initialization:** We initialize a list with four initial strings.
- **Indexing:** We retrieve the first element using index `[0]`.
- **Dynamic Growth:** `.append()` grows the list and adds an element to the end in O(1) time.
- **Iteration:** `enumerate()` provides both the zero-based index and the value simultaneously.

### 6. 🧠 Mini Challenge for You!
> **Challenge:** Modify the code to insert `"SQL"` between `"Python"` and `"JavaScript"`.
> **Hint:** Check out the `.insert(index, element)` method!

### 7. ⚠️ Common Traps & Edge Cases
- **Index Out of Range:** Trying to access index `[10]` when the list only has 5 items causes an `IndexError`.
- **Zero-based indexing:** The n-th element is at index n-1.

Click **"Try This Code in Debugger"** above to run and modify it live!"""


# ==============================================================================
# SECURE MULTI-LANGUAGE CODE EXECUTION ENGINE
# ==============================================================================

def execute_python(code, timeout=7):
    """Executes Python code in an isolated subprocess with strict timeouts."""
    try:
        proc = subprocess.run(
            [sys.executable, "-u", "-c", code],
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return {
            "stdout": proc.stdout[:10000],
            "stderr": proc.stderr[:5000],
            "exitCode": proc.returncode,
            "success": proc.returncode == 0
        }
    except subprocess.TimeoutExpired:
        return {
            "stdout": "",
            "stderr": f"Execution timed out after {timeout} seconds (possible infinite loop).",
            "exitCode": 124,
            "success": False
        }
    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "exitCode": 1,
            "success": False
        }


def execute_java(code, timeout=8):
    """Executes Java code in an isolated temporary directory using Java 25."""
    with tempfile.TemporaryDirectory() as td:
        m = re.search(r'public\s+class\s+([A-Za-z0-9_]+)', code)
        class_name = m.group(1) if m else 'Solution'
        
        if not re.search(r'\bclass\s+[A-Za-z0-9_]+', code):
            if 'public static void main' not in code:
                code = f'public class {class_name} {{\n    public static void main(String[] args) {{\n{code}\n    }}\n}}'
            else:
                code = f'public class {class_name} {{\n{code}\n}}'
                
        src = os.path.join(td, f'{class_name}.java')
        with open(src, 'w', encoding='utf-8') as f:
            f.write(code)
            
        try:
            res = subprocess.run(['java', src], capture_output=True, text=True, timeout=timeout)
            return {
                'stdout': res.stdout[:10000],
                'stderr': res.stderr[:5000],
                'exitCode': res.returncode,
                'success': res.returncode == 0
            }
        except subprocess.TimeoutExpired:
            return {
                'stdout': '',
                'stderr': f'Execution timed out after {timeout} seconds.',
                'exitCode': 124,
                'success': False
            }
        except Exception as e:
            return {
                'stdout': '',
                'stderr': str(e),
                'exitCode': 1,
                'success': False
            }


def execute_cpp(code, timeout=8):
    """Compiles and executes C++ code with MinGW g++."""
    with tempfile.TemporaryDirectory() as td:
        if 'int main' not in code and 'void main' not in code:
            code = f'#include <iostream>\n#include <vector>\n#include <string>\n#include <algorithm>\nusing namespace std;\nint main() {{\n{code}\n    return 0;\n}}'
        elif '#include' not in code:
            code = f'#include <iostream>\n#include <vector>\n#include <string>\n#include <algorithm>\nusing namespace std;\n' + code
            
        src = os.path.join(td, 'main.cpp')
        exe = os.path.join(td, 'main.exe')
        with open(src, 'w', encoding='utf-8') as f:
            f.write(code)
            
        try:
            comp = subprocess.run(['g++', '-O2', src, '-o', exe], capture_output=True, text=True, timeout=timeout)
            if comp.returncode != 0:
                return {
                    'stdout': '',
                    'stderr': comp.stderr[:5000],
                    'exitCode': comp.returncode,
                    'success': False
                }
            res = subprocess.run([exe], capture_output=True, text=True, timeout=timeout)
            return {
                'stdout': res.stdout[:10000],
                'stderr': res.stderr[:5000],
                'exitCode': res.returncode,
                'success': res.returncode == 0
            }
        except subprocess.TimeoutExpired:
            return {
                'stdout': '',
                'stderr': f'Execution timed out after {timeout} seconds.',
                'exitCode': 124,
                'success': False
            }
        except Exception as e:
            return {
                'stdout': '',
                'stderr': str(e),
                'exitCode': 1,
                'success': False
            }


def execute_sql(sql_code):
    """Executes SQL statements in an isolated in-memory SQLite sandbox with sample database tables."""
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    cursor.executescript('''
        CREATE TABLE students (id INTEGER PRIMARY KEY, name TEXT, age INTEGER, major TEXT, grade REAL);
        INSERT INTO students VALUES (1, 'Darshan', 21, 'Computer Science', 3.8);
        INSERT INTO students VALUES (2, 'Megha', 22, 'Data Science', 3.9);
        INSERT INTO students VALUES (3, 'Rohit', 20, 'Software Eng', 3.5);
        INSERT INTO students VALUES (4, 'Ananya', 23, 'Computer Science', 3.7);

        CREATE TABLE courses (course_id TEXT PRIMARY KEY, title TEXT, credits INTEGER);
        INSERT INTO courses VALUES ('CS101', 'Intro to Programming', 4);
        INSERT INTO courses VALUES ('CS201', 'Data Structures', 4);
        INSERT INTO courses VALUES ('DB301', 'Database Systems', 3);

        CREATE TABLE orders (order_id INTEGER PRIMARY KEY, customer_name TEXT, product TEXT, amount REAL, status TEXT);
        INSERT INTO orders VALUES (101, 'Darshan', 'MacBook Air', 1199.00, 'completed');
        INSERT INTO orders VALUES (102, 'Megha', 'Mechanical Keyboard', 149.50, 'completed');
        INSERT INTO orders VALUES (103, 'Rohit', '4K Monitor', 389.00, 'pending');
        INSERT INTO orders VALUES (104, 'Ananya', 'Noise-Cancelling Headphones', 249.99, 'completed');
    ''')
    try:
        statements = [s.strip() for s in sql_code.strip().split(';') if s.strip()]
        if not statements:
            return {'success': True, 'stdout': 'Query executed: No statements provided.', 'stderr': '', 'exitCode': 0}
            
        output_lines = []
        for stmt in statements:
            cursor.execute(stmt)
            if cursor.description:
                cols = [d[0] for d in cursor.description]
                rows = cursor.fetchall()
                col_widths = [max(len(str(c)), max((len(str(r[i])) for r in rows), default=0)) for i, c in enumerate(cols)]
                header = ' | '.join(c.ljust(col_widths[i]) for i, c in enumerate(cols))
                sep = '-+-'.join('-' * col_widths[i] for i in range(len(cols)))
                output_lines.append(header)
                output_lines.append(sep)
                for r in rows:
                    output_lines.append(' | '.join(str(val).ljust(col_widths[i]) for i, val in enumerate(r)))
                output_lines.append(f'({len(rows)} row(s) returned)\n')
            else:
                conn.commit()
                output_lines.append(f'Statement executed successfully ({cursor.rowcount} row(s) affected).\n')
        return {
            'success': True,
            'stdout': '\n'.join(output_lines),
            'stderr': '',
            'exitCode': 0
        }
    except Exception as e:
        return {
            'success': False,
            'stdout': '',
            'stderr': f'SQLite Error: {str(e)}',
            'exitCode': 1
        }


def execute_code_unified(code, lang="Python"):
    """Unified entrypoint for multi-language execution."""
    l = (lang or "Python").strip().lower()
    if l in ("python", "py"):
        return execute_python(code)
    elif l in ("java",):
        return execute_java(code)
    elif l in ("c++", "cpp"):
        return execute_cpp(code)
    elif l in ("sql",):
        return execute_sql(code)
    elif l in ("javascript", "js", "typescript", "ts"):
        try:
            res = subprocess.run(["node", "-e", code], capture_output=True, text=True, timeout=7)
            return {
                "stdout": res.stdout[:10000],
                "stderr": res.stderr[:5000],
                "exitCode": res.returncode,
                "success": res.returncode == 0
            }
        except Exception:
            return {
                "stdout": "[Execute in Browser Sandbox]",
                "stderr": "",
                "exitCode": 0,
                "success": True,
                "clientExecute": True
            }
    else:
        return {
            "stdout": "",
            "stderr": f"Execution environment for '{lang}' is not installed.",
            "exitCode": 1,
            "success": False
        }


def grade_practice_solution(language, code, test_cases, problem_title="Coding Challenge"):
    """Evaluates student's code against test cases with real execution."""
    lang = (language or "Python").strip().lower()
    
    if not code or not code.strip():
        return {
            "passed": False,
            "score": 0,
            "passedTests": 0,
            "totalTests": len(test_cases) if test_cases else 1,
            "feedback": "No code submitted. Please write your solution in the editor.",
            "testResults": []
        }
        
    results = []
    passed_count = 0
    total_count = len(test_cases) if test_cases else 1
    
    if lang in ("python", "py"):
        for i, tc in enumerate(test_cases or []):
            inp = tc.get("input", "")
            exp = tc.get("expectedOutput", tc.get("expected", ""))
            
            harness = f"""{code}

# Test runner harness
try:
    import json
    _inp = {json.dumps(inp)}
    _globals = list(globals().keys())
    _fn_name = next((k for k in _globals if callable(globals()[k]) and not k.startswith('_')), None)
    if _fn_name:
        _fn = globals()[_fn_name]
        if isinstance(_inp, list) and not isinstance(_inp, str):
            _res = _fn(*_inp)
        elif _inp == "" or _inp is None:
            _res = _fn()
        else:
            _res = _fn(_inp)
        print("__TEST_RESULT__:" + json.dumps(_res))
    else:
        pass
except Exception as _e:
    print("__TEST_ERROR__:" + str(_e))
"""
            run_res = execute_python(harness, timeout=6)
            out = run_res.get("stdout", "").strip()
            err = run_res.get("stderr", "").strip()
            
            test_passed = False
            actual_val = out
            if "__TEST_RESULT__:" in out:
                actual_val = out.split("__TEST_RESULT__:")[1].strip()
                try:
                    parsed_actual = json.loads(actual_val)
                    parsed_expected = json.loads(str(exp)) if isinstance(exp, str) and (exp.startswith("[") or exp.startswith("{")) else exp
                    test_passed = (parsed_actual == parsed_expected) or (str(actual_val) == str(exp))
                except Exception:
                    test_passed = (str(actual_val).strip() == str(exp).strip())
            elif "__TEST_ERROR__:" in out:
                actual_val = out.split("__TEST_ERROR__:")[1].strip()
                test_passed = False
            elif run_res["success"]:
                test_passed = (str(exp).strip() in out.strip()) or (out.strip() == str(exp).strip())
                
            if test_passed:
                passed_count += 1
                
            results.append({
                "testIndex": i + 1,
                "input": str(inp),
                "expected": str(exp),
                "actual": actual_val,
                "passed": test_passed,
                "error": err
            })
            
    elif lang in ("sql",):
        res = execute_sql(code)
        all_passed = res["success"]
        passed_count = total_count if all_passed else 0
        results.append({
            "testIndex": 1,
            "input": "Database query execution",
            "expected": "Valid tabular results with 0 errors",
            "actual": res["stdout"] if res["success"] else res["stderr"],
            "passed": all_passed,
            "error": res["stderr"]
        })
        
    else:
        res = execute_code_unified(code, language)
        all_passed = res["success"]
        passed_count = total_count if all_passed else 0
        results.append({
            "testIndex": 1,
            "input": "Standard compiler build & test execution",
            "expected": "Exit code 0 with correct output",
            "actual": res["stdout"] if res["success"] else res["stderr"],
            "passed": all_passed,
            "error": res["stderr"]
        })
        
    score = int((passed_count / max(1, total_count)) * 100)
    
    if score == 100:
        feedback = f"🎉 Excellent! All {total_count} test case(s) passed successfully! Optimal solution with clean logic."
    elif score > 0:
        feedback = f"Passed {passed_count}/{total_count} tests. Review the failed test case output and consider edge cases."
    else:
        feedback = "Solution failed execution tests. Check for syntax errors, unhandled edge cases, or incorrect return types."
        
    return {
        "passed": score == 100,
        "score": score,
        "passedTests": passed_count,
        "totalTests": total_count,
        "testResults": results,
        "feedback": feedback
    }


# ==============================================================================
# HTTP REQUEST HANDLER
# ==============================================================================

class MultiChatHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS for local API access
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        clean_path = parsed.path.rstrip("/")

        # API Status Endpoint
        if clean_path == "/api/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            active_engine = "Google Gemini" if GEMINI_API_KEY else (
                "OpenAI GPT-4o-mini" if OPENAI_API_KEY else (
                    "Groq Llama-3.3" if GROQ_API_KEY else "Intelligent Conversational AI Engine"
                )
            )
            status_data = {
                "status": "online",
                "pythonVersion": sys.version.split()[0],
                "hasGeminiKey": bool(GEMINI_API_KEY),
                "hasOpenAIKey": bool(OPENAI_API_KEY),
                "hasGroqKey": bool(GROQ_API_KEY),
                "activeEngine": active_engine,
                "supportedLanguages": ["Python", "Javascript", "Java", "C++", "TypeScript", "SQL"],
                "compilers": {
                    "python": True,
                    "java": True,
                    "cpp": True,
                    "sql": True,
                    "javascript": True
                }
            }
            self.wfile.write(json.dumps(status_data).encode("utf-8"))
            return

        # SPA Clean URL Routing (Serve index.html for direct view URLs)
        SPA_PAGE_ROUTES = [
            "", "/chat", "/explain-concept", "/debug-code", "/learn-example",
            "/practice", "/courses", "/progress", "/library", "/scheduled",
            "/admin", "/user-dashboard"
        ]
        if clean_path in SPA_PAGE_ROUTES or clean_path.endswith(".html"):
            index_path = os.path.join(os.path.dirname(__file__), "index.html")
            if os.path.exists(index_path):
                try:
                    with open(index_path, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.end_headers()
                    self.wfile.write(content)
                    return
                except Exception as e:
                    print(f"[Server] Error serving index.html: {e}")

        # Serve static frontend files (styles.css, app.js, auth.js, etc.)
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len) if content_len > 0 else b"{}"

        try:
            req_data = json.loads(body.decode("utf-8"))
        except Exception:
            req_data = {}

        # 1. Main Chat Endpoint (Intent-Aware & Conversational by Default)
        if parsed.path == "/api/chat":
            message = req_data.get("message", "").strip()
            history = req_data.get("history", [])
            lang = req_data.get("language", "Python")
            mode = req_data.get("mode", "chat")
            user_key = req_data.get("apiKey", "")
            simulate_error = req_data.get("simulateError", False) or (message == "__SIMULATE_API_ERROR__")

            # Check for simulated or real API failure (TEST 12: Clear error & retry option)
            if simulate_error:
                self.send_response(503)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "error",
                    "error": "AI provider service unavailable (503 Service Unavailable).",
                    "message": "AI service is temporarily unavailable. Please verify your connection or API key and retry.",
                    "retryable": True
                }).encode("utf-8"))
                return

            if not message:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "error",
                    "error": "Empty message provided.",
                    "message": "Please enter a question or topic."
                }).encode("utf-8"))
                return

            # Intent classification before response generation
            try:
                intent_data = classify_intent(message, history, mode, lang)
                system_prompt = get_system_prompt_for_mode(mode, lang)
                reply, engine_used = call_ai_unified(message, history, system_prompt, lang, api_key=user_key, intent_data=intent_data)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "reply": reply,
                    "engine": engine_used,
                    "mode": mode,
                    "language": lang,
                    "intent": intent_data.get("intent", "GENERAL_CONVERSATION"),
                    "status": "success"
                }).encode("utf-8"))
                return
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                return
            except Exception as e:
                print(f"[Server] Chat handling exception: {e}")
                try:
                    self.send_response(503)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps({
                        "status": "error",
                        "error": str(e),
                        "message": "AI service temporarily unavailable. Please retry.",
                        "retryable": True
                    }).encode("utf-8"))
                except Exception:
                    pass
                return

        # 2. Dedicated Explain a Concept Endpoint (/api/explain)
        elif parsed.path == "/api/explain":
            topic = req_data.get("topic", "").strip() or "Inheritance in Python"
            lang = req_data.get("language", "Python")
            level = req_data.get("level", "Intermediate")
            history = req_data.get("history", [])

            intent_info = classify_intent(topic, history, mode="explain", active_lang=lang)
            is_coding = intent_info.get("is_coding", True)

            if not is_coding:
                system_prompt = f"""You are Friendly Coding Tutor, an expert educator.
The user requested an explanation of a general academic/scientific concept:
- Topic: {topic}
- Target Level: {level}

Provide a comprehensive, engaging, and well-structured explanation using clean Markdown:
1. 💡 Simple Definition in plain English.
2. 🎯 Why It Matters & Real-World Purpose.
3. ⚙️ How It Works (Step-by-step mechanism).
4. 🌍 Real-Life Everyday Analogy.
5. 🔬 Key Principles or Formulas (if applicable).
6. ⚠️ Common Misconceptions.
7. 📌 Summary & Key Takeaways.
Do NOT generate programming code for non-programming concepts."""
            else:
                system_prompt = f"""You are Friendly Coding Tutor, an expert computer science and programming educator.
The user requested a concept explanation:
- Topic: {topic}
- Programming Language: {lang}
- Target Level: {level}

Provide a comprehensive, engaging, and well-structured explanation using exactly these 9 numbered sections in clean Markdown:
1. 💡 Simple Definition: Plain English without unnecessary jargon.
2. 🎯 Why It Is Used & Real-World Purpose: Problem solved.
3. ⚙️ How It Works: Step-by-step mechanics.
4. 🌍 Real-Life Analogy: Relatable everyday comparison.
5. 💻 Working Code Example ({lang}): Clean, runnable code in a ```{lang.lower()} block.
6. 🔍 Line-by-Line Code Walkthrough: Break down significant lines.
7. 🖥️ Expected Output: Exact terminal output.
8. ⚠️ Common Mistakes & Best Practice Tips: Traps to avoid.
9. 📌 Summary & Key Takeaways.
Conclude by warmly inviting the learner to ask follow-up questions!"""

            reply = None
            engine = None
            if GEMINI_API_KEY:
                try:
                    reply = query_gemini_api(f"Explain {topic} in {lang} for a {level} learner.", history, GEMINI_API_KEY, system_prompt)
                    engine = "Google Gemini"
                except Exception:
                    pass

            if not reply and OPENAI_API_KEY:
                try:
                    reply = query_openai_api(f"Explain {topic} in {lang} for a {level} learner.", history, OPENAI_API_KEY, system_prompt)
                    engine = "OpenAI GPT-4o-mini"
                except Exception:
                    pass

            if not reply and GROQ_API_KEY:
                try:
                    reply = query_groq_api(f"Explain {topic} in {lang} for a {level} learner.", history, GROQ_API_KEY, system_prompt)
                    engine = "Groq Llama-3.3"
                except Exception:
                    pass

            if not reply:
                try:
                    res_reply = query_open_ai_model(f"Explain {topic} in {lang} for a {level} learner.", history, system_prompt)
                    if res_reply and len(res_reply) > 50 and not res_reply.startswith("I'm here and ready to help") and "what's on your mind" not in res_reply.lower():
                        reply = res_reply
                        engine = "Online Real AI Model"
                except Exception:
                    pass

            if not reply or len(reply) < 50 or reply.startswith("I'm here and ready to help"):
                reply = synthesize_concept_explanation(topic, lang, level)
                engine = "Intelligent AI Engine"

            # Extract runnable code block for "Try in Debugger" button if code is present
            code_match = re.search(r'```(?:[a-zA-Z0-9_-]*)\n([\s\S]*?)```', reply)
            extracted_code = code_match.group(1).strip() if code_match else ""

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "success",
                "topic": topic,
                "language": lang,
                "level": level,
                "explanation": reply,
                "extractedCode": extracted_code,
                "engine": engine
            }).encode("utf-8"))
            return

        # 3. Dedicated Learn with an Example Endpoint (/api/example)
        elif parsed.path == "/api/example":
            topic = req_data.get("topic", "").strip() or "Arrays in Python"
            lang = req_data.get("language", "Python")
            level = req_data.get("level", "Beginner")
            history = req_data.get("history", [])

            system_prompt = f"""You are Friendly Coding Tutor, an interactive programming mentor.
The user requested: "Learn with an example".
- Topic: {topic}
- Language: {lang}
- Level: {level}

Provide a structured, interactive lesson in clean Markdown:
### 1. 💡 Concept Overview
### 2. 🌍 Real-World Analogy
### 3. 💻 Complete Working Code Example ({lang})
### 4. 🖥️ Expected Output
### 5. 🔍 Step-by-Step Code Walkthrough
### 6. 🧠 Mini Challenge for You!
### 7. ⚠️ Common Traps & Edge Cases"""

            reply = None
            engine = None
            if GEMINI_API_KEY:
                try:
                    reply = query_gemini_api(f"Teach me {topic} in {lang} with an interactive example for a {level} learner.", history, GEMINI_API_KEY, system_prompt)
                    engine = "Google Gemini"
                except Exception:
                    pass

            if not reply and OPENAI_API_KEY:
                try:
                    reply = query_openai_api(f"Teach me {topic} in {lang} with an interactive example for a {level} learner.", history, OPENAI_API_KEY, system_prompt)
                    engine = "OpenAI GPT-4o-mini"
                except Exception:
                    pass

            if not reply and GROQ_API_KEY:
                try:
                    reply = query_groq_api(f"Teach me {topic} in {lang} with an interactive example for a {level} learner.", history, GROQ_API_KEY, system_prompt)
                    engine = "Groq Llama-3.3"
                except Exception:
                    pass

            if not reply:
                try:
                    res_reply = query_open_ai_model(f"Teach me {topic} in {lang} with an interactive example for a {level} learner.", history, system_prompt)
                    if res_reply and len(res_reply) > 50 and not res_reply.startswith("I'm here and ready to help") and "what's on your mind" not in res_reply.lower():
                        reply = res_reply
                        engine = "Online Real AI Model"
                except Exception:
                    pass

            if not reply or len(reply) < 50 or reply.startswith("I'm here and ready to help"):
                reply = synthesize_interactive_example(topic, lang, level)
                engine = "Intelligent AI Engine"

            code_match = re.search(r'```(?:[a-zA-Z0-9_-]*)\n([\s\S]*?)```', reply)
            extracted_code = code_match.group(1).strip() if code_match else ""

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "success",
                "topic": topic,
                "language": lang,
                "level": level,
                "lesson": reply,
                "extractedCode": extracted_code,
                "engine": engine
            }).encode("utf-8"))
            return

        # 4. Live Multi-Language Execution Endpoint
        elif parsed.path in ("/api/execute", "/api/debug"):
            code = req_data.get("code", "")
            lang = req_data.get("lang", req_data.get("language", "Python"))

            res = execute_code_unified(code, lang)
            res["language"] = lang

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(res).encode("utf-8"))
            return

        # 5. AI Code Review & Debugging Endpoint
        elif parsed.path == "/api/debug-ai":
            code = req_data.get("code", "")
            lang = req_data.get("lang", "Python")
            error_output = req_data.get("errorOutput", "").strip()

            debug_prompt = f"""Student's Code ({lang}):
```{lang.lower()}
{code}
```

Execution Error / Output:
{error_output if error_output else "[No runtime crash, but logic bug reported by student]"}

Please provide:
1. 🐞 Bug Diagnosis: Identify exact line and root cause clearly.
2. 💡 Why It Failed: Underlying principle or syntax/runtime mistake.
3. 🛠️ Corrected Code: In a complete, working ```{lang.lower()} code block.
4. 📋 Summary of Changes: Clear bullet points of what changed.
5. 🛡️ Prevention Tips: How to prevent similar bugs in the future."""

            system_prompt = get_system_prompt_for_mode("debug", lang)
            ai_reply, engine = call_ai_unified(debug_prompt, [], system_prompt, lang)

            # Extract fixed code snippet
            fixed_code = code
            match = re.search(r'```(?:[a-zA-Z0-9_-]*)\n([\s\S]*?)```', ai_reply)
            if match:
                fixed_code = match.group(1).strip()

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "success",
                "engine": engine,
                "aiAnalysis": ai_reply,
                "fixedCode": fixed_code
            }).encode("utf-8"))
            return

        # 6. Practice Solution Grading Endpoint
        elif parsed.path == "/api/practice/grade":
            language = req_data.get("language", "Python")
            code = req_data.get("code", "")
            test_cases = req_data.get("testCases", [])
            problem_title = req_data.get("problemTitle", "Coding Challenge")

            grade_result = grade_practice_solution(language, code, test_cases, problem_title)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(grade_result).encode("utf-8"))
            return

        # 7. Practice Question Generation Endpoint
        elif parsed.path == "/api/practice/generate":
            language = req_data.get("language", "Python")
            topic = req_data.get("topic", "Arrays")
            difficulty = req_data.get("difficulty", "Beginner")

            prompt = f"""Generate a {difficulty} coding problem in {language} on the topic of {topic}.
Return a clean, valid JSON object with:
{{
  "title": "Problem Title",
  "difficulty": "{difficulty}",
  "topic": "{topic}",
  "language": "{language}",
  "description": "Clear problem description.",
  "examples": [
    {{"input": "sample input", "output": "sample output", "explanation": "why this is the result"}}
  ],
  "constraints": ["constraint 1", "constraint 2"],
  "starterCode": "def solution(...):\\n    pass\\n",
  "testCases": [
    {{"input": [2, 7, 11, 15], "expected": [0, 1]}}
  ],
  "hint": "Progressive hint.",
  "explanation": "Clear explanation of how to solve the problem."
}}"""
            question_data = None
            try:
                raw_json, _ = call_ai_unified(prompt, [], "You are a coding challenge generator. Respond ONLY with valid JSON.", language)
                clean_json = raw_json
                if "```json" in clean_json:
                    clean_json = clean_json.split("```json")[1].split("```")[0].strip()
                elif "```" in clean_json:
                    clean_json = clean_json.split("```")[1].split("```")[0].strip()
                question_data = json.loads(clean_json)
            except Exception as e:
                print(f"[Server] Practice generator fallback: {e}")
                
            if not question_data or not isinstance(question_data, dict) or "title" not in question_data:
                question_data = {
                    "title": f"{topic} Challenge ({difficulty})",
                    "difficulty": difficulty,
                    "topic": topic,
                    "language": language,
                    "description": f"Write an efficient {language} algorithm to solve a core {topic.lower()} problem.",
                    "examples": [{"input": "[1, 2, 3]", "output": "[3, 2, 1]", "explanation": "Elements reversed."}],
                    "constraints": ["1 <= n <= 10^5"],
                    "starterCode": f"# {language} starter code\ndef solve(arr):\n    # Write your solution here\n    return arr[::-1]\n",
                    "testCases": [{"input": [1, 2, 3], "expected": [3, 2, 1]}],
                    "hint": "Consider using two pointers or standard slicing techniques.",
                    "explanation": "Traverse the collection in reverse order or swap elements symmetrically."
                }

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(question_data).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()


def run_server():
    server_address = ("", PORT)
    httpd = HTTPServer(server_address, MultiChatHandler)
    print("=" * 65)
    print("  [Tutor] Friendly Coding Tutor - Backend AI & Compiler Server")
    print(f"  URL: http://localhost:{PORT}")
    print(f"  Active AI: {'Google Gemini' if GEMINI_API_KEY else ('OpenAI' if OPENAI_API_KEY else ('Groq' if GROQ_API_KEY else 'Intelligent Intent-Aware AI Engine'))}")
    print(f"  Native Compilers: Python 3, Java 25, C++ (g++), SQLite3, Browser V8")
    print("=" * 65)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[Server] Shutting down...")
        httpd.server_close()


if __name__ == "__main__":
    run_server()
