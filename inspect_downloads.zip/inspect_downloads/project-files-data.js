/**
 * Project Files Bundler
 * Contains pre-packaged source files for instant 1-click in-browser zip generation.
 */

window.PROJECT_SOURCES = {
  "README.md": `# 🤖 CodeMentor AI - Learn • Build • Improve

An intelligent coding tutor web application with dedicated programming features:
1. Concept Language Selection (Python, JavaScript, Java, C++, TypeScript, SQL)
2. "Explain a concept" interactive questioning & breakdown flow
3. "Debug my code" live split-screen online compiler
4. "Learn with an example" real-world code walkthrough
5. "Practice" coding challenges with automated grading & score rating
6. Weekly Performance & Skill Rhythm dashboard (Problems solved, Streak, Accuracy)
7. Search & Query History in Settings
8. Pre-configured Login (Megha@143 / 123456)
9. SQL Database Schema (schema.sql & SQLite initializer)

## 🔑 Login Credentials (Dual Access Portal)
- **User Side:** \`darshan@123\` / \`456789\` (Role: Student)
- **Admin Side:** \`megha@1409\` / \`123456\` (Role: Admin)
`,

  "create-zip.bat": `@echo off
echo ===================================================
echo   Packaging CodeMentor AI into codementor-ai.zip
echo ===================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path * -DestinationPath ..\\codementor-ai.zip -Force"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Zip created successfully!
    echo Location: %~dp0..\\codementor-ai.zip
    echo.
) else (
    echo.
    echo [ERROR] Failed to create zip archive.
    echo.
)
pause
`,

  "schema.sql": `-- ============================================================================
-- CodeMentor AI - Database Schema (SQL)
-- Compatible with SQLite, PostgreSQL, and MySQL
-- Default User: Megha@143 (password: 123456)
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150),
    plan VARCHAR(50) DEFAULT 'student plan',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conversations (
    conversation_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    concept_language VARCHAR(50) DEFAULT 'Python',
    mode VARCHAR(50) DEFAULT 'Chat',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS messages (
    message_id VARCHAR(50) PRIMARY KEY,
    conversation_id VARCHAR(50) NOT NULL,
    sender VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    code_snippet TEXT,
    language VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS search_history (
    history_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    query_text TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    concept_language VARCHAR(50) DEFAULT 'Python',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS practice_submissions (
    submission_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    question_title VARCHAR(255) NOT NULL,
    concept_language VARCHAR(50) NOT NULL,
    submitted_code TEXT NOT NULL,
    score INT NOT NULL,
    rating VARCHAR(20) NOT NULL,
    feedback TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS weekly_performance (
    stat_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    problems_solved INT DEFAULT 42,
    problems_this_week INT DEFAULT 8,
    lessons_done INT DEFAULT 18,
    lessons_in_progress INT DEFAULT 3,
    current_streak_days INT DEFAULT 7,
    accuracy_percentage INT DEFAULT 84,
    accuracy_delta INT DEFAULT 6,
    total_focus_minutes INT DEFAULT 272,
    week_start_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS skill_map (
    skill_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    skill_name VARCHAR(50) NOT NULL,
    proficiency_percentage INT NOT NULL,
    color_hex VARCHAR(20) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

INSERT INTO users (user_id, username, password_hash, full_name, plan)
VALUES ('usr_megha_001', 'Megha@143', '123456', 'Megha Sharma', 'student plan');
`,

  "create_sqlite_db.py": `import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "codementor.db")
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.sql")

def build_database():
    print(f"Connecting to {DB_PATH}...")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    if os.path.exists(SCHEMA_PATH):
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            sql_script = f.read()
        cursor.executescript(sql_script)
        conn.commit()
        print("Database codementor.db created and seeded successfully!")
    conn.close()

if __name__ == "__main__":
    build_database()
`
};
