@echo off
title Friendly Coding Tutor Server
echo ===================================================
echo   Starting Friendly Coding Tutor Backend Server
echo ===================================================
cd /d "%~dp0"
python server.py
pause
