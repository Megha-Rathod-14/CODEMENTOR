# 🤖 Friendly Coding Tutor — Learn • Build • Debug • Practice

A fully functional, ChatGPT-like AI programming assistant and online coding tutor. Built with a pixel-perfect dark theme (`#0d0f18`), purple accent styling, real backend AI endpoints, native compilers, and interactive practice grading.

---

## 🌟 Key Features

### 1. 💬 ChatGPT-Like General AI Assistant
- **Multi-Turn Conversation Memory:** Understands context and remembers previous messages across follow-up queries (*"Explain this again"*, *"Make it easier"*, *"Give me another example"*).
- **Natural Language Understanding:** Explains both programming and non-programming topics in clear, beginner-friendly language.
- **Rich Markdown & Syntax Highlighting:** Supports headings, bullet points, numbered steps, bold/italic text, and syntax-highlighted code blocks with 1-click **Copy Code** and **Run Code** buttons.
- **Typing Indicator & Streaming:** Responsive indicator while generating responses.
- **Keyboard Shortcuts:** `Enter` to send, `Shift + Enter` for a multi-line input.
- **Auto-Scroll & Dual Bubbles:** User messages on the right, AI responses on the left.

---

### 2. 💡 Feature 1: Explain a Concept
When clicked, activates structured 8-part pedagogical explanations:
1. **Simple Definition**
2. **Why It Is Used**
3. **How It Works Step-by-Step**
4. **Real-Life Analogy**
5. **Programming Example** in the currently selected language
6. **Line-by-Line Code Explanation**
7. **Expected Program Output**
8. **Quick Recap & Follow-Up Prompts**

---

### 3. 🐞 Feature 2: Debug My Code — Online Coding Workspace
A split-screen coding playground integrated directly within the application:
- **Left Side (Code Editor):**
  - Multi-language support: **Python, JavaScript, Java, C++, TypeScript, SQL**.
  - **Run Code** button executing on real native compilers.
  - **Sample Code** templates and **Clear Code** button.
- **Right Side (Console Output & AI Bug Diagnostics):**
  - **Terminal / Console:** Real stdout and stderr, syntax errors, and runtime stack traces.
  - **AI Bug Diagnostics:** Analyzes the root cause, identifies the problematic line, explains why it failed, and provides the corrected code.
  - **Apply Fix to Editor:** 1-click button to automatically replace buggy code with the AI fix and immediately re-run.

---

### 4. 🎯 Feature 3: Learn with an Example
Interactive step-by-step tutorial mode:
- Explains concepts with complete runnable code.
- Line-by-line breakdown and internal execution mechanics.
- Slightly modified variant to reinforce understanding.
- Adaptive follow-up prompts (*"Explain line 3"*, *"Give me an easier example"*, *"I don't understand"*).

---

### 5. 🧩 Feature 4: Practice — Adaptive Coding Challenges
- Adaptive coding problem generator and bank across **Beginner**, **Intermediate**, and **Advanced** difficulties.
- Multi-language filters: **Python, JavaScript, Java, C++, TypeScript, SQL**.
- Displays: Title, Problem Description, Input/Output formats, Example cases, and Constraints.
- **Submit Answer:** Evaluates student code against real test cases in an isolated execution sandbox.
- **Pass/Fail Breakdown:** Displays passed test counts, actual vs expected outputs, and execution status.
- **Get Hint:** Progressive hints without giving away the full answer.
- **Show Explanation:** Complete complexity analysis ($O(n)$ time/space) and solution walkthrough.

---

### 6. 🌐 6 Supported Programming Languages
- **Python:** Python 3.13 subprocess sandbox with timeout protection.
- **Java:** Java 25 single-file execution runner.
- **C++:** MinGW GCC (`g++`) compiler sandbox.
- **SQL:** SQLite in-memory relational sandbox pre-populated with `students`, `courses`, and `orders` tables.
- **JavaScript & TypeScript:** Native browser V8 engine and client-side execution.

---

## 🚀 How to Run the Application

### Step 1: Start the Backend Server
Double-click `start-server.bat` or run:
```bash
python server.py
```
The server will start on `http://localhost:5000`.

### Step 2: Open in Your Browser
Open your browser and navigate to:
```
http://localhost:5000
```
The application opens directly onto the **Friendly Coding Tutor** landing screen ready for chat, code debugging, and practice!

---

## 🧪 Running Automated Tests

Run the complete end-to-end test suite anytime:
```bash
python test_suite.py
```
This tests:
1. Python 3.13 valid code execution.
2. Buggy code error handling (`ZeroDivisionError`).
3. Java 25 compiler execution.
4. C++ (MinGW `g++`) compiler execution.
5. SQLite query execution on sample database tables.
6. AI bug diagnostics and corrected code generation.
7. Practice challenge grading (passing and failing test cases).
8. Concept explanation mode (8-part structured output).
9. Learn with an example mode.
10. Multi-turn conversational follow-up memory.

---

## 🔐 Optional API Key Setup

The tutor works **100% out of the box** using the included online AI router and offline NLP fallbacks.

If you wish to use your personal API keys for Google Gemini, OpenAI, or Groq:
1. Open `.env` in the project root:
   ```env
   GEMINI_API_KEY=your_gemini_key_here
   OPENAI_API_KEY=your_openai_key_here
   GROQ_API_KEY=your_groq_key_here
   PORT=5000
   ```
2. Restart the server (`start-server.bat`).

---

## 📁 Project Structure

```text
friendly-coding-tutor/
├── index.html            # Main UI with dark theme, hero, cards, and modal views
├── styles.css            # Dark theme styling, purple accents (#6c5ce7), responsive layout
├── app.js                # Frontend controller: chat, markdown, compilers, practice grader
├── auth.js               # Session controller (auto-authenticates student session)
├── server.py             # Python HTTP backend (API routing, compilers, AI model router)
├── test_suite.py         # Automated end-to-end verification test suite
├── start-server.bat      # 1-click launcher for Windows
├── .env.example          # Environment variables template
├── .env                  # Environment file for optional API keys
├── skulpt.min.js         # Client-side Python virtual machine
├── skulpt-stdlib.js      # Python standard library
└── README.md             # Project documentation
```
