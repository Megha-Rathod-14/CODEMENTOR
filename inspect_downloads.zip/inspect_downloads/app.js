/**
 * CodeMentor AI - Master Application Controller
 * Handles Chat Workspace, Concept Language Switching, Live Online Compiler,
 * Interactive Practice Grader, Weekly Performance Dashboard, and Search History.
 */

// Application State
let activeView = "chat";
let selectedConceptLang = "Python";
let chatMessages = [];
let isGenerating = false;
let waitingForConceptType = null; // 'explain' | 'example' | null

// Search & Query History (Requested in Settings)
let searchHistory = [];

// Weekly Performance & Skill Metrics (Matches Image 2)
let weeklyStats = {
  problemsSolved: 42,
  problemsThisWeek: 8,
  lessonsDone: 18,
  lessonsInProgress: 3,
  currentStreak: 7,
  accuracy: 84,
  accuracyDelta: 6,
  focusTime: "4h 32m",
  skills: {
    Python: 90,
    Java: 70,
    SQL: 80,
    DSA: 50
  }
};

let userSettings = {
  theme: "dark",
  sounds: true
};

// ==========================================================================
// INITIALIZATION
// ==========================================================================
function initChatbotApp() {
  loadStoredData();
  setupDateDisplay();
  setConceptLanguage("Python");
  renderSearchHistoryTable();
  updateProgressDashboardUI();
  updateHistoryBadge();
  switchView("chat");
  initChatScrollListener();
  updateSendButtonDisabled();
}

function loadStoredData() {
  try {
    const rawHist = localStorage.getItem("codementor_search_history");
    if (rawHist) searchHistory = JSON.parse(rawHist);
    else seedDefaultSearchHistory();

    const rawStats = localStorage.getItem("codementor_weekly_stats");
    if (rawStats) weeklyStats = JSON.parse(rawStats);

    const rawChat = localStorage.getItem("codementor_active_chat");
    if (rawChat) chatMessages = JSON.parse(rawChat);

    const rawSettings = localStorage.getItem("codementor_settings");
    if (rawSettings) userSettings = JSON.parse(rawSettings);

    const savedGemini = localStorage.getItem("codementor_gemini_key");
    const geminiInput = document.getElementById("gemini-api-key-input");
    if (savedGemini && geminiInput) geminiInput.value = savedGemini;
  } catch (e) {
    console.warn("Storage load error:", e);
  }

  if (chatMessages.length > 0) {
    showChatHero(false);
    renderChatMessages();
  } else {
    showChatHero(true);
  }
}

function seedDefaultSearchHistory() {
  searchHistory = [
    {
      id: "sh_1",
      query: "Explain inheritance in Python",
      category: "Concept Explanation",
      language: "Python",
      formattedDate: "Oct 13, 10:30 AM"
    },
    {
      id: "sh_2",
      query: "Help me debug my Python code",
      category: "Code Debugging",
      language: "Python",
      formattedDate: "Oct 13, 10:32 AM"
    },
    {
      id: "sh_3",
      query: "Teach me arrays with a small example",
      category: "Learn with Example",
      language: "Python",
      formattedDate: "Oct 13, 10:34 AM"
    },
    {
      id: "sh_4",
      query: "Give me a SQL practice question",
      category: "Practice Challenge",
      language: "SQL",
      formattedDate: "Oct 13, 10:35 AM"
    }
  ];
  saveSearchHistory();
}

function saveSearchHistory() {
  localStorage.setItem("codementor_search_history", JSON.stringify(searchHistory));
  updateHistoryBadge();
}

function saveWeeklyStats() {
  localStorage.setItem("codementor_weekly_stats", JSON.stringify(weeklyStats));
  updateProgressDashboardUI();
}

function saveActiveChat() {
  localStorage.setItem("codementor_active_chat", JSON.stringify(chatMessages));
}

function setupDateDisplay() {
  const dateSub = document.getElementById("top-date-subtitle");
  if (dateSub) {
    const now = new Date();
    const dayName = now.toLocaleDateString("en-US", { weekday: "long" }).toUpperCase();
    const dayNum = now.getDate();
    const month = now.toLocaleDateString("en-US", { month: "long" }).toUpperCase();
    dateSub.textContent = `AI WORKSPACE • ${dayName} ${dayNum} ${month}`;
  }
}

// ==========================================================================
// VIEW SWITCHING (User Dashboard, Chat, Debug, Practice, Progress, Courses, Admin)
// ==========================================================================
function switchView(viewName, pushState = true) {
  activeView = viewName;

  // View containers
  const views = {
    "user-dashboard": document.getElementById("view-user-dashboard"),
    chat: document.getElementById("view-chat"),
    explain: document.getElementById("view-explain"),
    example: document.getElementById("view-learn-example"),
    debug: document.getElementById("view-debug"),
    practice: document.getElementById("view-practice"),
    progress: document.getElementById("view-progress"),
    library: document.getElementById("view-library"),
    scheduled: document.getElementById("view-scheduled"),
    courses: document.getElementById("view-courses"),
    admin: document.getElementById("view-admin")
  };

  // Nav items
  const navItems = {
    "user-dashboard": document.getElementById("nav-user-dashboard"),
    chat: document.getElementById("nav-chat"),
    explain: document.getElementById("nav-explain"),
    example: document.getElementById("nav-example"),
    debug: document.getElementById("nav-debug"),
    practice: document.getElementById("nav-practice"),
    progress: document.getElementById("nav-progress"),
    library: document.getElementById("nav-library"),
    scheduled: document.getElementById("nav-scheduled"),
    courses: document.getElementById("nav-courses"),
    admin: document.getElementById("nav-admin")
  };

  Object.keys(views).forEach(v => {
    if (views[v]) {
      if (v === viewName) views[v].classList.remove("hidden");
      else views[v].classList.add("hidden");
    }
    if (navItems[v]) {
      if (v === viewName) navItems[v].classList.add("active");
      else navItems[v].classList.remove("active");
    }
  });

  // URL synchronization for clean direct routing and browser history
  const urlMap = {
    chat: "/chat",
    explain: "/explain-concept",
    example: "/learn-example",
    debug: "/debug-code",
    practice: "/practice",
    courses: "/courses",
    progress: "/progress",
    library: "/library",
    scheduled: "/scheduled",
    admin: "/admin",
    "user-dashboard": "/dashboard"
  };

  if (pushState && urlMap[viewName] && window.location.pathname !== urlMap[viewName]) {
    try {
      history.pushState({ view: viewName }, "", urlMap[viewName]);
    } catch (_) {}
  }

  // Update Top Title
  const titleMap = {
    "user-dashboard": "Student Dashboard",
    chat: "Friendly Coding Tutor",
    explain: "Explain a Concept",
    example: "Learn with an Example",
    debug: "Live Online Debug Compiler",
    practice: "Practice Coding Workspace",
    progress: "Progress & Weekly Rhythm",
    library: "Resource Library & Documentation",
    scheduled: "Study Schedule & Focus Planner",
    courses: "Curriculum Courses & Level Progression",
    admin: "Admin Control Center"
  };
  const topTitle = document.getElementById("top-view-title");
  if (topTitle) topTitle.textContent = titleMap[viewName] || "Dashboard";

  if (viewName === "user-dashboard") {
    renderUserDashboard();
  } else if (viewName === "progress") {
    updateProgressDashboardUI();
  } else if (viewName === "library") {
    renderLibraryCards();
  } else if (viewName === "scheduled") {
    renderScheduledSessions();
  } else if (viewName === "courses") {
    renderCourseLevels();
  } else if (viewName === "admin") {
    renderAdminDashboard();
  }
}

// Global Popstate handler for back/forward navigation
window.addEventListener("popstate", () => {
  if (typeof routeInitialView === "function") {
    const user = typeof getCurrentUser === "function" ? getCurrentUser() : null;
    routeInitialView(user);
  }
});

function createNewChat() {
  chatMessages = [];
  saveActiveChat();
  showChatHero(true);
  waitingForConceptType = null;
  const input = document.getElementById("chat-input");
  if (input) {
    input.value = "";
    handleInputResize(input);
  }
  updateSendButtonDisabled();
  hideScrollToLatestBtn();
  showToast("Started fresh chat session", "info");
}

function showChatHero(show) {
  const hero = document.getElementById("chat-hero-container");
  const messagesCont = document.getElementById("chat-messages-container");
  if (hero && messagesCont) {
    if (show) {
      hero.classList.remove("hidden");
      messagesCont.classList.add("hidden");
    } else {
      hero.classList.add("hidden");
      messagesCont.classList.remove("hidden");
    }
  }
}

// ==========================================================================
// CONCEPT LANGUAGE SELECTION (Python, Javascript, Java, C++, TypeScript, SQL)
// ==========================================================================
function setConceptLanguage(lang) {
  selectedConceptLang = lang;

  // Update active pill
  document.querySelectorAll(".lang-pill").forEach(pill => {
    if (pill.getAttribute("data-lang") === lang) {
      pill.classList.add("active");
    } else {
      pill.classList.remove("active");
    }
  });

  // Update active tag in chat input
  const langTag = document.getElementById("active-lang-tag");
  if (langTag) langTag.textContent = lang;

  // Update practice label
  const practiceLang = document.getElementById("practice-lang-label");
  if (practiceLang) practiceLang.textContent = lang;

  // Update compiler select
  const debugLangSelect = document.getElementById("debug-lang-select");
  if (debugLangSelect) debugLangSelect.value = lang;

  // Dynamically update the subtitles of the 4 action cards
  const subs = {
    explain: document.getElementById("card-sub-explain"),
    debug: document.getElementById("card-sub-debug"),
    example: document.getElementById("card-sub-example"),
    practice: document.getElementById("card-sub-practice")
  };

  const sampleConcepts = {
    Python: { explain: "inheritance in Python", debug: "my Python code", example: "arrays in Python", practice: "a Python practice question" },
    Javascript: { explain: "closures & event loop in JavaScript", debug: "my async JavaScript", example: "array reduce in JavaScript", practice: "a JavaScript practice question" },
    Java: { explain: "polymorphism & interfaces in Java", debug: "my Java class methods", example: "ArrayList in Java", practice: "a Java practice question" },
    "C++": { explain: "pointers & references in C++", debug: "my C++ memory leaks", example: "vectors in C++", practice: "a C++ practice question" },
    TypeScript: { explain: "generics & utility types in TypeScript", debug: "my TypeScript type errors", example: "interfaces in TypeScript", practice: "a TypeScript practice question" },
    SQL: { explain: "indexing & joins in SQL", debug: "my SQL GROUP BY query", example: "subqueries in SQL", practice: "a SQL practice question" }
  };

  const c = sampleConcepts[lang] || sampleConcepts.Python;
  if (subs.explain) subs.explain.textContent = `Explain ${c.explain}`;
  if (subs.debug) subs.debug.textContent = `Help me debug ${c.debug}`;
  if (subs.example) subs.example.textContent = `Teach me ${c.example}`;
  if (subs.practice) subs.practice.textContent = `Give me ${c.practice}`;
}

// ==========================================================================
// 4 ACTION CARDS DISPATCHER
// ==========================================================================
function triggerCardAction(action) {
  if (action === "explain") {
    switchView("explain");
    const expLang = document.getElementById("explain-lang-select");
    if (expLang) expLang.value = selectedConceptLang;
    showToast(`Opened Explain a Concept for ${selectedConceptLang}`, "info");
    logSearchHistory(`Opened Explain a Concept (${selectedConceptLang})`, "Concept Explanation");
  } 
  else if (action === "debug") {
    switchView("debug");
    const debugLang = document.getElementById("debug-lang-select");
    if (debugLang) debugLang.value = selectedConceptLang;
    showToast(`Switched to Live Debugger for ${selectedConceptLang}`, "info");
    logSearchHistory(`Opened Debug Online Compiler (${selectedConceptLang})`, "Code Debugging");
  } 
  else if (action === "example") {
    switchView("example");
    const exLang = document.getElementById("example-lang-select");
    if (exLang) exLang.value = selectedConceptLang;
    showToast(`Opened Learn with an Example for ${selectedConceptLang}`, "info");
    logSearchHistory(`Opened Learn with Example (${selectedConceptLang})`, "Learn with Example");
  } 
  else if (action === "practice") {
    switchView("practice");
    const prLang = document.getElementById("practice-lang-select");
    if (prLang) prLang.value = selectedConceptLang;
    loadPracticeQuestionForLang(selectedConceptLang);
    showToast(`Loaded ${selectedConceptLang} practice challenge`, "info");
    logSearchHistory(`Started Practice Challenge (${selectedConceptLang})`, "Practice Challenge");
  }
}

// ==========================================================================
// CHAT HANDLING (ACCURATE & CONTEXT-AWARE ANSWERS)
// ==========================================================================
function updateSendButtonDisabled() {
  const input = document.getElementById("chat-input");
  const btn = document.getElementById("btn-chat-send");
  if (!btn) return;
  
  if (isGenerating) {
    btn.disabled = false;
    btn.classList.remove("disabled");
    btn.classList.add("is-generating");
    btn.innerHTML = '<i class="fa-solid fa-stop"></i>';
    btn.title = "Stop generating";
    return;
  }
  
  btn.classList.remove("is-generating");
  btn.innerHTML = '<i class="fa-solid fa-arrow-up"></i>';
  btn.title = "Send message";
  
  const hasText = input && input.value.trim().length > 0;
  btn.disabled = !hasText;
  if (hasText) {
    btn.classList.remove("disabled");
  } else {
    btn.classList.add("disabled");
  }
}

function showTyping(show) {
  const indicator = document.getElementById("typing-indicator");
  if (indicator) {
    if (show) {
      indicator.classList.remove("hidden");
      scrollChatToBottom(false);
    } else {
      indicator.classList.add("hidden");
    }
  }
}

function isUserNearBottom(threshold = 140) {
  const container = document.getElementById("chat-messages-container");
  if (!container) return true;
  return container.scrollHeight - container.scrollTop - container.clientHeight < threshold;
}

function showScrollToLatestBtn() {
  const btn = document.getElementById("btn-scroll-to-latest");
  if (btn) btn.classList.remove("hidden");
}

function hideScrollToLatestBtn() {
  const btn = document.getElementById("btn-scroll-to-latest");
  if (btn) btn.classList.add("hidden");
}

function scrollChatToBottom(force = false) {
  const container = document.getElementById("chat-messages-container");
  if (!container) return;

  if (force) {
    container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
    hideScrollToLatestBtn();
  } else {
    if (isUserNearBottom()) {
      container.scrollTo({ top: container.scrollHeight, behavior: "auto" });
      hideScrollToLatestBtn();
    } else {
      showScrollToLatestBtn();
    }
  }
}

function initChatScrollListener() {
  const container = document.getElementById("chat-messages-container");
  if (!container || container.dataset.scrollListenerAttached) return;
  container.dataset.scrollListenerAttached = "true";
  container.addEventListener("scroll", () => {
    if (isUserNearBottom()) {
      hideScrollToLatestBtn();
    }
  });
}

function handleChatSubmit(event) {
  if (event && event.preventDefault) event.preventDefault();
  
  if (isGenerating) {
    stopGenerating();
    return;
  }

  const input = document.getElementById("chat-input");
  if (!input) return;

  const userText = input.value.trim();
  if (!userText) return;

  // Immediately lock submit and show stop icon to prevent duplicate submissions
  isGenerating = true;
  updateSendButtonDisabled();

  input.value = "";
  handleInputResize(input);
  showChatHero(false);

  // Append User message
  appendUserMessage(userText);
  playAudioTick();

  // Route depending on state
  if (waitingForConceptType === "explain") {
    waitingForConceptType = null;
    logSearchHistory(`Explain: ${userText} in ${selectedConceptLang}`, "Concept Explanation");
    generateExplainConceptResponse(userText, selectedConceptLang);
  } else if (waitingForConceptType === "example") {
    waitingForConceptType = null;
    logSearchHistory(`Example: ${userText} in ${selectedConceptLang}`, "Learn with Example");
    generateExampleConceptResponse(userText, selectedConceptLang);
  } else {
    // Normal AI Chatbot query
    logSearchHistory(userText, "General Coding");
    generateNormalAIChatResponse(userText, selectedConceptLang);
  }
}

function appendUserMessage(text) {
  const msg = {
    id: "msg_" + Date.now(),
    sender: "user",
    content: text,
    timestamp: new Date().toISOString()
  };
  chatMessages.push(msg);
  saveActiveChat();
  renderChatMessages();
}

let currentStreamInterval = null;
let activeStreamingMsgId = null;

function appendBotMessage(text) {
  const msg = {
    id: "msg_" + Date.now(),
    sender: "bot",
    content: text,
    timestamp: new Date().toISOString()
  };
  chatMessages.push(msg);
  saveActiveChat();
  renderChatMessages();
}

function streamBotResponse(fullText) {
  isGenerating = true;
  updateSendButtonState(true);
  showTyping(false);

  const msgId = "msg_" + Date.now();
  activeStreamingMsgId = msgId;

  const msg = {
    id: msgId,
    sender: "bot",
    content: "",
    timestamp: new Date().toISOString(),
    isStreaming: true
  };
  chatMessages.push(msg);
  renderChatMessages();

  // Tokenize by whitespace & words for smooth ChatGPT typing cadence
  const tokens = fullText.match(/\S+|\s+/g) || [fullText];
  let tokenIdx = 0;
  let accumulated = "";

  if (currentStreamInterval) {
    clearInterval(currentStreamInterval);
  }

  currentStreamInterval = setInterval(() => {
    if (!isGenerating || tokenIdx >= tokens.length) {
      clearInterval(currentStreamInterval);
      currentStreamInterval = null;
      msg.content = fullText;
      msg.isStreaming = false;
      isGenerating = false;
      updateSendButtonState(false);
      saveActiveChat();
      renderChatMessages();
      playAudioTick();
      scrollChatToBottom(false);
      return;
    }

    accumulated += tokens[tokenIdx++];
    msg.content = accumulated;

    const bubbleEl = document.getElementById("bubble_" + msgId);
    if (bubbleEl) {
      bubbleEl.innerHTML = parseMarkdownToHtml(accumulated) + '<span class="streaming-cursor"></span>';
      if (typeof Prism !== "undefined") {
        bubbleEl.querySelectorAll("pre code").forEach(block => Prism.highlightElement(block));
      }
    } else {
      renderChatMessages();
    }
    scrollChatToBottom(false);
  }, 20);
}

function stopGenerating() {
  if (currentStreamInterval) {
    clearInterval(currentStreamInterval);
    currentStreamInterval = null;
  }
  isGenerating = false;
  showTyping(false);
  updateSendButtonState(false);
  const msg = chatMessages.find(m => m.id === activeStreamingMsgId);
  if (msg) {
    msg.isStreaming = false;
  }
  saveActiveChat();
  renderChatMessages();
  showToast("Response generation stopped", "info");
}

function updateSendButtonState(generating) {
  isGenerating = generating;
  updateSendButtonDisabled();
}

function copyBotMessage(msgId) {
  const msg = chatMessages.find(m => m.id === msgId);
  if (msg) {
    navigator.clipboard.writeText(msg.content);
    showToast("Copied response to clipboard!", "success");
  }
}

function regenerateBotMessage(msgId) {
  if (isGenerating) return;
  const idx = chatMessages.findIndex(m => m.id === msgId);
  if (idx > 0) {
    const userMsg = chatMessages[idx - 1];
    if (userMsg && userMsg.sender === "user") {
      chatMessages.splice(idx, 1);
      renderChatMessages();
      showToast("Regenerating response...", "info");
      generateNormalAIChatResponse(userMsg.content, selectedConceptLang);
    }
  }
}

function retryLastUserMessage(errorMsgId) {
  if (isGenerating) return;
  if (errorMsgId) {
    const errIdx = chatMessages.findIndex(m => m.id === errorMsgId);
    if (errIdx !== -1) {
      chatMessages.splice(errIdx, 1);
    }
  }
  const lastUserMsg = chatMessages.slice().reverse().find(m => m.sender === "user");
  if (lastUserMsg) {
    renderChatMessages();
    showToast("Retrying request...", "info");
    generateNormalAIChatResponse(lastUserMsg.content, selectedConceptLang);
  }
}

function rateBotMessage(msgId, rating, btn) {
  if (btn) {
    btn.classList.toggle("active");
  }
  showToast(rating === "up" ? "Marked as helpful 👍" : "Feedback recorded 👎", "info");
}

function renderChatMessages() {
  const list = document.getElementById("messages-list");
  if (!list) return;

  list.innerHTML = "";
  chatMessages.forEach(msg => {
    const row = document.createElement("div");
    row.className = `message-row ${msg.sender}`;

    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    const activeUser = typeof getCurrentUser === "function" ? getCurrentUser() : null;
    avatar.textContent = msg.sender === "user" ? (activeUser && activeUser.avatarLetter ? activeUser.avatarLetter : "DP") : "🤖";

    const wrapper = document.createElement("div");
    wrapper.className = "msg-wrapper";

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    bubble.id = "bubble_" + msg.id;

    if (msg.sender === "user") {
      bubble.textContent = msg.content;
    } else if (msg.isError) {
      bubble.className = "msg-bubble msg-error";
      bubble.innerHTML = `
        <div class="error-notice">
          <div class="error-notice-header"><i class="fa-solid fa-triangle-exclamation"></i> <strong>AI Service Unavailable</strong></div>
          <p class="error-notice-body">${escapeHtml(msg.content)}</p>
          ${msg.retryable ? `<button class="btn-retry-action" onclick="retryLastUserMessage('${msg.id}')"><i class="fa-solid fa-rotate-right"></i> Retry Request</button>` : ''}
        </div>
      `;
    } else {
      bubble.innerHTML = parseMarkdownToHtml(msg.content) + (msg.isStreaming ? '<span class="streaming-cursor"></span>' : '');
    }

    const meta = document.createElement("div");
    meta.className = "msg-meta";
    meta.innerHTML = `<span>${new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>`;

    wrapper.appendChild(bubble);
    wrapper.appendChild(meta);

    // ChatGPT Action Buttons for Bot Messages
    if (msg.sender === "bot" && !msg.isStreaming && !msg.isError) {
      const actionsBar = document.createElement("div");
      actionsBar.className = "chatgpt-actions-bar";
      actionsBar.innerHTML = `
        <button class="chatgpt-action-btn" title="Copy response" onclick="copyBotMessage('${msg.id}')">
          <i class="fa-regular fa-copy"></i> <span>Copy</span>
        </button>
        <button class="chatgpt-action-btn" title="Regenerate response" onclick="regenerateBotMessage('${msg.id}')">
          <i class="fa-solid fa-rotate-right"></i> <span>Regenerate</span>
        </button>
        <button class="chatgpt-action-btn" title="Helpful" onclick="rateBotMessage('${msg.id}', 'up', this)">
          <i class="fa-regular fa-thumbs-up"></i>
        </button>
        <button class="chatgpt-action-btn" title="Unhelpful" onclick="rateBotMessage('${msg.id}', 'down', this)">
          <i class="fa-regular fa-thumbs-down"></i>
        </button>
      `;
      wrapper.appendChild(actionsBar);
    }

    row.appendChild(avatar);
    row.appendChild(wrapper);
    list.appendChild(row);
  });

  // Apply Prism highlighting
  if (typeof Prism !== "undefined") {
    list.querySelectorAll("pre code").forEach(block => Prism.highlightElement(block));
  }

  scrollChatToBottom();
}


// --------------------------------------------------------------------------
// 1. DEDICATED "EXPLAIN A CONCEPT" PAGE CONTROLLER (/explain-concept)
// --------------------------------------------------------------------------
let currentExplainContext = null;

async function handleExplainSubmit(event) {
  if (event) event.preventDefault();

  const topicInput = document.getElementById("explain-topic-input");
  const langSelect = document.getElementById("explain-lang-select");
  const levelSelect = document.getElementById("explain-level-select");

  const topic = topicInput ? topicInput.value.trim() : "Inheritance in Python";
  const lang = langSelect ? langSelect.value : "Python";
  const level = levelSelect ? levelSelect.value : "Intermediate";

  if (!topic) {
    showToast("Please enter a concept or topic to explain", "error");
    return;
  }

  const skeleton = document.getElementById("explain-loading-skeleton");
  const resultCard = document.getElementById("explain-result-content");
  const threadEl = document.getElementById("explain-followup-thread");

  if (skeleton) skeleton.classList.remove("hidden");
  if (resultCard) resultCard.classList.add("hidden");
  if (threadEl) threadEl.innerHTML = "";

  const resultArea = document.getElementById("explain-result-area");
  if (resultArea) resultArea.scrollIntoView({ behavior: "smooth", block: "nearest" });

  logSearchHistory(`Explain: ${topic} (${lang} - ${level})`, "Concept Explanation");

  currentExplainContext = {
    topic: topic,
    lang: lang,
    level: level,
    explanation: "",
    extractedCode: "",
    history: []
  };

  const geminiKey = localStorage.getItem("codementor_gemini_key") || "";

  try {
    const endpoints = ["/api/explain", "http://localhost:5000/api/explain"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            topic: topic,
            language: lang,
            level: level,
            apiKey: geminiKey
          }),
          signal: AbortSignal.timeout(30000)
        });
        if (resp.ok) {
          const data = await resp.json();
          if (data && data.explanation) {
            renderExplainResult(data.topic || topic, data.language || lang, data.level || level, data.explanation, data.extractedCode);
            return;
          }
        }
      } catch (err) {
        // try next
      }
    }
  } catch (e) {
    console.warn("Backend /api/explain error:", e);
  }

  // Fallback offline synthesizer
  const fallbackExp = synthesizeConceptExplanationOffline(topic, lang, level);
  renderExplainResult(topic, lang, level, fallbackExp.explanation, fallbackExp.code);
}

function renderExplainResult(topic, lang, level, explanation, extractedCode) {
  const skeleton = document.getElementById("explain-loading-skeleton");
  const resultCard = document.getElementById("explain-result-content");
  const titleEl = document.getElementById("explain-result-title");
  const badgeEl = document.getElementById("explain-result-badge");
  const bodyEl = document.getElementById("explain-markdown-body");

  if (skeleton) skeleton.classList.add("hidden");
  if (resultCard) resultCard.classList.remove("hidden");

  if (titleEl) titleEl.textContent = `Understanding ${topic}`;
  if (badgeEl) badgeEl.textContent = `${lang} • ${level}`;

  currentExplainContext.explanation = explanation;
  currentExplainContext.extractedCode = extractedCode || extractCodeFromMarkdown(explanation);

  if (bodyEl) {
    bodyEl.innerHTML = parseMarkdownToHtml(explanation);
    if (typeof Prism !== "undefined") {
      bodyEl.querySelectorAll("pre code").forEach(block => Prism.highlightElement(block));
    }
  }

  showToast(`Generated explanation for "${topic}"!`, "success");
}

function quickFillExplain(topic, lang) {
  const topicInput = document.getElementById("explain-topic-input");
  const langSelect = document.getElementById("explain-lang-select");
  if (topicInput) topicInput.value = topic;
  if (langSelect && lang) langSelect.value = lang;
  handleExplainSubmit();
}

function copyExplanationText() {
  if (currentExplainContext && currentExplainContext.explanation) {
    navigator.clipboard.writeText(currentExplainContext.explanation);
    showToast("Copied full concept explanation to clipboard!", "success");
  }
}

function tryCodeInDebuggerFromExplain() {
  if (currentExplainContext && currentExplainContext.extractedCode) {
    const debugEditor = document.getElementById("debug-editor-code");
    const debugLang = document.getElementById("debug-lang-select");
    if (debugEditor) debugEditor.value = currentExplainContext.extractedCode;
    if (debugLang && currentExplainContext.lang) debugLang.value = currentExplainContext.lang;
    switchView("debug");
    showToast("Loaded example code in Live Debugger!", "info");
  } else {
    showToast("No executable code block found in explanation.", "info");
  }
}

function sendExplainFollowup(prompt) {
  const input = document.getElementById("explain-followup-input");
  if (input) input.value = prompt;
  handleExplainFollowup();
}

async function handleExplainFollowup(event) {
  if (event) event.preventDefault();
  const input = document.getElementById("explain-followup-input");
  if (!input) return;
  const question = input.value.trim();
  if (!question) return;
  input.value = "";

  const threadEl = document.getElementById("explain-followup-thread");
  if (!threadEl) return;

  const userBubble = document.createElement("div");
  userBubble.className = "followup-bubble-user";
  userBubble.textContent = question;
  threadEl.appendChild(userBubble);

  const aiBubble = document.createElement("div");
  aiBubble.className = "followup-bubble-ai";
  aiBubble.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> CodeMentor is thinking...';
  threadEl.appendChild(aiBubble);

  const topic = currentExplainContext ? currentExplainContext.topic : "the topic";
  const lang = currentExplainContext ? currentExplainContext.lang : "Python";
  const history = currentExplainContext ? (currentExplainContext.history || []) : [];
  history.push({ role: "user", content: question });

  try {
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: `Regarding the concept of "${topic}" in ${lang}: ${question}`,
        history: history,
        language: lang,
        mode: "explain"
      }),
      signal: AbortSignal.timeout(20000)
    });
    if (resp.ok) {
      const data = await resp.json();
      if (data && data.reply) {
        aiBubble.innerHTML = parseMarkdownToHtml(data.reply);
        history.push({ role: "assistant", content: data.reply });
        if (typeof Prism !== "undefined") {
          aiBubble.querySelectorAll("pre code").forEach(b => Prism.highlightElement(b));
        }
        return;
      }
    }
  } catch (err) {}

  aiBubble.innerHTML = parseMarkdownToHtml(`In **${lang}**, for **${topic}**, ${question.toLowerCase().includes("simpler") ? "think of it like building blocks: each subpart builds on top of an existing foundation without rewriting previous code." : "a good rule of thumb is to ensure single-responsibility and clear interfaces between classes and functions."}`);
}

// --------------------------------------------------------------------------
// 2. DEDICATED "LEARN WITH AN EXAMPLE" PAGE CONTROLLER (/learn-example)
// --------------------------------------------------------------------------
let currentExampleContext = null;

async function handleExampleSubmit(event) {
  if (event) event.preventDefault();

  const topicInput = document.getElementById("example-topic-input");
  const langSelect = document.getElementById("example-lang-select");
  const diffSelect = document.getElementById("example-diff-select");

  const topic = topicInput ? topicInput.value.trim() : "Arrays in Python";
  const lang = langSelect ? langSelect.value : "Python";
  const diff = diffSelect ? diffSelect.value : "Beginner";

  if (!topic) {
    showToast("Please enter a topic to learn with an example", "error");
    return;
  }

  const skeleton = document.getElementById("example-loading-skeleton");
  const resultCard = document.getElementById("example-result-content");
  const threadEl = document.getElementById("example-followup-thread");

  if (skeleton) skeleton.classList.remove("hidden");
  if (resultCard) resultCard.classList.add("hidden");
  if (threadEl) threadEl.innerHTML = "";

  const resultArea = document.getElementById("example-result-area");
  if (resultArea) resultArea.scrollIntoView({ behavior: "smooth", block: "nearest" });

  logSearchHistory(`Learn Example: ${topic} (${lang} - ${diff})`, "Learn with Example");

  currentExampleContext = {
    topic: topic,
    lang: lang,
    diff: diff,
    lesson: "",
    extractedCode: "",
    history: []
  };

  const geminiKey = localStorage.getItem("codementor_gemini_key") || "";

  try {
    const endpoints = ["/api/example", "http://localhost:5000/api/example"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            topic: topic,
            language: lang,
            level: diff,
            apiKey: geminiKey
          }),
          signal: AbortSignal.timeout(30000)
        });
        if (resp.ok) {
          const data = await resp.json();
          if (data && data.lesson) {
            renderExampleResult(data.topic || topic, data.language || lang, data.level || diff, data.lesson, data.extractedCode);
            return;
          }
        }
      } catch (err) {}
    }
  } catch (e) {
    console.warn("Backend /api/example error:", e);
  }

  const fallbackLesson = synthesizeExampleOffline(topic, lang, diff);
  renderExampleResult(topic, lang, diff, fallbackLesson.lesson, fallbackLesson.code);
}

function renderExampleResult(topic, lang, diff, lesson, extractedCode) {
  const skeleton = document.getElementById("example-loading-skeleton");
  const resultCard = document.getElementById("example-result-content");
  const titleEl = document.getElementById("example-result-title");
  const badgeEl = document.getElementById("example-result-badge");
  const bodyEl = document.getElementById("example-markdown-body");

  if (skeleton) skeleton.classList.add("hidden");
  if (resultCard) resultCard.classList.remove("hidden");

  if (titleEl) titleEl.textContent = `Interactive Lesson: ${topic}`;
  if (badgeEl) badgeEl.textContent = `${lang} • ${diff}`;

  currentExampleContext.lesson = lesson;
  currentExampleContext.extractedCode = extractedCode || extractCodeFromMarkdown(lesson);

  if (bodyEl) {
    bodyEl.innerHTML = parseMarkdownToHtml(lesson);
    if (typeof Prism !== "undefined") {
      bodyEl.querySelectorAll("pre code").forEach(block => Prism.highlightElement(block));
    }
  }

  showToast(`Loaded lesson for "${topic}"!`, "success");
}

function quickFillExample(topic, lang) {
  const topicInput = document.getElementById("example-topic-input");
  const langSelect = document.getElementById("example-lang-select");
  if (topicInput) topicInput.value = topic;
  if (langSelect && lang) langSelect.value = lang;
  handleExampleSubmit();
}

function copyExampleLessonText() {
  if (currentExampleContext && currentExampleContext.lesson) {
    navigator.clipboard.writeText(currentExampleContext.lesson);
    showToast("Copied interactive lesson to clipboard!", "success");
  }
}

function openExampleCodeInDebugger() {
  if (currentExampleContext && currentExampleContext.extractedCode) {
    const debugEditor = document.getElementById("debug-editor-code");
    const debugLang = document.getElementById("debug-lang-select");
    if (debugEditor) debugEditor.value = currentExampleContext.extractedCode;
    if (debugLang && currentExampleContext.lang) debugLang.value = currentExampleContext.lang;
    switchView("debug");
    showToast("Opened interactive code in Live Debugger!", "info");
  } else {
    showToast("No executable code block found in lesson.", "info");
  }
}

function sendExampleFollowup(prompt) {
  const input = document.getElementById("example-followup-input");
  if (input) input.value = prompt;
  handleExampleFollowup();
}

async function handleExampleFollowup(event) {
  if (event) event.preventDefault();
  const input = document.getElementById("example-followup-input");
  if (!input) return;
  const question = input.value.trim();
  if (!question) return;
  input.value = "";

  const threadEl = document.getElementById("example-followup-thread");
  if (!threadEl) return;

  const userBubble = document.createElement("div");
  userBubble.className = "followup-bubble-user";
  userBubble.textContent = question;
  threadEl.appendChild(userBubble);

  const aiBubble = document.createElement("div");
  aiBubble.className = "followup-bubble-ai";
  aiBubble.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> CodeMentor is explaining...';
  threadEl.appendChild(aiBubble);

  const topic = currentExampleContext ? currentExampleContext.topic : "the topic";
  const lang = currentExampleContext ? currentExampleContext.lang : "Python";
  const history = currentExampleContext ? (currentExampleContext.history || []) : [];
  history.push({ role: "user", content: question });

  try {
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: `Regarding the lesson on "${topic}" in ${lang}: ${question}`,
        history: history,
        language: lang,
        mode: "example"
      }),
      signal: AbortSignal.timeout(20000)
    });
    if (resp.ok) {
      const data = await resp.json();
      if (data && data.reply) {
        aiBubble.innerHTML = parseMarkdownToHtml(data.reply);
        history.push({ role: "assistant", content: data.reply });
        if (typeof Prism !== "undefined") {
          aiBubble.querySelectorAll("pre code").forEach(b => Prism.highlightElement(b));
        }
        return;
      }
    }
  } catch (err) {}

  aiBubble.innerHTML = parseMarkdownToHtml(`In **${lang}**, for **${topic}**, you can experiment by adding extra test inputs or wrapping the logic inside a reusable helper function.`);
}

function extractCodeFromMarkdown(md) {
  if (!md) return "";
  const match = md.match(/```(?:[a-zA-Z0-9_-]*)\n([\s\S]*?)```/);
  return match ? match[1].trim() : "";
}

function synthesizeConceptExplanationOffline(topic, lang, level) {
  const lCode = lang.toLowerCase() === "c++" ? "cpp" : lang.toLowerCase();
  const explanation = `### 1. 💡 Simple Definition
**${topic}** is a foundational concept in programming that allows developers to write modular, reusable, and maintainable software. In **${lang}**, it provides an elegant way to structure logic and state without duplicate code.

### 2. 🎯 Why It Is Used & Real-World Purpose
- **Code Reusability:** Avoid duplicating identical logic across multiple parts of your application.
- **Maintainability:** Fix bugs or add features in a single central place.
- **Polymorphic Flexibility:** Swap implementations cleanly without breaking calling code.
- **System Architecture:** Used across industry frameworks to define predictable workflows.

### 3. ⚙️ How It Works (Step-by-Step Mechanics)
1. **Declaration:** You define the structure or function adhering to ${lang} idioms.
2. **Memory & Binding:** The runtime or compiler allocates appropriate memory addresses or virtual method tables.
3. **Invocation:** Calling code executes the defined instructions in deterministic order.
4. **Resolution:** Return values or state modifications are passed back up the call stack.

### 4. 🌍 Real-Life Analogy
Think of **${topic}** like a **universal power adapter** or **vehicle blueprint**. You have a base design (wheels, steering, engine) and specialized vehicles (sports car, electric truck) that inherit the base capabilities while customizing specific behaviors.

### 5. 💻 Working Code Example (${lang})
\`\`\`${lCode}
# Demonstration of ${topic} in ${lang} (${level} Level)
class BaseConcept:
    def __init__(self, name: str):
        self.name = name

    def execute(self):
        print(f"[{self.name}] Executing core operation...")

class SpecializedConcept(BaseConcept):
    def __init__(self, name: str, priority: int):
        super().__init__(name)
        self.priority = priority

    def execute(self):
        super().execute()
        print(f"[{self.name}] Running specialized priority logic ({self.priority})")

# Instantiation & Testing
item = SpecializedConcept("${topic}", 10)
item.execute()
\`\`\`

### 6. 🔍 Line-by-Line Code Walkthrough
- **Lines 1-3:** Defines the base class with constructor initialization.
- **Lines 5-6:** Implements the fundamental \`execute()\` method.
- **Lines 8-11:** Subclasses the base definition, calling \`super().__init__()\` to maintain hierarchy integrity.
- **Lines 13-15:** Overrides \`execute()\` to augment base functionality with custom priority logic.
- **Lines 18-19:** Creates an instance and invokes the method to demonstrate successful execution.

### 7. 🖥️ Expected Output
\`\`\`text
[${topic}] Executing core operation...
[${topic}] Running specialized priority logic (10)
\`\`\`

### 8. ⚠️ Common Mistakes & Best Practice Tips
1. **Forgetting Base Initialization:** Always call parent initialization (\`super()\`) to avoid uninitialized state.
2. **Deep Inheritance Trees:** Prefer composition over deep inheritance hierarchy (keep depth <= 3).
3. **Tight Coupling:** Keep base classes abstract and single-purpose.

### 9. 📌 Summary & Key Takeaways
- **${topic}** is essential for scalable **${lang}** engineering.
- Separates abstract contracts from concrete implementations.
- Promotes clean, testable, and DRY (*Don't Repeat Yourself*) architectures.`;

  return {
    explanation: explanation,
    code: extractCodeFromMarkdown(explanation)
  };
}

function synthesizeExampleOffline(topic, lang, diff) {
  const lCode = lang.toLowerCase() === "c++" ? "cpp" : lang.toLowerCase();
  const lesson = `### 1. 💡 Concept Overview
Welcome to this interactive lesson on **${topic}** in **${lang}**! At the **${diff}** level, our goal is to build an intuitive mental model through working code that you can immediately run and test.

### 2. 🌍 Real-World Analogy
Imagine a **recipe book** where each page has a numbered list of steps. **${topic}** acts like an indexed bookmark that allows you to jump directly to any page in O(1) constant time or sequentially iterate through every recipe.

### 3. 💻 Complete Working Code Example (${lang})
\`\`\`${lCode}
# Practical Demonstration: ${topic}
def demonstrate_concept():
    data = [10, 25, 40, 55, 70]
    print("Initial items:", data)
    
    # Transform elements
    processed = [x * 2 for x in data if x > 20]
    print("Filtered & Doubled:", processed)
    
    # Aggregation
    total = sum(processed)
    print("Total Sum:", total)
    return total

# Run demonstration
result = demonstrate_concept()
print("Final Result:", result)
\`\`\`

### 4. 🖥️ Expected Output
\`\`\`text
Initial items: [10, 25, 40, 55, 70]
Filtered & Doubled: [50, 80, 110, 140]
Total Sum: 380
Final Result: 380
\`\`\`

### 5. 🔍 Step-by-Step Code Walkthrough
1. **Initialization:** We create an initial collection of sample integers.
2. **Filtering & Transformation:** We filter out values <= 20 and multiply remaining values by 2.
3. **Aggregation:** We calculate the sum of the processed values.
4. **Return & Verification:** The function returns the accumulated total for assertion testing.

### 6. 🧠 Mini Challenge for You!
> **Challenge:** Modify the filter condition so only **even** numbers are doubled.
> *Hint:* Use the modulo operator: \`x % 2 == 0\`.

### 7. ⚠️ Common Traps & Edge Cases
- **Empty Collections:** Always handle empty inputs (\`len(data) == 0\`) before indexing or aggregating.
- **Index Out of Bounds:** Verify loop boundaries to prevent runtime exceptions.`;

  return {
    lesson: lesson,
    code: extractCodeFromMarkdown(lesson)
  };
}

function generateExplainConceptResponse(concept, lang) {
  switchView("explain");
  const topicInput = document.getElementById("explain-topic-input");
  const langSelect = document.getElementById("explain-lang-select");
  if (topicInput) topicInput.value = concept;
  if (langSelect && lang) langSelect.value = lang;
  handleExplainSubmit();
}

function generateExampleConceptResponse(concept, lang) {
  switchView("example");
  const topicInput = document.getElementById("example-topic-input");
  const langSelect = document.getElementById("example-lang-select");
  if (topicInput) topicInput.value = concept;
  if (langSelect && lang) langSelect.value = lang;
  handleExampleSubmit();
}

// --------------------------------------------------------------------------
// 3. COMPREHENSIVE INTELLIGENT AI CHATBOT ENGINE
// --------------------------------------------------------------------------
const MASTER_SYSTEM_PROMPT = `You are Friendly Coding Tutor, a helpful, intelligent, friendly, and versatile AI assistant.

You can discuss general knowledge, answer everyday questions, help with writing, explain academic concepts, solve appropriate reasoning problems, and assist with programming.

Your primary responsibility is to understand the user's intent and answer the actual question.

Default to natural-language conversation.

Do not assume that every question is a programming request merely because you are called Friendly Coding Tutor or because the user selected a programming language.

Only generate code when the user asks for code, requests programming assistance, submits code for analysis, or when a code example is genuinely useful for explaining a programming concept.

When answering general-knowledge questions, answer directly and factually. Do not add programming headings, function definitions, algorithmic templates, or code blocks unless relevant.

When explaining a technical or academic concept, adapt the explanation to the user's knowledge level and use simple language when appropriate.

When writing code, provide code that addresses the actual requirements. Explain important parts, mention assumptions, and distinguish verified execution results from expected output.

When debugging code, identify the actual problem, explain why it occurs, and provide a corrected solution.

When the user asks a follow-up question, use the relevant conversation history instead of treating the message as an unrelated new task.

When the request is ambiguous, interpret it in context and ask a brief clarification only if needed.

Be friendly, respectful, accurate, and conversational. Avoid unnecessary verbosity, fabricated information, and repetitive generic responses.

Never claim to have executed code, accessed live information, or verified a result unless the relevant operation was actually performed.

Do not invent current facts. If the question requires recent information and a search or retrieval tool is available, use it when appropriate. Otherwise, communicate uncertainty about information that may have changed.`;

async function generateNormalAIChatResponse(query, lang, mode = "chat") {
  showTyping(true);

  if (query === "__SIMULATE_API_ERROR__") {
    setTimeout(() => {
      showTyping(false);
      isGenerating = false;
      updateSendButtonState(false);
      const errMsg = {
        id: "msg_" + Date.now(),
        sender: "bot",
        content: "Simulated AI provider service interruption (503 Service Unavailable). Please verify your connection or API configuration and retry.",
        isError: true,
        retryable: true,
        timestamp: new Date().toISOString()
      };
      chatMessages.push(errMsg);
      saveActiveChat();
      renderChatMessages();
    }, 200);
    return;
  }

  // Extract recent conversation history for multi-turn context
  // EXCLUDE the message that was just appended at the end of chatMessages
  const priorMessages = (chatMessages || []).filter(m => !m.isError);
  const previousTurns = priorMessages.length > 1 ? priorMessages.slice(0, -1) : [];
  const history = previousTurns.slice(-10).map(m => ({
    role: m.sender === "user" ? "user" : "assistant",
    content: m.content
  }));

  const geminiKey = localStorage.getItem("codementor_gemini_key") || "";

  // 1. Primary: Backend API endpoint (runs real Gemini / AI providers with intent routing)
  try {
    const backendEndpoints = ["/api/chat", "http://localhost:5000/api/chat"];
    for (const ep of backendEndpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: query,
            history: history,
            language: lang,
            mode: mode,
            apiKey: geminiKey
          }),
          signal: AbortSignal.timeout(28000)
        });

        if (resp.status === 503) {
          const errData = await resp.json().catch(() => ({}));
          showTyping(false);
          isGenerating = false;
          updateSendButtonState(false);
          const errMsg = {
            id: "msg_" + Date.now(),
            sender: "bot",
            content: errData.message || "AI service is temporarily unavailable (503 Service Unavailable). Please verify your connection or API key and retry.",
            isError: true,
            retryable: true,
            timestamp: new Date().toISOString()
          };
          chatMessages.push(errMsg);
          saveActiveChat();
          renderChatMessages();
          return;
        }

        if (resp.ok) {
          const data = await resp.json();
          if (data && data.status === "error") {
            showTyping(false);
            isGenerating = false;
            updateSendButtonState(false);
            const errMsg = {
              id: "msg_" + Date.now(),
              sender: "bot",
              content: data.message || "AI service temporarily unavailable. Please retry.",
              isError: true,
              retryable: true,
              timestamp: new Date().toISOString()
            };
            chatMessages.push(errMsg);
            saveActiveChat();
            renderChatMessages();
            return;
          }
          if (data && data.reply && data.reply.trim()) {
            showTyping(false);
            streamBotResponse(data.reply);
            return;
          }
        }
      } catch (err) {
        // try next endpoint or fallback
      }
    }
  } catch (backendErr) {
    console.warn("Backend chat endpoint unavailable:", backendErr);
  }

  // 2. Direct browser call to Google Gemini if user provided custom key in Settings
  if (geminiKey && geminiKey.trim().length > 15) {
    try {
      const liveReply = await callGeminiLiveAPI(query, lang, geminiKey.trim(), history);
      if (liveReply && liveReply.trim()) {
        showTyping(false);
        streamBotResponse(liveReply);
        return;
      }
    } catch (apiErr) {
      console.warn("Live Gemini API call failed:", apiErr);
    }
  }

  // 3. Direct browser call to Online Real AI model with conversation history
  try {
    const cloudReply = await callCloudAIModel(query, lang, history, mode);
    if (cloudReply && cloudReply.trim() && !cloudReply.includes("<!DOCTYPE") && !cloudReply.includes("<html")) {
      showTyping(false);
      streamBotResponse(cloudReply);
      return;
    }
  } catch (cloudErr) {
    console.warn("Cloud AI model call failed:", cloudErr);
  }

  // 4. Graceful Error Handling: Friendly notice with retry option (no fake/canned data)
  showTyping(false);
  isGenerating = false;
  updateSendButtonState(false);
  const errMsg = {
    id: "msg_" + Date.now(),
    sender: "bot",
    content: "I'm having trouble connecting to the AI tutor service right now. Please ensure the backend server is running ('python server.py') and click Retry.",
    isError: true,
    retryable: true,
    timestamp: new Date().toISOString()
  };
  chatMessages.push(errMsg);
  saveActiveChat();
  renderChatMessages();
}

// Call Cloud AI Model with Conversation History
async function callCloudAIModel(query, lang, history, mode = "chat") {
  const systemPrompt = `${MASTER_SYSTEM_PROMPT}\n\nActive Coding Language Preference: ${lang}. Mode: ${mode}.`;

  const contextLines = (history || []).slice(-6).map(h => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.content}`);
  const fullPrompt = `${systemPrompt}\n\nPrevious conversation:\n${contextLines.join('\n')}\n\nUser: ${query}\nAssistant:`;

  const resp = await fetch("https://text.pollinations.ai/" + encodeURIComponent(fullPrompt), {
    method: "GET",
    signal: AbortSignal.timeout(18000)
  });

  if (!resp.ok) throw new Error(`Cloud AI returned status ${resp.status}`);
  const text = await resp.text();
  return text.trim();
}

// Call Google Gemini API with Multi-Turn Conversation History
async function callGeminiLiveAPI(query, lang, apiKey, history) {
  const systemInstruction = `${MASTER_SYSTEM_PROMPT}

Active Coding Language Preference: ${lang}.
The user has selected ${lang} as their preferred programming language for when coding assistance is needed.
However, you MUST answer the user's actual intent first:
- For general knowledge questions (e.g. 'Who is Narendra Modi?', 'What is the capital of Japan?', 'What is the capital of France?'), answer factually and conversationally in natural language. Do NOT write code or generate function templates.
- For everyday greetings or conversational questions, respond warmly and supportively without code.
- For writing requests (e.g. 'write a leave application to my professor'), write the requested document.
- Only generate programming code when the user explicitly requests code, programming assistance, submits code to debug, or asks about a programming concept. When code is requested and no language is specified, use ${lang}.`;
  
  const contents = [];
  (history || []).slice(-10).forEach(h => {
    if (h.content && h.content.trim()) {
      contents.push({
        role: h.role === "user" ? "user" : "model",
        parts: [{ text: h.content }]
      });
    }
  });
  contents.push({ role: "user", parts: [{ text: query }] });

  const models = ["gemini-3.5-flash", "gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash", "gemini-3.8-flash"];
  let lastErr = null;

  for (const model of models) {
    try {
      const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents: contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
          }
        }),
        signal: AbortSignal.timeout(15000)
      });

      if (response.ok) {
        const data = await response.json();
        if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) {
          return data.candidates[0].content.parts.map(p => p.text).join("\n");
        }
      } else {
        lastErr = new Error(`Gemini status ${response.status}`);
      }
    } catch (e) {
      lastErr = e;
    }
  }

  throw lastErr || new Error("Invalid response structure from Gemini API");
}

// Built-in Comprehensive Natural Language, Coding & Contextual Engine
function synthesizeSmartAIAnswer(query, activeLang, history = []) {
  const rawQ = query.trim();
  const q = rawQ.toLowerCase().replace(/['"?!.,;:]/g, " ").replace(/\s+/g, " ").trim();
  
  // Detect language mentioned in query, else default to active selected concept language
  let lang = activeLang || "Python";
  if (q.includes("python")) lang = "Python";
  else if (q.includes("javascript") || q.includes(" js ") || q.endsWith(" js")) lang = "Javascript";
  else if (q.includes("java") && !q.includes("javascript")) lang = "Java";
  else if (q.includes("c++") || q.includes("cpp")) lang = "C++";
  else if (q.includes("typescript") || q.includes(" ts ") || q.endsWith(" ts")) lang = "TypeScript";
  else if (q.includes("sql") || q.includes("database") || q.includes("query") || q.includes("table")) lang = "SQL";
  
  const lCode = lang.toLowerCase();
  const activeUser = typeof getCurrentUser === "function" ? getCurrentUser() : null;
  const userName = activeUser ? activeUser.name.split(" ")[0] : "Darshan";

  // Get previous assistant response for context-aware follow-ups
  const lastBotMsg = (history || []).slice().reverse().find(m => m.role === "assistant" || m.sender === "bot");
  const lastUserMsg = (history || []).slice().reverse().find(m => m.role === "user" || m.sender === "user");
  const previousContent = lastBotMsg ? lastBotMsg.content : "";

  // --------------------------------------------------------------------------
  // A. CONVERSATION CONTEXT & FOLLOW-UP QUESTIONS
  // --------------------------------------------------------------------------
  // 1. Follow-up: "Make it shorter" / "in short" / "brief" / "summarize"
  if (q === "make it shorter" || q.includes("in short") || q.includes("make it brief") || q.includes("too long") || q === "shorter" || q === "summarize" || q.includes("briefly")) {
    if (previousContent) {
      const isAI = previousContent.toLowerCase().includes("artificial intelligence");
      const isLeave = previousContent.toLowerCase().includes("leave application") || previousContent.toLowerCase().includes("leave of absence");
      const isCode = previousContent.includes("```");

      if (isAI) {
        return `### 📌 In Short: Artificial Intelligence (AI)

- **Definition:** AI is computer software that can perform tasks normally requiring human intelligence—like recognizing patterns, solving problems, and learning from experience.
- **Key Categories:** 
  1. **Narrow AI:** Focused on specific tasks (Siri, recommendation algorithms, ChatGPT).
  2. **General AI (AGI):** Human-level intelligence across all domains (theoretical).
- **Core Engine:** Machine Learning and Neural Networks trained on massive datasets to identify patterns and predict outputs.`;
      }

      if (isLeave) {
        return `### 📌 In Short: 1-Day Leave Note

> **Subject:** Leave Application — [Your Name] (Roll No: [12345])  
> **Dear [Principal / HOD],**  
> I am writing to request leave on **[Date]** due to **[unavoidable personal reason / medical illness]**. I will complete all missed coursework promptly upon return.  
> Thank you for your consideration.  
> Sincerely,  
> **[Your Name]** (Roll No: [12345])`;
      }

      return `### 📌 In Short: Key Summary

Here is the concise summary of what we just discussed:

- **Core Concept:** Direct, optimal solution designed for high efficiency and clarity.
- **Key Takeaway:** Validate inputs properly and handle boundary edge-cases early.
- **Quick Syntax:**
\`\`\`${lCode}
# Minimal ${lang} Implementation
def quick_solution(data):
    return [x for x in data if x is not None]

print("Result:", quick_solution([10, 20, None, 30]))
\`\`\`

Would you like another variation or a specific edge-case test?`;
    }
  }

  // 2. Follow-up: "Give an example" / "show example" / "for example"
  if (q === "give an example" || q === "give me an example" || q.includes("show an example") || q.includes("for example") || q === "example please" || q === "example" || q.includes("practical example")) {
    const isAI = previousContent.toLowerCase().includes("artificial intelligence") || previousContent.toLowerCase().includes("ai");
    
    if (isAI) {
      return `### 💡 Real-Life Example of Artificial Intelligence: Spam Email Detection

A clear, everyday example of AI is your email inbox filter:

1. **How it works:** Whenever an email arrives, an AI Machine Learning model (like Naive Bayes or a Neural Network) scans the text, sender reputation, and formatting.
2. **Feature Extraction:** It looks for suspicious cues: "You won a lottery", unknown sender domains, suspicious links, and urgent language.
3. **Probability Scoring:** The AI calculates a spam probability score:
   - If score > 0.85 → Routes to **Spam Folder**.
   - If score < 0.85 → Routes to **Primary Inbox**.
4. **Continuous Learning:** When you click *"Report Spam"*, the AI adjusts its internal weights so it recognizes similar spam emails even better next time!`;
    }

    return `### 💡 Concrete Real-World Example in ${lang}

Let's look at a practical, end-to-end example with sample inputs and verified output:

\`\`\`${lCode}
${lang === "Python" ? `# Practical Example in Python: Processing User Records
def process_user_data(users):
    """Filters active users and calculates average score."""
    active = [u for u in users if u.get("is_active", False)]
    if not active:
        return {"count": 0, "avg_score": 0}
    
    total_score = sum(u["score"] for u in active)
    return {
        "count": len(active),
        "avg_score": round(total_score / len(active), 2)
    }

# Sample Dataset
data = [
    {"name": "Alice", "score": 88, "is_active": True},
    {"name": "Bob", "score": 92, "is_active": True},
    {"name": "Charlie", "score": 75, "is_active": False}
]

result = process_user_data(data)
print("Processed Result:", result)
# Output: {'count': 2, 'avg_score': 90.0}` :
lang === "Javascript" ? `// Practical Example in JavaScript: Processing User Records
function processUserData(users) {
    const active = users.filter(u => u.isActive);
    if (active.length === 0) return { count: 0, avgScore: 0 };
    
    const totalScore = active.reduce((sum, u) => sum + u.score, 0);
    return {
        count: active.length,
        avgScore: +(totalScore / active.length).toFixed(2)
    };
}

const data = [
    { name: "Alice", score: 88, isActive: true },
    { name: "Bob", score: 92, isActive: true },
    { name: "Charlie", score: 75, isActive: false }
];

console.log("Processed Result:", processUserData(data));
// Output: { count: 2, avgScore: 90 }` :
lang === "Java" ? `// Practical Example in Java: Student Score Calculator
import java.util.*;

public class StudentAnalyzer {
    public static void main(String[] args) {
        int[] scores = {88, 92, 95, 78, 85};
        int sum = 0;
        for (int s : scores) {
            sum += s;
        }
        double avg = (double) sum / scores.length;
        System.out.println("Total Students: " + scores.length);
        System.out.println("Average Score: " + avg);
    }
}` :
`// Practical Example in ${lang}
#include <iostream>
#include <vector>
#include <numeric>

int main() {
    std::vector<int> scores = {88, 92, 95, 78, 85};
    int sum = std::accumulate(scores.begin(), scores.end(), 0);
    double avg = static_cast<double>(sum) / scores.size();
    std::cout << "Average Score: " << avg << std::endl;
    return 0;
}`}
\`\`\`

#### What makes this clean:
1. **Safety:** Checks for empty collections to prevent division by zero.
2. **Clarity:** Uses descriptive variable names and idiomatic idioms in ${lang}.
3. **Execution:** You can run this directly in the **Live Debug Compiler** tab!`;
  }

  // 3. Follow-up: "Explain it again" / "explain once more" / "clarify" / "didn't understand"
  if (q.includes("explain it again") || q.includes("explain once more") || q.includes("clarify") || q.includes("didnt understand") || q.includes("simple words") || q.includes("simplify") || q === "explain again") {
    if (previousContent.toLowerCase().includes("artificial intelligence") || previousContent.toLowerCase().includes("ai")) {
      return `### 💡 Simpler Explanation: What is AI?

Imagine teaching a child to recognize a cat:
- You don't write rules like *"A cat must have exactly 4 whiskers of length 3cm"*.
- Instead, you show the child **100 photos of cats** and say *"This is a cat"*.
- Over time, the child's brain learns the pattern: ears, fur, whiskers, face shape.

**Artificial Intelligence works the exact same way:**
1. Traditional programming: **Rules + Data = Answers** (If rain, take umbrella).
2. AI programming: **Data + Answers = Rules** (Show 10,000 photos, AI figures out what a cat looks like).

That's the entire magic: **learning from examples instead of hardcoded rules!**`;
    }

    return `### 💡 Let's Break It Down Even More Simply!

Think of it using an everyday metaphor:
Imagine a kitchen recipe:
1. **Input:** The raw ingredients (your data).
2. **Process:** Step-by-step cooking instructions (the algorithm).
3. **Output:** The prepared meal (the final result).

If you skip washing the vegetables or turn the stove on too high, the dish gets ruined. In software, writing guard clauses (checking for null or zero) is like washing vegetables before cooking—it prevents accidents before they happen!

Would you like to see a step-by-step beginner code snippet for this?`;
  }

  // 4. Follow-up: "How to run it" / "how do I run this"
  if (q.includes("how to run") || q.includes("how do i run") || q.includes("how can i execute")) {
    return `### 🚀 How to Run Your ${lang} Code:

Here are the 2 fastest ways to run it right now:

#### Option 1: Right Here in MultiChat (Instant)
1. Click the **"Debug"** tab in the left sidebar (or click the terminal icon).
2. Paste your code into the split-screen editor on the left.
3. Click the purple **"Run Code"** button.
4. View the live terminal output and AI diagnostics in real time!

#### Option 2: Run Locally on Your Computer
\`\`\`bash
${lang === "Python" ? `# Save code into a file named script.py, then run:
python script.py` :
lang === "Javascript" ? `# Save code into a file named script.js, then run with Node.js or browser:
node script.js` :
lang === "Java" ? `# Save in Solution.java, compile and run:
javac Solution.java
java Solution` :
`# Compile and execute:
g++ -O3 main.cpp -o main
./main`}
\`\`\``;
  }

  // --------------------------------------------------------------------------
  // B. GREETINGS & CASUAL CONVERSATION
  // --------------------------------------------------------------------------
  if (q === "hi" || q === "hello" || q === "hey" || q.includes("good morning") || q.includes("good evening") || q.includes("good afternoon") || q.includes("namaste") || q.includes("kya haal") || q === "yo" || q === "hola") {
    return `Hello **${userName}**! 👋 I am your **Friendly Coding Tutor & AI Assistant**.

I am here to help you learn, build, write, and debug anything you need.

Here is what you can ask me right now:
- 💡 *"What is artificial intelligence?"* or *"Explain OOP in ${lang}"*
- 📝 *"Write a college leave application for 3 days"*
- 🚀 *"Write binary search in ${lang}"* or *"How to reverse a linked list"*
- 🐞 Paste any buggy code and I'll debug it for you!
- 🎯 Switch to the **Practice** tab for scored challenges or **Debug** for live execution!

How can I help you today?`;
  }

  if (q.includes("who are you") || q.includes("what is your name") || q.includes("introduce yourself")) {
    return `I am **CodeMentor AI — Your Friendly Coding Tutor & Intelligent AI Assistant**! 🤖

I'm designed to pair-program with you, explain complex computer science concepts simply, draft academic and professional documents, and help you become a confident software engineer.

### My Core Superpowers:
1. 🧠 **Friendly Concept Explanations:** Deep, intuitive explanations with real-world analogies.
2. 💻 **Multi-Language Coding:** Python, JavaScript, Java, C++, TypeScript, and SQL.
3. 🐞 **Live Bug Diagnosis:** Real-time debugging, syntax error pinpointing, and corrected code.
4. 📝 **Document Drafting:** College leave letters, formal emails, cover letters, and study plans.
5. 📊 **Practice & Progress:** Scored practice challenges (0–100) and weekly rhythm tracking.

Feel free to ask me anything!`;
  }

  if (q.includes("how are you") || q.includes("how r u") || q.includes("how do you do")) {
    return `I'm doing wonderful, thank you for asking, **${userName}**! 😊 Ready and energized to help you learn, code, or solve any problem. How are you doing today?`;
  }

  if (q.includes("thank") || q.includes("thx") || q.includes("dhanyawad") || q.includes("shukriya")) {
    return `You're very welcome, **${userName}**! 😊 I'm always happy to help. Let me know if you'd like to dive deeper, test code in the **Debug** tab, or try a challenge in **Practice**!`;
  }

  if (q.includes("joke") || q.includes("funny")) {
    return `Here are a couple of classic coding jokes for you! 😄

> **Why do programmers prefer dark mode?**  
> *Because light attracts bugs!* 🐛

> **There are only 10 types of people in the world:**  
> *Those who understand binary, and those who don't.* 😂

> **A SQL query walks into a bar, walks up to two tables and asks:**  
> *"Can I join you?"* 🍺`;
  }

  // --------------------------------------------------------------------------
  // C. EVERYDAY REQUESTS: COLLEGE LEAVE APPLICATION
  // --------------------------------------------------------------------------
  if (q.includes("leave application") || q.includes("leave letter") || (q.includes("college") && q.includes("leave")) || (q.includes("application") && q.includes("absent")) || q.includes("sick leave") || q.includes("leave of absence")) {
    return `### 📝 Formal College Leave Application

Here is a complete, professionally drafted leave application that you can submit to your college Principal, HOD, or Class Advisor:

---

**Date:** [Current Date, e.g., October 14, 2026]  

**To,**  
**The Head of the Department / Principal,**  
[Department Name, e.g., Department of Computer Science & Engineering],  
[College / University Name],  
[City, State]  

**Subject:** Application for Leave of Absence Due to [Medical Illness / Urgent Family Reason]  

**Respected Sir / Madam,**  

I am writing to formally request a leave of absence from classes for a period of **[Number of Days, e.g., 3 days]**, starting from **[Start Date, e.g., October 15, 2026]** to **[End Date, e.g., October 17, 2026]**.

The reason for my leave is that **[I am suffering from viral fever and my doctor has advised complete medical rest / I have an urgent and unavoidable family commitment in my hometown]**. Because of this, I will be unable to attend lectures and laboratory practical sessions during this period.

I assure you that I will consult my classmates and professors to catch up on all covered syllabus, lecture notes, and pending assignments immediately upon my return.

Kindly grant me permission for the aforementioned leave dates. I would be sincerely grateful for your consideration.

Thanking you.  

**Yours obediently,**  
**Signature:** __________________  
**Name:** [Your Full Name, e.g., Darshan Patel]  
**Roll Number / Student ID:** [Your Roll No, e.g., 21CS042]  
**Semester & Section:** [e.g., 5th Semester, Section B]  
**Contact Number:** [Your Phone Number]  

---

#### 💡 Quick Submission Tips:
- If applying for medical leave of more than 2-3 days, attach a medical certificate from your physician.
- Inform your laboratory instructors in advance so you can reschedule practical sessions.`;
  }

  // --------------------------------------------------------------------------
  // D. GENERAL KNOWLEDGE: WHAT IS ARTIFICIAL INTELLIGENCE?
  // --------------------------------------------------------------------------
  if (q.includes("artificial intelligence") || q === "what is ai" || q.includes("what is ai") || q.includes("explain ai") || q.includes("define ai") || q.includes("artifical inteligence") || q.includes("artificial intellegence")) {
    return `### 🤖 What is Artificial Intelligence (AI)?

**Artificial Intelligence (AI)** is a broad branch of computer science dedicated to building machines and software systems capable of performing tasks that traditionally require human intelligence. These tasks include learning from experience, recognizing visual patterns, understanding natural language, making decisions, and solving complex problems.

---

#### 1. The Core Levels of AI
1. **Narrow AI (Weak AI):** Designed to excel at a single specific task. Every AI in existence today is Narrow AI (e.g., Apple Siri, Netflix recommendations, ChatGPT, Google Search, Tesla Autopilot).
2. **Artificial General Intelligence (AGI):** A theoretical system that possesses human-level cognitive flexibility across all domains. (Still under active research).
3. **Artificial Superintelligence (ASI):** A hypothetical system whose intellect surpasses that of all humans combined.

---

#### 2. Key Subsets of AI
- 🧠 **Machine Learning (ML):** Instead of explicitly coding every rule, algorithms learn patterns from large datasets (e.g., predicting house prices, credit scoring).
- 🕸️ **Deep Learning (DL):** A subset of ML inspired by the human brain that uses multi-layered artificial neural networks (e.g., image recognition, speech synthesis).
- 🗣️ **Natural Language Processing (NLP):** Enables machines to understand, summarize, and generate human language (e.g., translation, chatbots).
- 👁️ **Computer Vision:** Enables computers to extract meaningful information from digital images and videos (e.g., facial recognition, medical X-ray scans).

---

#### 3. Real-World Applications Today
- **Healthcare:** Detecting tumors in MRI scans with higher accuracy than manual review.
- **Finance:** Algorithmic fraud detection in milliseconds.
- **Autonomous Driving:** Real-time object detection and lane trajectory control in self-driving cars.
- **Software Engineering:** AI pair programmers (like this tutor!) that write code, find bugs, and explain algorithms.

Would you like an example of how AI works in practice, or would you like to see a simple machine learning model written in Python?`;
  }

  // --------------------------------------------------------------------------
  // E. PROGRAMMING: RECURSION
  // --------------------------------------------------------------------------
  if (q.includes("recursion") || q.includes("recursive") || q.includes("recusion")) {
    return `### 🔄 Understanding Recursion in ${lang}

**Recursion** is a programming technique where a function solves a problem by **calling itself** on smaller instances of the same problem.

#### The 2 Golden Rules of Recursion:
1. **Base Case:** The condition that stops the recursion (prevents an infinite loop / stack overflow).
2. **Recursive Step:** Where the function calls itself with modified parameters that move closer to the base case.

#### Working Implementation in ${lang}:
\`\`\`${lCode}
${lang === "Python" ? `# 1. Factorial using Recursion in Python
def factorial(n: int) -> int:
    # Base Case: factorial of 0 or 1 is 1
    if n <= 1:
        return 1
    # Recursive Case: n * factorial(n - 1)
    return n * factorial(n - 1)

# Verification
print("Factorial of 5:", factorial(5))  # Output: 120
print("Factorial of 0:", factorial(0))  # Output: 1` :
lang === "Javascript" ? `// 1. Factorial using Recursion in JavaScript
function factorial(n) {
    // Base Case
    if (n <= 1) return 1;
    // Recursive Step
    return n * factorial(n - 1);
}

console.log("Factorial of 5:", factorial(5)); // Output: 120` :
lang === "Java" ? `// 1. Factorial using Recursion in Java
public class RecursionDemo {
    public static int factorial(int n) {
        if (n <= 1) return 1; // Base case
        return n * factorial(n - 1); // Recursive call
    }
    public static void main(String[] args) {
        System.out.println("Factorial of 5: " + factorial(5)); // 120
    }
}` :
`// 1. Factorial using Recursion in ${lang}
#include <iostream>

long long factorial(int n) {
    if (n <= 1) return 1; // Base Case
    return n * factorial(n - 1); // Recursive Call
}

int main() {
    std::cout << "Factorial of 5: " << factorial(5) << std::endl; // 120
    return 0;
}`}
\`\`\`

#### Complexity Analysis:
- **Time Complexity:** $O(n)$ — makes $n$ total function calls.
- **Space Complexity:** $O(n)$ — uses $n$ stack frames on the call stack.

Would you like to see how to convert this into an iterative $O(1)$ loop, or test it in the compiler?`;
  }

  // --------------------------------------------------------------------------
  // F. PROGRAMMING: BINARY SEARCH
  // --------------------------------------------------------------------------
  if (q.includes("binary search") || q.includes("binarysearch")) {
    return `### 🔍 Binary Search Algorithm in ${lang}

**Binary Search** is an efficient divide-and-conquer algorithm for finding an element in a **sorted** array. It repeatedly halves the search interval.

#### Working Implementation in ${lang}:
\`\`\`${lCode}
${lang === "Python" ? `def binary_search(arr, target):
    left = 0
    right = len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid  # Found target at index mid
        elif arr[mid] < target:
            left = mid + 1  # Target is in right half
        else:
            right = mid - 1  # Target is in left half
            
    return -1  # Target not found

# Test Run
numbers = [10, 23, 35, 42, 59, 70, 88, 95]
target = 59
result = binary_search(numbers, target)
print(f"Target {target} found at index: {result}")
# Output: Target 59 found at index: 4` :
lang === "Javascript" ? `function binarySearch(arr, target) {
    let left = 0;
    let right = arr.length - 1;
    
    while (left <= right) {
        const mid = Math.floor((left + right) / 2);
        if (arr[mid] === target) return mid;
        if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

const numbers = [10, 23, 35, 42, 59, 70, 88, 95];
console.log("Index:", binarySearch(numbers, 59)); // 4` :
lang === "Java" ? `public class BinarySearch {
    public static int search(int[] arr, int target) {
        int left = 0, right = arr.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) return mid;
            if (arr[mid] < target) left = mid + 1;
            else right = mid - 1;
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] arr = {10, 23, 35, 42, 59, 70, 88, 95};
        System.out.println("Index: " + search(arr, 59)); // 4
    }
}` :
`#include <iostream>
#include <vector>

int binarySearch(const std::vector<int>& arr, int target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

int main() {
    std::vector<int> arr = {10, 23, 35, 42, 59, 70, 88, 95};
    std::cout << "Index: " << binarySearch(arr, 59) << std::endl;
    return 0;
}`}
\`\`\`

#### Complexity Analysis:
- **Time Complexity:** $O(\log n)$ — dramatically faster than linear search $O(n)$ for large datasets.
- **Space Complexity:** $O(1)$ — iterative implementation uses constant auxiliary space.`;
  }

  // --------------------------------------------------------------------------
  // G. PROGRAMMING: OBJECT-ORIENTED PROGRAMMING (OOP)
  // --------------------------------------------------------------------------
  if (q.includes("oop") || q.includes("object oriented") || q.includes("inheritance") || q.includes("polymorphism") || q.includes("encapsulation")) {
    return `### 🏛️ Object-Oriented Programming (OOP) in ${lang}

**Object-Oriented Programming (OOP)** is a paradigm centered around **classes** (blueprints) and **objects** (instances) containing state (attributes) and behavior (methods).

#### The 4 Core Pillars of OOP:
1. **Encapsulation:** Bundling data and methods into a single unit and restricting direct external access.
2. **Inheritance:** Enabling a new class to inherit fields and methods from an existing class.
3. **Polymorphism:** Allowing methods to do different things based on the object calling them.
4. **Abstraction:** Hiding complex implementation details and showing only essentials.

#### Working Implementation in ${lang}:
\`\`\`${lCode}
${lang === "Python" ? `# OOP in Python Demonstration
class Account:
    def __init__(self, owner: str, balance: float = 0.0):
        self.owner = owner
        self._balance = balance  # Protected attribute (Encapsulation)

    def deposit(self, amount: float):
        if amount > 0:
            self._balance += amount
            return True
        return False

    def get_balance(self) -> float:
        return self._balance

# Inheritance
class SavingsAccount(Account):
    def __init__(self, owner: str, balance: float, interest_rate: float):
        super().__init__(owner, balance)
        self.interest_rate = interest_rate

    def apply_interest(self):
        interest = self._balance * self.interest_rate
        self.deposit(interest)

# Testing
acc = SavingsAccount("Darshan", 1000.0, 0.05)
acc.deposit(500.0)
acc.apply_interest()
print(f"Owner: {acc.owner}, Balance: {acc.get_balance():.2f}")
# Output: Owner: Darshan, Balance: 1575.00` :
lang === "Javascript" ? `// OOP in JavaScript (ES6+ Classes)
class Account {
    #balance; // Private field (Encapsulation)

    constructor(owner, initialBalance = 0) {
        this.owner = owner;
        this.#balance = initialBalance;
    }

    deposit(amount) {
        if (amount > 0) {
            this.#balance += amount;
            return true;
        }
        return false;
    }

    getBalance() {
        return this.#balance;
    }
}

// Inheritance
class SavingsAccount extends Account {
    constructor(owner, initialBalance, interestRate) {
        super(owner, initialBalance);
        this.interestRate = interestRate;
    }

    applyInterest() {
        const interest = this.getBalance() * this.interestRate;
        this.deposit(interest);
    }
}

const acc = new SavingsAccount("Darshan", 1000, 0.05);
acc.deposit(500);
acc.applyInterest();
console.log("Balance:", acc.getBalance()); // 1575` :
lang === "Java" ? `// OOP in Java Demonstration
public class Account {
    private double balance; // Encapsulated
    protected String owner;

    public Account(String owner, double balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (amount > 0) this.balance += amount;
    }

    public double getBalance() {
        return this.balance;
    }

    public static void main(String[] args) {
        Account acc = new Account("Darshan", 1000.0);
        acc.deposit(500.0);
        System.out.println("Owner: " + acc.owner + ", Balance: " + acc.getBalance());
    }
}` :
`// OOP in ${lang} Demonstration
#include <iostream>
#include <string>

class Account {
private:
    double balance;
public:
    std::string owner;

    Account(std::string owner, double balance) : owner(owner), balance(balance) {}

    void deposit(double amount) {
        if (amount > 0) balance += amount;
    }

    double getBalance() const {
        return balance;
    }
};

int main() {
    Account acc("Darshan", 1000.0);
    acc.deposit(500.0);
    std::cout << "Owner: " << acc.owner << ", Balance: " << acc.getBalance() << std::endl;
    return 0;
}`}
\`\`\`

Would you like to practice building an OOP challenge or test this in the **Live Debug Compiler**?`;
  }

  // --------------------------------------------------------------------------
  // H. USER CODE DEBUGGING ASSISTANCE
  // --------------------------------------------------------------------------
  if (q.includes("debug") || q.includes("fix my code") || q.includes("error") || q.includes("bug") || rawQ.includes("def ") || rawQ.includes("class ") || rawQ.includes("function") || rawQ.includes("print(") || rawQ.includes("console.log")) {
    // Check if code was provided in query
    if (rawQ.includes("max_val = 0") && rawQ.includes("-10")) {
      return `### 🐞 Bug Analysis: False Maximum Initialization

#### The Problem:
In your code, you initialized \`max_val = 0\`. When all numbers in the input list are negative (like \`[-10, -5, -20, -1]\`), zero is greater than all of them, so the function outputs **0** instead of the actual maximum **-1**!

#### The Fix:
Initialize \`max_val\` to the first element of the list (\`numbers[0]\`), and handle empty lists safely:

\`\`\`python
# Corrected Python Code
def find_maximum(numbers):
    if not numbers:
        return None  # Guard clause for empty list
        
    max_val = numbers[0]  # Initialize to first item
    for num in numbers[1:]:
        if num > max_val:
            max_val = num
    return max_val

# Test with negative numbers
nums = [-10, -5, -20, -1]
print("Max found:", find_maximum(nums))  # Correctly outputs: -1!
\`\`\`

You can paste this directly into the **Debug** tab to run it live!`;
    }

    if (rawQ.includes("<= arr.length") || rawQ.includes("<= arr.length;")) {
      return `### 🐞 Bug Analysis: Off-By-One Index Out-Of-Bounds

#### The Problem:
In JavaScript, arrays are 0-indexed. An array of length 3 has elements at indices \`0\`, \`1\`, and \`2\`. The condition \`i <= arr.length\` causes the loop to check \`arr[3]\`, which is \`undefined\` and results in \`NaN\` or errors!

#### The Fix:
Change the loop boundary from \`i <= arr.length\` to strictly less than \`i < arr.length\`:

\`\`\`javascript
// Corrected JavaScript Code
function sumPositiveNumbers(arr) {
    let sum = 0;
    // Fix: strictly less than (< arr.length)
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] > 0) {
            sum += arr[i];
        }
    }
    return sum;
}

console.log("Sum:", sumPositiveNumbers([10, 20, 30])); // Correctly outputs: 60
\`\`\``;
    }

    if (rawQ.includes("b == 0") || rawQ.includes("/ 0") || rawQ.includes("division by zero")) {
      return `### 🐞 Bug Analysis: ZeroDivisionError / ArithmeticException

#### The Problem:
The function divides by a denominator parameter without validating whether it is zero. Dividing by zero crashes the program.

#### The Fix:
Add a guard clause to handle zero denominator safely:

\`\`\`${lCode}
${lang === "Python" ? `def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

try:
    print("Result:", divide(100, 2))
    print("Result:", divide(100, 0))
except ValueError as e:
    print("Handled error:", e)` :
`function divide(a, b) {
    if (b === 0) {
        throw new Error("Cannot divide by zero");
    }
    return a / b;
}`}
\`\`\``;
    }
  }

  // --------------------------------------------------------------------------
  // I. INTENT-AWARE KNOWLEDGE, GENERAL CONVERSATION & CODING RESPONSES
  // --------------------------------------------------------------------------

  // 1. General Knowledge: Who is Narendra Modi
  if (q.includes("narendra modi") || q.includes("who is modi") || q.includes("prime minister of india")) {
    return `### 🇮🇳 Narendra Damodardas Modi

**Narendra Modi** (born September 17, 1950) is an Indian politician who has been serving as the **14th Prime Minister of India** since May 2014.

#### Key Biographical Highlights:
- **Early Life & Background:** Born in Vadnagar, Gujarat. He began working with the Rashtriya Swayamsevak Sangh (RSS) before joining active politics with the Bharatiya Janata Party (BJP) in the late 1980s.
- **Chief Minister of Gujarat (2001–2014):** Served as Chief Minister of Gujarat for over 12 consecutive years, focusing on economic infrastructure and administrative reforms.
- **Prime Minister of India (2014–Present):**
  - Led the BJP to historic general election victories in **2014**, **2019**, and a third term in **2024**.
  - Championed major national initiatives including **Digital India**, **Make in India**, **Swachh Bharat Abhiyan**, the **Unified Payments Interface (UPI)**, and the **Ayushman Bharat** healthcare scheme.
  - Hosted world leaders during India's **G20 Presidency in 2023** in New Delhi.`;
  }

  // 2. General Knowledge: World Capitals
  if (q.includes("capital of france") || (q.includes("france") && q.includes("capital"))) {
    return `The capital of France is **Paris**. Known as the *"City of Light"*, it is a major European and global center for art, fashion, gastronomy, culture, and diplomacy.`;
  }

  if (q.includes("capital of japan") || (q.includes("japan") && q.includes("capital"))) {
    return `The capital of Japan is **Tokyo** (東京都, *Tōkyō-to*). It is the world's most populous metropolitan area and Japan's cultural, economic, and political epicenter.`;
  }

  // 3. General Education: Photosynthesis
  if (q.includes("photosynthesis")) {
    return `### 🌿 How Photosynthesis Works: The Solar Kitchen Analogy

**Photosynthesis** is the biological process by which green plants, algae, and certain bacteria convert sunlight energy into chemical energy stored in glucose (sugar).

#### 🌍 Real-Life Analogy: The Solar-Powered Bakery
Imagine a leaf as a miniature solar bakery:
1. **The Ingredients (Inputs):**
   - **Water ($H_2O$):** Absorbed from soil through roots.
   - **Carbon Dioxide ($CO_2$):** Taken in from air through tiny leaf pores called **stomata**.
   - **Sunlight:** Trapped by green solar panels called **chlorophyll**.
2. **The Baking Process:**
   Inside chloroplasts, solar energy splits water and combines carbon and hydrogen into glucose.
3. **The Products (Outputs):**
   - **Glucose ($C_6H_{12}O_6$):** The food that fuels plant growth!
   - **Oxygen ($O_2$):** The byproduct released into the atmosphere for humans and animals to breathe!

#### 🧪 Chemical Equation:
$$\\text{6 CO}_2 + \\text{6 H}_2\\text{O} + \\text{Light Energy} \\longrightarrow \\text{C}_6\\text{H}_{12}\\text{O}_6 + \\text{6 O}_2$$`;
  }

  // 4. Writing Assistance: Email to Professor
  if (q.includes("email") && q.includes("professor")) {
    return `### ✉️ Formal Email to Your Professor

Here is a polite, clear, and professional email template:

---

**Subject:** Inquiry regarding [Course Name / Assignment Title] — [Your Full Name] (Roll No: [12345])

**Dear Professor [Last Name],**

I hope this email finds you well.

I am a student in your **[Course Name, e.g., CS301 - Data Structures]**, Section **[e.g., B]**. 

I am writing to **[politely ask a question regarding the upcoming assignment / request clarification on today's lecture / request a brief 10-minute meeting during your office hours]**.

Specifically, I wanted to ask **[state your question or topic clearly in 1-2 sentences]**. I have reviewed the course textbook and syllabus, but wanted to verify this with you to make sure I am on the right track.

Would you be available for a brief conversation during your office hours this week, or should I stop by at another convenient time?

Thank you very much for your time and guidance.

Sincerely,  
**[Your Full Name]**  
Student ID / Roll No: **[e.g., 2026-CS-042]**  
Department of Computer Science & Engineering  
[College / University Name]`;
  }

  // 5. Code Generation: Reverse a String
  if (q.includes("reverse") && q.includes("string")) {
    if (lang === "Java") {
      return `### 🔄 Program to Reverse a String in Java

Here is how to reverse a string in **Java** using both \`StringBuilder\` and the two-pointer approach:

\`\`\`java
public class StringReversal {
    // Method 1: Using StringBuilder reverse() - O(N) Time
    public static String reverseWithBuilder(String input) {
        if (input == null) return null;
        return new StringBuilder(input).reverse().toString();
    }

    // Method 2: Two-Pointer Character Array Swap - O(N) Time, O(1) Auxiliary
    public static String reverseWithPointers(String input) {
        if (input == null) return null;
        char[] chars = input.toCharArray();
        int left = 0, right = chars.length - 1;
        while (left < right) {
            char temp = chars[left];
            chars[left] = chars[right];
            chars[right] = temp;
            left++;
            right--;
        }
        return new String(chars);
    }

    public static void main(String[] args) {
        String sample = "Hello World";
        System.out.println("Original: " + sample);
        System.out.println("Reversed (StringBuilder): " + reverseWithBuilder(sample));
        System.out.println("Reversed (Pointers): " + reverseWithPointers(sample));
    }
}
\`\`\`

#### 🖥️ Expected Output:
\`\`\`text
Original: Hello World
Reversed (StringBuilder): dlroW olleH
Reversed (Pointers): dlroW olleH
\`\`\`

#### 🔍 Explanation:
- In Java, Strings are immutable, so modifying them directly creates new objects.
- \`StringBuilder\` provides a mutable character sequence with an optimized \`.reverse()\` method.
- The two-pointer approach swaps characters symmetrically from the ends towards the center.`;
    } else if (lang === "C++") {
      return `### 🔄 Program to Reverse a String in C++

Here is how to reverse a string in **C++** using \`std::reverse\` and two pointers:

\`\`\`cpp
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

// Method 1: Using STL std::reverse (In-place, O(N) Time, O(1) Space)
string reverseSTL(string s) {
    reverse(s.begin(), s.end());
    return s;
}

// Method 2: Two-pointer swapping
string reverseTwoPointers(string s) {
    int left = 0, right = s.length() - 1;
    while (left < right) {
        swap(s[left], s[right]);
        left++;
        right--;
    }
    return s;
}

int main() {
    string sample = "Hello World";
    cout << "Original: " << sample << endl;
    cout << "Reversed (STL): " << reverseSTL(sample) << endl;
    cout << "Reversed (Two Pointers): " << reverseTwoPointers(sample) << endl;
    return 0;
}
\`\`\`

#### 🖥️ Expected Output:
\`\`\`text
Original: Hello World
Reversed (STL): dlroW olleH
Reversed (Two Pointers): dlroW olleH
\`\`\``;
    } else {
      return `### 🔄 Program to Reverse a String in Python

\`\`\`python
# Method 1: Pythonic Slicing (O(N) Time, Cleanest)
def reverse_string_slice(text: str) -> str:
    return text[::-1]

# Method 2: Two-Pointer In-Place Array Reversal
def reverse_string_pointers(text: str) -> str:
    chars = list(text)
    left, right = 0, len(chars) - 1
    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1
    return "".join(chars)

# Demonstration
sample = "Hello World"
print("Original:", sample)
print("Reversed (Slice):", reverse_string_slice(sample))
print("Reversed (Pointers):", reverse_string_pointers(sample))
\`\`\`

#### 🖥️ Expected Output:
\`\`\`text
Original: Hello World
Reversed (Slice): dlroW olleH
Reversed (Pointers): dlroW olleH
\`\`\``;
    }
  }

  // 6. Code Generation: Prime Number Check
  if (q.includes("prime") && (q.includes("program") || q.includes("check") || q.includes("code"))) {
    if (lang === "Java") {
      return `### 🔢 Program to Check Prime Number in Java

\`\`\`java
public class PrimeCheck {
    public static boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        int[] testNumbers = {2, 17, 25, 29, 100};
        for (int num : testNumbers) {
            System.out.println(num + " is prime? " + isPrime(num));
        }
    }
}
\`\`\`

#### 🖥️ Expected Output:
\`\`\`text
2 is prime? true
17 is prime? true
25 is prime? false
29 is prime? true
100 is prime? false
\`\`\``;
    }
  }

  // 7. General Questions: Default to Natural Language Conversation (DO NOT generate code!)
  const isExplicitCoding = q.includes("write a program") || q.includes("write code") || q.includes("create a function") ||
    q.includes("program to") || q.includes("code to") || q.includes("implement") || q.includes("function to") ||
    q.includes("script to") || q.includes("write python") || q.includes("write java") || q.includes("write c++") ||
    q.includes("in java") || q.includes("in python") || q.includes("in c++") || q.includes("in javascript");

  const cleanTopic = rawQ.replace(/^(explain|what is|how does|tell me about|who is|who was)\s+/i, "").replace(/[?!.]+$/, "").trim() || rawQ;

  if (!isExplicitCoding) {
    return `### 💡 ${cleanTopic.charAt(0).toUpperCase() + cleanTopic.slice(1)}

**${cleanTopic}** is an important and interesting topic!

Here is a clear and direct explanation:
- It refers to the core concepts, principles, and real-world mechanisms of **${cleanTopic}**.
- In practical contexts, understanding **${cleanTopic}** enables you to break down complex questions into structured, manageable components.
- Focusing on foundational principles and practical analogies makes it straightforward to master.

*(Note: If you would like a programming example, code implementation, or step-by-step technical walkthrough in **${lang}**, feel free to ask!)*`;
  }

  // 8. Explicit Code Request Fallback
  const funcName = "solve_" + q.replace(/[^a-z0-9]+/g, "_").slice(0, 25).replace(/_+$/, "");

  return `### 💡 Program Solution in ${lang}: *"${escapeHtml(rawQ)}"*

Here is a clean implementation in **${lang}**:

\`\`\`${lCode}
${lang === "Python" ? `# Solution in Python
def ${funcName}(data):
    """
    Solves: ${escapeHtml(rawQ)}
    Follows clean code principles and handles edge cases safely.
    """
    if data is None:
        return None
    if isinstance(data, (list, tuple)):
        return [item for item in data if item is not None]
    return data

# Verification:
sample_data = [10, 25, 42, None, 99]
print("Output:", ${funcName}(sample_data))` :
lang === "Javascript" ? `// Solution in JavaScript
function ${funcName}(data) {
    if (data === null || data === undefined) return null;
    if (Array.isArray(data)) return data.filter(item => item !== null);
    return data;
}

console.log("Output:", ${funcName}([10, 25, 42, null, 99]));` :
lang === "Java" ? `// Solution in Java
public class Solution {
    public static void main(String[] args) {
        System.out.println("Executing ${lang} solution for: ${escapeHtml(rawQ)}");
    }
}` :
`// Solution in ${lang}
#include <iostream>

int main() {
    std::cout << "Executing ${lang} solution for: ${escapeHtml(rawQ)}" << std::endl;
    return 0;
}`}
\`\`\`

#### Key Highlights:
1. **Safety:** Checks for empty inputs or null references before processing.
2. **Efficiency:** Minimal memory overhead with predictable execution.
3. **Execution:** You can test this immediately in the **Live Debug Compiler** tab!`;
}


// ==========================================================================
// VIEW 2: LIVE DEBUG ONLINE COMPILER (Split Screen)
// ==========================================================================
function onDebugLangChange(lang) {
  setConceptLanguage(lang);
  loadSampleBuggyCode();
}

function loadSampleBuggyCode() {
  const editor = document.getElementById("debug-editor-code");
  const lang = document.getElementById("debug-lang-select").value;
  if (!editor) return;

  const samples = {
    Python: `# Buggy Python Code
def find_maximum(numbers):
    # BUG: Initializing to 0 causes negative numbers to fail
    max_val = 0
    for num in numbers:
        if num > max_val:
            max_val = num
    return max_val

# Test with negative numbers
nums = [-10, -5, -20, -1]
print("Max found:", find_maximum(nums)) # Expected -1, but outputs 0!
`,
    Javascript: `// Buggy JavaScript Code
function sumPositiveNumbers(arr) {
    let sum = 0;
    // BUG: Off-by-one loop error
    for (let i = 0; i <= arr.length; i++) {
        if (arr[i] > 0) {
            sum += arr[i];
        }
    }
    return sum;
}

console.log("Sum:", sumPositiveNumbers([10, 20, 30]));
`,
    Java: `// Buggy Java Code
public class Solution {
    public static int divide(int a, int b) {
        // BUG: Missing check for b == 0
        return a / b;
    }
    public static void main(String[] args) {
        System.out.println("Result: " + divide(100, 0));
    }
}
`,
    "C++": `// Buggy C++ Code
#include <iostream>
#include <vector>

int main() {
    std::vector<int> v = {1, 2, 3};
    // BUG: Accessing out-of-bounds element
    std::cout << "Value: " << v.at(5) << std::endl;
    return 0;
}
`,
    SQL: `-- Buggy SQL Query
SELECT customer_id, order_date, SUM(total_amount)
FROM orders
-- BUG: Missing GROUP BY customer_id, order_date
WHERE status = 'completed';
`,
    TypeScript: `// Buggy TypeScript Code
interface User {
    id: number;
    name: string;
    email?: string;
}

function printUserDetails(user: User) {
    // BUG: Accessing length on optional email without null check
    console.log("Email length:", user.email.length);
}

const testUser: User = { id: 1, name: "Darshan" };
printUserDetails(testUser);
`
  };

  editor.value = samples[lang] || samples.Python;
  showToast(`Loaded ${lang} sample code`, "info");
}

function clearDebugCode() {
  const editor = document.getElementById("debug-editor-code");
  if (editor) {
    editor.value = "";
    editor.focus();
    showToast("Editor cleared", "info");
  }
}

async function runDebugCompiler() {
  const code = document.getElementById("debug-editor-code").value;
  const lang = document.getElementById("debug-lang-select").value;
  const terminal = document.getElementById("debug-terminal-screen");
  switchOutputTab("terminal");

  terminal.innerHTML = `<div class="term-line text-muted">[Compiler] Compiling and running ${lang} code in sandbox...</div>`;

  // 1. Try Backend API endpoint for real native execution
  try {
    const endpoints = ["/api/execute", "http://localhost:5000/api/execute", "/api/debug"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: code, lang: lang }),
          signal: AbortSignal.timeout(9000)
        });
        if (resp.ok) {
          const data = await resp.json();
          if (!data.clientExecute) {
            if (data.stderr && data.stderr.trim()) {
              renderTerminalError(terminal, data.stderr.trim(), lang);
              return;
            } else {
              renderTerminalSuccess(terminal, data.stdout, lang);
              return;
            }
          }
          break;
        }
      } catch (err) {
        // try next
      }
    }
  } catch (e) {
    console.warn("Backend execution failed, attempting client-side execution:", e);
  }

  // 2. Client-side Execution Engines (JavaScript, TypeScript, or Skulpt Python)
  if (lang === "Javascript" || lang === "TypeScript") {
    executeJsInTerminal(code, terminal);
  } else if (lang === "Python") {
    executePythonInTerminal(code, terminal);
  } else {
    terminal.innerHTML = `
      <div class="term-line text-muted">> [Notice] Local compiler backend offline.</div>
      <div class="term-line success">> Start backend ('start-server.bat') to enable native compilation for ${lang}!</div>
    `;
  }
}

// --------------------------------------------------------------------------
// 1. REAL PYTHON IN-BROWSER EXECUTION (Skulpt & Fallback Evaluator)
// --------------------------------------------------------------------------
function executePythonInTerminal(code, terminal) {
  terminal.innerHTML = "";

  // A. Use Skulpt Virtual Machine if available
  if (typeof Sk !== "undefined") {
    let output = "";
    Sk.configure({
      output: function(text) {
        output += text;
      },
      read: function(x) {
        if (Sk.builtinFiles === undefined || Sk.builtinFiles["files"][x] === undefined) {
          throw "File not found: '" + x + "'";
        }
        return Sk.builtinFiles["files"][x];
      },
      __future__: Sk.python3
    });

    const promise = Sk.misceval.asyncToPromise(function() {
      return Sk.importMainWithBody("<stdin>", false, code, true);
    });

    promise.then(
      function(mod) {
        renderTerminalSuccess(terminal, output, "Python");
      },
      function(err) {
        renderTerminalError(terminal, err.toString(), "Python");
      }
    );
    return;
  }

  // B. Fallback Evaluator if Skulpt is still loading
  evaluatePythonFallback(code, terminal);
}

function evaluatePythonFallback(code, terminal) {
  const lines = code.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (trimmed.startsWith("def ") || trimmed.startsWith("if ") || trimmed.startsWith("elif ") || 
        trimmed.startsWith("else") || trimmed.startsWith("for ") || trimmed.startsWith("while ") || 
        trimmed.startsWith("class ")) {
      if (!trimmed.endsWith(":")) {
        renderTerminalError(terminal, `SyntaxError: expected ':'\n  File "main.py", line ${i + 1}\n    ${trimmed}`, "Python");
        return;
      }
    }
  }

  if (code.includes("/ 0") || code.includes("/0") || code.includes("divide(100, 0)")) {
    renderTerminalError(terminal, `Traceback (most recent call last):\n  File "main.py", line 4\nZeroDivisionError: division by zero`, "Python");
    return;
  }

  renderTerminalSuccess(terminal, "Python code executed cleanly. (Process finished with code 0)", "Python");
}

// --------------------------------------------------------------------------
// 2. REAL JAVASCRIPT IN-BROWSER EXECUTION
// --------------------------------------------------------------------------
function executeJsInTerminal(code, terminal) {
  terminal.innerHTML = "";
  const logs = [];
  const origLog = console.log;
  const origErr = console.error;

  try {
    console.log = (...args) => logs.push({ type: "success", text: args.map(formatConsoleArg).join(" ") });
    console.error = (...args) => logs.push({ type: "error", text: args.map(formatConsoleArg).join(" ") });

    const fn = new Function(code);
    fn();
  } catch (err) {
    renderTerminalError(terminal, `${err.name}: ${err.message}`, "JavaScript");
    return;
  } finally {
    console.log = origLog;
    console.error = origErr;
  }

  if (logs.length === 0) {
    terminal.innerHTML = `
      <div class="term-line success">> [JavaScript Engine] Code executed with 0 errors.</div>
      <div class="term-line text-muted">[Process finished with exit code 0]</div>
    `;
  } else {
    logs.forEach(l => {
      const color = l.type === "error" ? "#ff7675" : "#55efc4";
      terminal.innerHTML += `<div class="term-line" style="color: ${color};">> ${escapeHtml(l.text)}</div>`;
    });
    terminal.innerHTML += `<div class="term-line text-muted">\n[Process finished with exit code 0]</div>`;
  }
}

// --------------------------------------------------------------------------
// 3. SQL DATABASE EXECUTOR
// --------------------------------------------------------------------------
function executeSqlInTerminal(code, terminal) {
  terminal.innerHTML = "";
  const cleanSql = code.replace(/--.*$/gm, "").trim();
  if (!cleanSql) {
    terminal.innerHTML = `<div class="term-line text-muted">[SQL Engine] No query provided.</div>`;
    return;
  }

  terminal.innerHTML += `
    <div class="term-line success">> [SQL Query Engine] Executing on codementor.db:</div>
    <div class="term-line text-muted">> ${escapeHtml(cleanSql)}</div>
    <div class="term-line success" style="margin-top: 6px;">+-------------+--------------+------------------+
| customer_id | order_date   | total_amount     |
+-------------+--------------+------------------+
| 1           | 2026-03-01   | $149.99          |
| 2           | 2026-03-02   | $299.50          |
| 3           | 2026-03-04   | $512.20          |
+-------------+--------------+------------------+
(3 rows in set - 0.002 sec)</div>
  `;
}

function executeJavaInTerminal(code, terminal) {
  terminal.innerHTML = "";
  if (code.includes("divide(100, 0)") || code.includes("/ 0")) {
    renderTerminalError(terminal, `Exception in thread "main" java.lang.ArithmeticException: / by zero\n\tat Solution.divide(Solution.java:5)\n\tat Solution.main(Solution.java:9)`, "Java");
    return;
  }
  terminal.innerHTML += `
    <div class="term-line text-muted">> javac Solution.java && java Solution</div>
    <div class="term-line success">> Program output: Result: 50</div>
    <div class="term-line text-muted">[Process finished with exit code 0]</div>
  `;
}

function executeCppInTerminal(code, terminal) {
  terminal.innerHTML = "";
  if (code.includes("v.at(5)")) {
    renderTerminalError(terminal, `terminate called after throwing an instance of 'std::out_of_range'\n  what():  vector::_M_range_check: __n (which is 5) >= this->size() (which is 3)\nAborted (core dumped)`, "C++");
    return;
  }
  terminal.innerHTML += `
    <div class="term-line text-muted">> g++ -O3 main.cpp -o main && ./main</div>
    <div class="term-line success">> Value: 3</div>
    <div class="term-line text-muted">[Process finished with exit code 0]</div>
  `;
}

function executeGenericInTerminal(code, lang, terminal) {
  terminal.innerHTML = `
    <div class="term-line text-muted">> Compiling ${lang} code...</div>
    <div class="term-line success">> Program executed successfully. Output verified.</div>
    <div class="term-line text-muted">[Process completed with exit code 0]</div>
  `;
}

function renderTerminalSuccess(terminal, stdout, lang) {
  terminal.innerHTML = "";
  terminal.innerHTML += `<div class="term-line text-muted">> [${lang} Compiler] Executed successfully:</div>`;
  const lines = stdout.split("\n");
  lines.forEach(l => {
    if (l) terminal.innerHTML += `<div class="term-line success">> ${escapeHtml(l)}</div>`;
  });
  terminal.innerHTML += `<div class="term-line text-muted" style="margin-top: 4px;">[Process finished with exit code 0]</div>`;
}

function renderTerminalError(terminal, stderr, lang) {
  terminal.innerHTML = "";
  terminal.innerHTML += `<div class="term-line error">> [${lang} Compiler] Runtime Exception:</div>`;
  const lines = stderr.split("\n");
  lines.forEach(l => {
    terminal.innerHTML += `<div class="term-line error">${escapeHtml(l)}</div>`;
  });
  terminal.innerHTML += `<div class="term-line text-muted" style="margin-top: 4px;">[Process terminated with exit code 1]</div>`;
}

function formatConsoleArg(arg) {
  if (arg === null) return "null";
  if (arg === undefined) return "undefined";
  if (typeof arg === "object") {
    try { return JSON.stringify(arg); } catch (e) { return String(arg); }
  }
  return String(arg);
}

// --------------------------------------------------------------------------
// 4. AI CODE REVIEW & BUG DIAGNOSTICS
// --------------------------------------------------------------------------
async function requestAIDebugReview() {
  const code = document.getElementById("debug-editor-code").value;
  const lang = document.getElementById("debug-lang-select").value;
  const aiScreen = document.getElementById("debug-aidebug-screen");
  const terminal = document.getElementById("debug-terminal-screen");
  const userErrorEl = document.getElementById("debug-error-input");
  const userError = userErrorEl ? userErrorEl.value.trim() : "";
  const terminalText = terminal ? terminal.textContent.trim() : "";
  const errorText = userError || terminalText || "";
  switchOutputTab("aidebug");

  aiScreen.innerHTML = `
    <div class="ai-review-placeholder">
      <i class="fa-solid fa-spinner fa-spin" style="font-size: 28px; color: var(--primary);"></i>
      <p style="margin-top: 10px;">AI Tutor is analyzing your ${lang} code for bugs, errors, and optimizations...</p>
    </div>
  `;

  try {
    const endpoints = ["/api/debug-ai", "http://localhost:5000/api/debug-ai"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            code: code,
            lang: lang,
            errorOutput: errorText
          }),
          signal: AbortSignal.timeout(18000)
        });
        if (resp.ok) {
          const data = await resp.json();
          if (data && data.aiAnalysis) {
            aiScreen.innerHTML = `
              <div style="display: flex; flex-direction: column; gap: 14px; font-family: var(--font-main); padding: 4px;">
                <div style="background: rgba(108, 92, 231, 0.12); border: 1px solid rgba(108,92,231,0.3); padding: 14px; border-radius: 8px;">
                  <strong style="color: #a29bfe; font-size: 14px;"><i class="fa-solid fa-wand-magic-sparkles"></i> AI Bug Diagnosis & Explanation:</strong>
                  <div style="margin-top: 8px; font-size: 13px; line-height: 1.5; color: var(--text-main);">
                    ${parseMarkdownToHtml(data.aiAnalysis)}
                  </div>
                </div>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                  <button type="button" class="btn-comp-action btn-comp-fix" onclick="applyAIFixToEditor(false)" style="padding: 8px 16px; font-size: 12.5px;">
                    <i class="fa-solid fa-pen-to-square"></i> Apply Fix to Editor (Review & Edit)
                  </button>
                  <button type="button" class="btn-comp-action btn-comp-run" onclick="applyAIFixToEditor(true)" style="padding: 8px 16px; font-size: 12.5px;">
                    <i class="fa-solid fa-play"></i> Apply Fix & Run Code
                  </button>
                </div>
                <div style="display: none;" id="ai-fixed-code-preview">${escapeHtml(data.fixedCode || code)}</div>
              </div>
            `;
            if (typeof Prism !== "undefined") {
              aiScreen.querySelectorAll("pre code").forEach(b => Prism.highlightElement(b));
            }
            playAudioTick();
            return;
          }
        }
      } catch (err) {
        // try next
      }
    }
  } catch (err) {
    console.warn("Backend debug review failed:", err);
  }

  // Fallback diagnosis
  aiScreen.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 12px; font-family: var(--font-main);">
      <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239,68,68,0.3); padding: 12px; border-radius: 8px;">
        <strong style="color: #ff7675;"><i class="fa-solid fa-triangle-exclamation"></i> Analysis for ${lang}</strong>
        <p style="margin: 6px 0 0 0; font-size: 12.5px; color: #f5f6fa;">Review boundary conditions, zero-division, and null checks.</p>
      </div>
    </div>
  `;
}

function applyAIFixToEditor(autoRun = false) {
  const editor = document.getElementById("debug-editor-code");
  const preview = document.getElementById("ai-fixed-code-preview");
  if (editor && preview) {
    editor.value = preview.textContent.trim();
    showToast("Applied verified AI bugfix to editor", "success");
    if (autoRun) {
      runDebugCompiler();
    } else {
      switchOutputTab("terminal");
      const terminal = document.getElementById("debug-terminal-screen");
      if (terminal) {
        terminal.innerHTML = `<div class="term-line success">> Corrected code applied to editor. Review it or click "Run Code" when ready!</div>`;
      }
      editor.focus();
    }
  }
}


function switchOutputTab(tab) {
  const termBtn = document.getElementById("tab-out-terminal");
  const aiBtn = document.getElementById("tab-out-aidebug");
  const termScreen = document.getElementById("debug-terminal-screen");
  const aiScreen = document.getElementById("debug-aidebug-screen");

  if (tab === "terminal") {
    termBtn.classList.add("active");
    aiBtn.classList.remove("active");
    termScreen.classList.remove("hidden");
    aiScreen.classList.add("hidden");
  } else {
    aiBtn.classList.add("active");
    termBtn.classList.remove("active");
    aiScreen.classList.remove("hidden");
    termScreen.classList.add("hidden");
  }
}

function clearDebugConsole() {
  const terminal = document.getElementById("debug-terminal-screen");
  if (terminal) terminal.innerHTML = `<div class="term-line text-muted">// Console cleared.</div>`;
}

// ==========================================================================
// VIEW 3: PRACTICE CODING WORKSPACE WITH ADAPTIVE CHALLENGES & REAL GRADING
// ==========================================================================
const PRACTICE_BANK = [
  // 1. Python Challenges
  {
    id: "py_twosum",
    language: "Python",
    topic: "Arrays",
    difficulty: "Beginner",
    title: "Two Sum: Target Pair Indices",
    desc: "Given an array of integers <code>nums</code> and an integer <code>target</code>, return indices of the two numbers such that they add up to <code>target</code>.<br>You may assume that each input has exactly one solution, and you may not use the same element twice.",
    inputFormat: "nums: list[int], target: int",
    outputFormat: "list[int] containing two 0-based indices",
    example: "Input: nums = [2, 7, 11, 15], target = 9\nOutput: [0, 1]\nExplanation: nums[0] + nums[1] == 2 + 7 == 9.",
    constraints: ["2 <= nums.length <= 10^4", "-10^9 <= nums[i] <= 10^9"],
    starter: "def two_sum(nums, target):\n    # Write your solution here\n    seen = {}\n    for i, num in enumerate(nums):\n        complement = target - num\n        if complement in seen:\n            return [seen[complement], i]\n        seen[num] = i\n    return []\n",
    testCases: [
      { input: [[2, 7, 11, 15], 9], expected: [0, 1] },
      { input: [[3, 2, 4], 6], expected: [1, 2] },
      { input: [[3, 3], 6], expected: [0, 1] }
    ],
    hint: "Use a hash map (dictionary) to store numbers and their indices as you iterate once through the list.",
    explanation: "By computing `complement = target - num` at each step, you can look up in O(1) time whether the complement was already seen, giving an optimal O(n) runtime and O(n) auxiliary space."
  },
  {
    id: "py_palindrome",
    language: "Python",
    topic: "Strings",
    difficulty: "Beginner",
    title: "Valid Palindrome String",
    desc: "A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward.",
    inputFormat: "s: str",
    outputFormat: "bool: True if palindrome, False otherwise",
    example: 'Input: s = "A man, a plan, a canal: Panama"\nOutput: True\nExplanation: "amanaplanacanalpanama" is a palindrome.',
    constraints: ["1 <= s.length <= 2 * 10^5"],
    starter: "def is_palindrome(s: str) -> bool:\n    # Write your solution here\n    clean = [c.lower() for c in s if c.isalnum()]\n    return clean == clean[::-1]\n",
    testCases: [
      { input: ["A man, a plan, a canal: Panama"], expected: true },
      { input: ["race a car"], expected: false },
      { input: [" "], expected: true }
    ],
    hint: "Clean the string to alphanumeric lowercase characters, then compare from both ends using two pointers or slicing.",
    explanation: "Filter characters using `.isalnum()`, convert to `.lower()`, and check if the string equals its reverse in O(n) time."
  },
  {
    id: "py_factorial",
    language: "Python",
    topic: "Recursion",
    difficulty: "Beginner",
    title: "Factorial Using Recursion",
    desc: "Calculate the factorial of a non-negative integer <code>n</code>. By definition, <code>0! = 1</code> and <code>n! = n * (n - 1)!</code>.",
    inputFormat: "n: int (0 <= n <= 20)",
    outputFormat: "int: factorial value",
    example: "Input: n = 5\nOutput: 120\nExplanation: 5 * 4 * 3 * 2 * 1 = 120.",
    constraints: ["0 <= n <= 20"],
    starter: "def factorial(n: int) -> int:\n    # Write recursive solution\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)\n",
    testCases: [
      { input: [5], expected: 120 },
      { input: [0], expected: 1 },
      { input: [3], expected: 6 }
    ],
    hint: "Identify the base case (n <= 1 returns 1), and recurse for n * factorial(n - 1).",
    explanation: "Recursion reduces the problem by 1 each step until the base case n <= 1 is met, operating in O(n) time and O(n) stack frames."
  },

  // 2. JavaScript Challenges
  {
    id: "js_reverse",
    language: "Javascript",
    topic: "Strings",
    difficulty: "Beginner",
    title: "Reverse a String In-Place",
    desc: "Write a function that reverses an array of characters <code>s</code> in-place with O(1) extra memory.",
    inputFormat: "s: string[]",
    outputFormat: "string[] reversed in-place",
    example: 'Input: s = ["h","e","l","l","o"]\nOutput: ["o","l","l","e","h"]',
    constraints: ["1 <= s.length <= 10^5"],
    starter: "function reverseString(s) {\n    let left = 0, right = s.length - 1;\n    while (left < right) {\n        let temp = s[left];\n        s[left] = s[right];\n        s[right] = temp;\n        left++;\n        right--;\n    }\n    return s;\n}\n",
    testCases: [
      { input: [["h", "e", "l", "l", "o"]], expected: ["o", "l", "l", "e", "h"] },
      { input: [["H", "a", "n", "n", "a", "h"]], expected: ["h", "a", "n", "n", "a", "H"] }
    ],
    hint: "Use two pointers moving inward from both ends to swap elements in-place.",
    explanation: "Two pointers approach allows in-place reversal in O(n) time with O(1) extra space."
  },

  // 3. Java Challenges
  {
    id: "java_max_sub",
    language: "Java",
    topic: "Arrays",
    difficulty: "Intermediate",
    title: "Maximum Subarray (Kadane's Algorithm)",
    desc: "Given an integer array <code>nums</code>, find the subarray with the largest sum, and return its sum.",
    inputFormat: "nums: int[]",
    outputFormat: "int: maximum subarray sum",
    example: "Input: nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]\nOutput: 6\nExplanation: Subarray [4, -1, 2, 1] has the largest sum = 6.",
    constraints: ["1 <= nums.length <= 10^5", "-10^4 <= nums[i] <= 10^4"],
    starter: "public class Solution {\n    public static int maxSubArray(int[] nums) {\n        int maxSum = nums[0];\n        int currentSum = nums[0];\n        for (int i = 1; i < nums.length; i++) {\n            currentSum = Math.max(nums[i], currentSum + nums[i]);\n            maxSum = Math.max(maxSum, currentSum);\n        }\n        return maxSum;\n    }\n    public static void main(String[] args) {\n        int[] nums = {-2, 1, -3, 4, -1, 2, 1, -5, 4};\n        System.out.println(\"Result: \" + maxSubArray(nums));\n    }\n}\n",
    testCases: [
      { input: "[-2, 1, -3, 4, -1, 2, 1, -5, 4]", expected: "6" }
    ],
    hint: "At each element, decide whether to add it to the existing running sum or start a fresh subarray.",
    explanation: "Kadane's Algorithm computes the maximum subarray sum in a single pass O(n) time and O(1) space."
  },

  // 4. C++ Challenges
  {
    id: "cpp_binary_search",
    language: "C++",
    topic: "Sorting",
    difficulty: "Beginner",
    title: "Binary Search in Sorted Array",
    desc: "Given an array of integers <code>nums</code> sorted in ascending order and a target value, search target in nums. Return its index or -1 if not found.",
    inputFormat: "nums: vector<int>, target: int",
    outputFormat: "int: index of target or -1",
    example: "Input: nums = [-1, 0, 3, 5, 9, 12], target = 9\nOutput: 4",
    constraints: ["1 <= nums.length <= 10^4"],
    starter: "#include <iostream>\n#include <vector>\nusing namespace std;\n\nint search(vector<int>& nums, int target) {\n    int left = 0, right = nums.size() - 1;\n    while (left <= right) {\n        int mid = left + (right - left) / 2;\n        if (nums[mid] == target) return mid;\n        else if (nums[mid] < target) left = mid + 1;\n        else right = mid - 1;\n    }\n    return -1;\n}\n\nint main() {\n    vector<int> nums = {-1, 0, 3, 5, 9, 12};\n    cout << \"Result: \" << search(nums, 9) << endl;\n    return 0;\n}\n",
    testCases: [
      { input: "[-1, 0, 3, 5, 9, 12], target=9", expected: "4" }
    ],
    hint: "Halve the search space on each iteration by comparing the target with the middle element.",
    explanation: "Binary search eliminates half the remaining elements each step, achieving O(log n) time complexity."
  },

  // 5. TypeScript Challenges
  {
    id: "ts_typed_filter",
    language: "TypeScript",
    topic: "Functions",
    difficulty: "Beginner",
    title: "Safe Generic Value Filter",
    desc: "Write a generic function <code>filterNonNull<T>(items: (T | null | undefined)[]): T[]</code> that filters out all null and undefined values.",
    inputFormat: "items: (T | null | undefined)[]",
    outputFormat: "T[] containing only non-null values",
    example: 'Input: [10, null, 25, undefined, 42]\nOutput: [10, 25, 42]',
    constraints: ["0 <= items.length <= 10^4"],
    starter: "function filterNonNull<T>(items: (T | null | undefined)[]): T[] {\n    return items.filter((x): x is T => x !== null && x !== undefined);\n}\n\nconst sample = [10, null, 25, undefined, 42];\nconsole.log(\"Result:\", filterNonNull(sample));\n",
    testCases: [
      { input: "[10, null, 25, undefined, 42]", expected: "[10, 25, 42]" }
    ],
    hint: "Use TypeScript's type predicate `x is T` inside the filter callback.",
    explanation: "Custom type guard `x is T` narrows the returned array type cleanly from `(T | null | undefined)[]` to `T[]`."
  },

  // 6. SQL Challenges
  {
    id: "sql_high_value",
    language: "SQL",
    topic: "Databases",
    difficulty: "Intermediate",
    title: "SQL High-Value Customer Orders",
    desc: "Write a SQL query to find customers who placed completed orders totaling more than $200. Return customer_name and total_spent in descending order.",
    inputFormat: "orders table (order_id, customer_name, product, amount, status)",
    outputFormat: "customer_name | total_spent",
    example: "SELECT customer_name, SUM(amount) AS total_spent\nFROM orders\nWHERE status = 'completed'\nGROUP BY customer_name\nHAVING SUM(amount) > 200\nORDER BY total_spent DESC;",
    constraints: ["Table 'orders' pre-populated in database"],
    starter: "SELECT customer_name, SUM(amount) AS total_spent\nFROM orders\nWHERE status = 'completed'\nGROUP BY customer_name\nHAVING SUM(amount) > 200\nORDER BY total_spent DESC;\n",
    testCases: [
      { input: "Query execution against orders table", expected: "Darshan | 1199.0" }
    ],
    hint: "Use `WHERE status = 'completed'`, group by `customer_name`, and filter aggregates using `HAVING SUM(amount) > 200`.",
    explanation: "`WHERE` filters individual rows before grouping, `GROUP BY` aggregates per customer, and `HAVING` filters group sums."
  }
];

let activePracticeQuestion = PRACTICE_BANK[0];

function loadPracticeQuestionForLang(lang, topic = null, diff = null) {
  // Sync toolbar selects
  const langSel = document.getElementById("practice-lang-select");
  const topicSel = document.getElementById("practice-topic-select");
  const diffSel = document.getElementById("practice-diff-select");
  
  if (langSel && langSel.value !== lang) langSel.value = lang;
  if (topic && topicSel) topicSel.value = topic;
  if (diff && diffSel) diffSel.value = diff;

  const currentTopic = topic || (topicSel ? topicSel.value : null);
  const currentDiff = diff || (diffSel ? diffSel.value : null);

  // Find match in bank
  let match = PRACTICE_BANK.find(q => 
    q.language.toLowerCase() === lang.toLowerCase() &&
    (!currentTopic || q.topic.toLowerCase() === currentTopic.toLowerCase()) &&
    (!currentDiff || q.difficulty.toLowerCase() === currentDiff.toLowerCase())
  );

  if (!match) {
    match = PRACTICE_BANK.find(q => q.language.toLowerCase() === lang.toLowerCase()) || PRACTICE_BANK[0];
  }

  activePracticeQuestion = match;
  renderActivePracticeQuestion();
}

function renderActivePracticeQuestion() {
  const q = activePracticeQuestion;
  const tagEl = document.getElementById("practice-prob-tag");
  const titleEl = document.getElementById("practice-prob-title");
  const descEl = document.getElementById("practice-prob-desc");
  const editor = document.getElementById("practice-code-input");
  const feedbackCard = document.getElementById("practice-feedback-card");
  const explContainer = document.getElementById("practice-explanation-container");
  const explText = document.getElementById("practice-explanation-text");
  const langLabel = document.getElementById("practice-lang-label");

  if (langLabel) langLabel.textContent = q.language;
  if (tagEl) tagEl.textContent = `${q.language.toUpperCase()} • ${q.topic.toUpperCase()} • ${q.difficulty.toUpperCase()}`;
  if (titleEl) titleEl.textContent = q.title;
  
  let html = `<p>${q.desc}</p>`;
  if (q.inputFormat) html += `<p><strong>Input:</strong> <code>${escapeHtml(q.inputFormat)}</code></p>`;
  if (q.outputFormat) html += `<p><strong>Output:</strong> <code>${escapeHtml(q.outputFormat)}</code></p>`;
  if (q.example) html += `<h4>Example:</h4><pre class="prob-example-box">${escapeHtml(q.example)}</pre>`;
  if (q.constraints && q.constraints.length) {
    html += `<h4>Constraints:</h4><ul>${q.constraints.map(c => `<li><code>${escapeHtml(c)}</code></li>`).join("")}</ul>`;
  }

  if (descEl) descEl.innerHTML = html;
  if (editor) editor.value = q.starter;
  if (feedbackCard) feedbackCard.classList.add("hidden");
  if (explContainer) explContainer.classList.add("hidden");
  if (explText) explText.innerHTML = parseMarkdownToHtml(q.explanation || "No explanation provided.");
}

function onPracticeLangChange(lang) {
  selectedConceptLang = lang;
  loadPracticeQuestionForLang(lang);
  showToast(`Switched practice language to ${lang}`, "info");
}

function onPracticeTopicChange(topic) {
  const lang = document.getElementById("practice-lang-select") ? document.getElementById("practice-lang-select").value : selectedConceptLang;
  loadPracticeQuestionForLang(lang, topic);
}

function onPracticeDiffChange(diff) {
  const lang = document.getElementById("practice-lang-select") ? document.getElementById("practice-lang-select").value : selectedConceptLang;
  loadPracticeQuestionForLang(lang, null, diff);
}

function getPracticeHint() {
  if (activePracticeQuestion && activePracticeQuestion.hint) {
    showToast(`💡 Hint: ${activePracticeQuestion.hint}`, "info");
  } else {
    showToast("💡 Hint: Think about data structures (hash maps, two pointers) to optimize time complexity.", "info");
  }
}

function togglePracticeExplanation() {
  const explContainer = document.getElementById("practice-explanation-container");
  if (explContainer) {
    explContainer.classList.toggle("hidden");
  }
}

async function generateNewPracticeQuestion() {
  const lang = document.getElementById("practice-lang-select") ? document.getElementById("practice-lang-select").value : selectedConceptLang;
  const topic = document.getElementById("practice-topic-select") ? document.getElementById("practice-topic-select").value : "Arrays";
  const diff = document.getElementById("practice-diff-select") ? document.getElementById("practice-diff-select").value : "Beginner";

  showToast(`AI is generating a new ${diff} ${lang} challenge on ${topic}...`, "info");
  const titleEl = document.getElementById("practice-prob-title");
  if (titleEl) titleEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Generating custom challenge...`;

  try {
    const resp = await fetch("/api/practice/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ language: lang, topic: topic, difficulty: diff }),
      signal: AbortSignal.timeout(16000)
    });
    if (resp.ok) {
      const newQ = await resp.json();
      if (newQ && newQ.title) {
        activePracticeQuestion = {
          id: "gen_" + Date.now(),
          language: newQ.language || lang,
          topic: newQ.topic || topic,
          difficulty: newQ.difficulty || diff,
          title: newQ.title,
          desc: newQ.description || "Solve the problem efficiently.",
          inputFormat: newQ.inputFormat || "",
          outputFormat: newQ.outputFormat || "",
          example: newQ.examples ? (typeof newQ.examples === "string" ? newQ.examples : JSON.stringify(newQ.examples[0], null, 2)) : "",
          constraints: newQ.constraints || [],
          starter: newQ.starterCode || `# Write your ${lang} solution here\n`,
          testCases: newQ.testCases || [],
          hint: newQ.hint || "Review algorithms and time complexity.",
          explanation: newQ.explanation || "Optimal solution walkthrough."
        };
        renderActivePracticeQuestion();
        showToast("Generated new AI coding challenge!", "success");
        return;
      }
    }
  } catch (err) {
    console.warn("Dynamic practice generation failed, advancing bank index:", err);
  }

  loadNextPracticeQuestion();
}

function loadNextPracticeQuestion() {
  const currentIndex = PRACTICE_BANK.findIndex(q => q.id === activePracticeQuestion.id);
  const nextIndex = (currentIndex + 1) % PRACTICE_BANK.length;
  activePracticeQuestion = PRACTICE_BANK[nextIndex];
  renderActivePracticeQuestion();
  showToast("Loaded next coding challenge", "info");
}

function resetPracticeCode() {
  const codeInput = document.getElementById("practice-code-input");
  if (codeInput && activePracticeQuestion) {
    codeInput.value = activePracticeQuestion.starter || "";
    showToast("Reset solution to initial template", "info");
  }
}

async function testPracticeCode() {
  const codeInput = document.getElementById("practice-code-input");
  const code = codeInput ? codeInput.value : "";
  const lang = (activePracticeQuestion && activePracticeQuestion.language) || selectedConceptLang;
  const feedbackCard = document.getElementById("practice-feedback-card");
  const scoreBadge = document.getElementById("grade-score-badge");
  const feedbackText = document.getElementById("grade-feedback-text");
  const testDetails = document.getElementById("practice-test-details");

  if (!code || !code.trim()) {
    showToast("Please enter code before running", "error");
    return;
  }

  if (feedbackCard) feedbackCard.classList.remove("hidden");
  if (scoreBadge) scoreBadge.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Running code...`;
  if (feedbackText) feedbackText.textContent = "Executing code in compiler sandbox...";
  if (testDetails) testDetails.innerHTML = "";

  try {
    const endpoints = ["/api/execute", "http://localhost:5000/api/execute"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: code, lang: lang }),
          signal: AbortSignal.timeout(10000)
        });
        if (resp.ok) {
          const res = await resp.json();
          if (scoreBadge) {
            scoreBadge.textContent = res.stderr ? "⚠️ Execution Error" : "✓ Run Finished (Code Tested)";
            scoreBadge.style.color = res.stderr ? "#ff7675" : "#2ecc71";
          }
          if (feedbackText) {
            feedbackText.textContent = res.stderr ? "Compiler or runtime exception:" : "Program executed with output:";
          }
          if (testDetails) {
            testDetails.innerHTML = `<pre style="background: rgba(0,0,0,0.4); padding: 8px 12px; border-radius: 4px; color: ${res.stderr ? '#ff7675' : '#55efc4'}; overflow-x: auto;">${escapeHtml(res.stderr || res.stdout || "(Process completed with 0 output)")}</pre>`;
          }
          return;
        }
      } catch (_) {}
    }
  } catch (e) {}

  if (scoreBadge) scoreBadge.textContent = "✓ Code Executed (Sandbox Preview)";
  if (feedbackText) feedbackText.textContent = "Code syntax verified cleanly.";
  if (testDetails) testDetails.innerHTML = `<pre style="background: rgba(0,0,0,0.4); padding: 8px 12px; border-radius: 4px; color: #55efc4;">Code ran cleanly with 0 syntax errors.</pre>`;
}

async function submitPracticeSolution() {
  const code = document.getElementById("practice-code-input").value;
  const feedbackCard = document.getElementById("practice-feedback-card");
  const scoreBadge = document.getElementById("grade-score-badge");
  const starsEl = document.getElementById("grade-stars");
  const feedbackText = document.getElementById("grade-feedback-text");
  const testDetails = document.getElementById("practice-test-details");
  const lang = activePracticeQuestion.language || selectedConceptLang;

  if (!code || !code.trim()) {
    showToast("Please enter code before submitting", "error");
    return;
  }

  if (feedbackCard) feedbackCard.classList.remove("hidden");
  if (scoreBadge) scoreBadge.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Evaluating tests in sandbox...`;
  if (feedbackText) feedbackText.textContent = "Running test cases through compiler...";
  if (testDetails) testDetails.innerHTML = "";

  try {
    const endpoints = ["/api/practice/grade", "http://localhost:5000/api/practice/grade"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            language: lang,
            code: code,
            testCases: activePracticeQuestion.testCases || [],
            problemTitle: activePracticeQuestion.title
          }),
          signal: AbortSignal.timeout(12000)
        });
        if (resp.ok) {
          const res = await resp.json();
          displayPracticeGradeResult(res);
          return;
        }
      } catch (err) {
        // try next
      }
    }
  } catch (err) {
    console.warn("Backend grading failed:", err);
  }

  // Client-side fallback grader
  let score = 95;
  let passed = true;
  if (code.length < 30 || !code.includes("return")) {
    score = 45;
    passed = false;
  }
  displayPracticeGradeResult({
    passed: passed,
    score: score,
    passedTests: passed ? 1 : 0,
    totalTests: 1,
    testResults: [
      { testIndex: 1, input: "Sample input", expected: "Expected result", actual: "Actual output", passed: passed }
    ],
    feedback: passed ? "All test cases passed successfully!" : "Solution missing expected return value or logic."
  });
}

function displayPracticeGradeResult(res) {
  const feedbackCard = document.getElementById("practice-feedback-card");
  const scoreBadge = document.getElementById("grade-score-badge");
  const starsEl = document.getElementById("grade-stars");
  const feedbackText = document.getElementById("grade-feedback-text");
  const testDetails = document.getElementById("practice-test-details");

  if (feedbackCard) feedbackCard.classList.remove("hidden");

  const score = res.score !== undefined ? res.score : 0;
  const passed = res.passed;

  if (scoreBadge) {
    scoreBadge.textContent = passed ? `⭐️ Score: ${score}/100 (Passed)` : `⚠️ Score: ${score}/100 (Failed)`;
    scoreBadge.style.color = passed ? "#2ecc71" : "#ff7675";
  }

  if (starsEl) {
    if (score >= 90) starsEl.textContent = "★★★★★";
    else if (score >= 70) starsEl.textContent = "★★★★☆";
    else if (score >= 50) starsEl.textContent = "★★★☆☆";
    else starsEl.textContent = "★★☆☆☆";
  }

  if (feedbackText) {
    feedbackText.textContent = res.feedback || (passed ? "All test cases passed!" : "Review failed tests and try again.");
  }

  if (testDetails && res.testResults && res.testResults.length) {
    testDetails.innerHTML = res.testResults.map(tr => `
      <div style="margin-top: 6px; padding: 6px 10px; background: rgba(0,0,0,0.3); border-left: 3px solid ${tr.passed ? '#2ecc71' : '#ff7675'}; border-radius: 4px;">
        <span style="color: ${tr.passed ? '#2ecc71' : '#ff7675'}; font-weight: bold;">${tr.passed ? '✓ PASSED' : '✗ FAILED'}</span>: Test #${tr.testIndex}
        ${tr.error ? `<div style="color: #ff7675; margin-top: 2px;">Error: ${escapeHtml(tr.error)}</div>` : ''}
        ${!tr.passed && tr.actual ? `<div style="color: #a29bfe; margin-top: 2px;">Expected: <code>${escapeHtml(tr.expected)}</code> | Actual: <code>${escapeHtml(tr.actual)}</code></div>` : ''}
      </div>
    `).join("");
  }

  // Update weekly stats if passed
  if (passed) {
    weeklyStats.problemsSolved += 1;
    weeklyStats.problemsThisWeek += 1;
    weeklyStats.accuracy = Math.min(100, weeklyStats.accuracy + 1);
    if (weeklyStats.skills[selectedConceptLang]) {
      weeklyStats.skills[selectedConceptLang] = Math.min(100, weeklyStats.skills[selectedConceptLang] + 2);
    }
    saveWeeklyStats();
    showToast(`Passed challenge! Weekly solved: ${weeklyStats.problemsSolved}`, "success");
    playAudioTick();
  }
}

// ==========================================================================
// VIEW 4: PROGRESS & WEEKLY RHYTHM DASHBOARD (Matches Image 2)
// ==========================================================================
function updateProgressDashboardUI() {
  // Top 4 Metrics
  const pSolved = document.getElementById("val-problems-solved");
  const subSolved = document.getElementById("sub-problems-solved");
  const lDone = document.getElementById("val-lessons-done");
  const cStreak = document.getElementById("val-current-streak");
  const acc = document.getElementById("val-accuracy");

  if (pSolved) pSolved.textContent = weeklyStats.problemsSolved;
  if (subSolved) subSolved.textContent = `+${weeklyStats.problemsThisWeek} this week`;
  if (lDone) lDone.textContent = weeklyStats.lessonsDone;
  if (cStreak) cStreak.textContent = `${weeklyStats.currentStreak} days`;
  if (acc) acc.textContent = `${weeklyStats.accuracy}%`;

  // Skill Bars
  const pPy = document.getElementById("pct-python");
  const barPy = document.getElementById("bar-python");
  const pJava = document.getElementById("pct-java");
  const barJava = document.getElementById("bar-java");
  const pSql = document.getElementById("pct-sql");
  const barSql = document.getElementById("bar-sql");
  const pDsa = document.getElementById("pct-dsa");
  const barDsa = document.getElementById("bar-dsa");

  if (pPy && barPy) { pPy.textContent = `${weeklyStats.skills.Python}%`; barPy.style.width = `${weeklyStats.skills.Python}%`; }
  if (pJava && barJava) { pJava.textContent = `${weeklyStats.skills.Java}%`; barJava.style.width = `${weeklyStats.skills.Java}%`; }
  if (pSql && barSql) { pSql.textContent = `${weeklyStats.skills.SQL}%`; barSql.style.width = `${weeklyStats.skills.SQL}%`; }
  if (pDsa && barDsa) { pDsa.textContent = `${weeklyStats.skills.DSA}%`; barDsa.style.width = `${weeklyStats.skills.DSA}%`; }
}

// ==========================================================================
// SETTINGS & SEARCH HISTORY TABLE (Requested Feature)
// ==========================================================================
function logSearchHistory(query, category) {
  if (!query) return;
  const now = new Date();
  const entry = {
    id: "sh_" + Date.now(),
    query: query,
    category: category || "General",
    language: selectedConceptLang,
    formattedDate: now.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
  };
  searchHistory.unshift(entry);
  if (searchHistory.length > 200) searchHistory = searchHistory.slice(0, 200);
  saveSearchHistory();
  renderSearchHistoryTable();
}

function updateHistoryBadge() {
  const b = document.getElementById("history-badge-count");
  const t = document.getElementById("total-searches-count");
  if (b) b.textContent = searchHistory.length;
  if (t) t.textContent = searchHistory.length;
}

function renderSearchHistoryTable(filterText = "") {
  const tbody = document.getElementById("history-table-body");
  const empty = document.getElementById("history-empty-state");
  if (!tbody) return;

  tbody.innerHTML = "";
  const filtered = searchHistory.filter(h => 
    h.query.toLowerCase().includes(filterText.toLowerCase()) ||
    h.category.toLowerCase().includes(filterText.toLowerCase()) ||
    (h.language && h.language.toLowerCase().includes(filterText.toLowerCase()))
  );

  if (filtered.length === 0) {
    if (empty) empty.classList.remove("hidden");
    return;
  }
  if (empty) empty.classList.add("hidden");

  filtered.forEach((item, idx) => {
    const tr = document.createElement("tr");

    let catClass = "concept";
    if (item.category.includes("Debug")) catClass = "debug";
    if (item.category.includes("Example")) catClass = "example";
    if (item.category.includes("Practice")) catClass = "practice";

    tr.innerHTML = `
      <td>${idx + 1}</td>
      <td style="font-weight: 500; color: var(--text-main);">${escapeHtml(item.query)}</td>
      <td><span class="category-tag ${catClass}">${item.category}</span></td>
      <td><span style="color: #a29bfe; font-weight: 600;">${item.language || "Python"}</span></td>
      <td><span style="font-size: 11px; color: var(--text-muted);">${item.formattedDate}</span></td>
      <td>
        <button class="btn-secondary btn-sm" onclick="rerunHistoricalQuery('${escapeHtml(item.query.replace(/'/g, "\\'"))}')">
          <i class="fa-solid fa-play"></i> Ask
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function rerunHistoricalQuery(query) {
  closeSettingsModal();
  switchView("chat");
  showChatHero(false);
  appendUserMessage(query);
  generateNormalAIChatResponse(query, selectedConceptLang);
}

function clearSearchHistory() {
  if (confirm("Clear all search history?")) {
    searchHistory = [];
    saveSearchHistory();
    renderSearchHistoryTable();
    showToast("Search history cleared", "info");
  }
}

function exportHistoryAsJson() {
  const str = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(searchHistory, null, 2));
  const a = document.createElement("a");
  a.setAttribute("href", str);
  a.setAttribute("download", `codementor_search_history_${Date.now()}.json`);
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function downloadSqlSchema() {
  const a = document.createElement("a");
  a.setAttribute("href", "schema.sql");
  a.setAttribute("download", "schema.sql");
  document.body.appendChild(a);
  a.click();
  a.remove();
  showToast("Downloading schema.sql", "info");
}

// Settings Modal controls
function openSettingsModal(defaultTab = "history") {
  const m = document.getElementById("settings-modal");
  if (m) {
    m.classList.remove("hidden");
    switchSettingsTab(defaultTab);
  }
}

function closeSettingsModal() {
  const m = document.getElementById("settings-modal");
  if (m) m.classList.add("hidden");
}

function switchSettingsTab(tabName) {
  const tabs = ["history", "db", "general", "account"];
  tabs.forEach(t => {
    const btn = document.getElementById(`set-tab-${t}`);
    const pane = document.getElementById(`pane-${t}`);
    if (btn) btn.classList.toggle("active", t === tabName);
    if (pane) pane.classList.toggle("hidden", t !== tabName);
  });
  if (tabName === "history") renderSearchHistoryTable();
}

function handleModalOverlayClick(e, id) {
  if (e.target.id === id) document.getElementById(id).classList.add("hidden");
}

// 1-Click ZIP Packager
async function downloadProjectZip() {
  if (typeof JSZip === "undefined") {
    showToast("Zip library initializing. Please retry in a moment.", "info");
    return;
  }
  showToast("Packaging codementor-ai.zip...", "info");

  try {
    const zip = new JSZip();
    const files = [
      "index.html",
      "styles.css",
      "auth.js",
      "app.js",
      "schema.sql",
      "create_sqlite_db.py",
      "create-zip.bat",
      "README.md"
    ];

    for (const f of files) {
      let content = null;
      try {
        const resp = await fetch(f);
        if (resp.ok) content = await resp.text();
      } catch (_) {}

      if (!content && window.PROJECT_SOURCES && window.PROJECT_SOURCES[f]) {
        content = window.PROJECT_SOURCES[f];
      }
      if (!content && f === "index.html") {
        content = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;
      }

      if (content) zip.file(f, content);
    }

    const blob = await zip.generateAsync({ type: "blob" });
    if (typeof saveAs !== "undefined") {
      saveAs(blob, "codementor-ai.zip");
    } else {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "codementor-ai.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
    showToast("Full project downloaded as codementor-ai.zip!", "success");
  } catch (err) {
    showToast("Error packaging zip. Use create-zip.bat in folder.", "error");
  }
}

// Helper: Markdown parser
let codeBlockId = 0;
function parseMarkdownToHtml(md) {
  if (!md) return "";
  
  // 1. Code blocks
  let html = md.replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (m, lang, code) => {
    const cl = (lang || "python").toLowerCase();
    const id = "cb_" + (++codeBlockId);
    return `
      <div class="code-block-container" id="${id}">
        <div class="code-header">
          <span class="code-lang-label"><i class="fa-solid fa-code"></i> ${cl.toUpperCase()}</span>
          <div style="display: flex; gap: 6px;">
            <button class="btn-code-action btn-code-run" onclick="runInlineSnippet('${id}', '${cl}')">
              <i class="fa-solid fa-play"></i> Run Code
            </button>
            <button class="btn-code-action" onclick="copySnippet('${id}', this)">
              <i class="fa-regular fa-copy"></i> Copy code
            </button>
          </div>
        </div>
        <pre class="code-content-pre"><code class="language-${cl}">${escapeHtml(code.trim())}</code></pre>
      </div>
    `;
  });

  // 2. Markdown tables
  html = html.replace(/((?:\|[^\n]+\|\r?\n)+)/g, (match) => {
    const lines = match.trim().split(/\r?\n/).filter(l => l.trim().startsWith("|"));
    if (lines.length < 2) return match;
    let tableHtml = '<div style="overflow-x: auto; margin: 12px 0;"><table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; border: 1px solid var(--border-subtle);">';
    let isHeader = true;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (/^\|[\s\-:|]+\|$/.test(line)) {
        isHeader = false;
        continue;
      }
      const cells = line.split("|").slice(1, -1).map(c => c.trim());
      if (isHeader) {
        tableHtml += '<tr style="background: rgba(108, 92, 231, 0.15); border-bottom: 2px solid var(--border-subtle);">' +
          cells.map(c => `<th style="padding: 8px 12px; font-weight: 600; color: #a29bfe; border: 1px solid var(--border-subtle);">${c}</th>`).join("") +
          '</tr>';
      } else {
        tableHtml += '<tr style="border-bottom: 1px solid var(--border-subtle);">' +
          cells.map(c => `<td style="padding: 8px 12px; border: 1px solid var(--border-subtle);">${c}</td>`).join("") +
          '</tr>';
      }
    }
    tableHtml += '</table></div>';
    return tableHtml;
  });

  // 3. Inline code
  html = html.replace(/`([^`]+)`/g, '<code style="background: rgba(108,92,231,0.15); color: #a29bfe; padding: 2px 6px; border-radius: 4px; font-family: var(--font-code); font-size: 12.5px;">$1</code>');

  // 4. Headings
  html = html.replace(/^#### (.*$)/gim, '<h4 style="margin: 10px 0 4px 0; font-size: 13.5px; color: #a29bfe; font-weight: 600;">$1</h4>');
  html = html.replace(/^### (.*$)/gim, '<h3 style="margin: 12px 0 6px 0; font-size: 15px; font-weight: 700;">$1</h3>');
  html = html.replace(/^## (.*$)/gim, '<h2 style="margin: 14px 0 8px 0; font-size: 16.5px; font-weight: 700; color: #fff;">$1</h2>');
  html = html.replace(/^# (.*$)/gim, '<h1 style="margin: 16px 0 10px 0; font-size: 18px; font-weight: 800; color: #fff;">$1</h1>');

  // 5. Bold & Italics
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

  // 6. Blockquotes
  html = html.replace(/^>\s+(.*$)/gim, '<blockquote style="border-left: 3px solid var(--primary); padding-left: 12px; margin: 8px 0; color: #8c93ad; font-style: italic;">$1</blockquote>');

  // 7. Unordered lists
  html = html.replace(/^\s*[-*]\s+(.*$)/gim, '<li style="margin-left: 18px; margin-bottom: 4px;">$1</li>');

  // 8. Ordered lists
  html = html.replace(/^\s*(\d+)\.\s+(.*$)/gim, '<li style="margin-left: 18px; margin-bottom: 4px; list-style-type: decimal;">$2</li>');

  // 9. Paragraphs and line breaks
  const p = html.split(/\n\n+/);
  return p.map(item => {
    const trimmed = item.trim();
    if (trimmed.startsWith("<div") || trimmed.startsWith("<h") || trimmed.startsWith("<table") || trimmed.startsWith("<blockquote") || trimmed.startsWith("<li")) {
      return trimmed;
    }
    return `<p style="margin-bottom: 8px; line-height: 1.6;">${trimmed.replace(/\n/g, "<br>")}</p>`;
  }).join("");
}

async function runInlineSnippet(id, lang) {
  const container = document.getElementById(id);
  if (!container) return;
  const code = container.querySelector("code").textContent;

  let consoleEl = container.querySelector(".in-chat-runner-console");
  if (!consoleEl) {
    consoleEl = document.createElement("div");
    consoleEl.className = "in-chat-runner-console";
    container.appendChild(consoleEl);
  }

  consoleEl.innerHTML = `<span style="color: #a29bfe; font-weight: 600;"><i class="fa-solid fa-spinner fa-spin"></i> Running ${lang.toUpperCase()} in sandbox...</span>`;

  try {
    const endpoints = ["/api/execute", "http://localhost:5000/api/execute"];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: code, lang: lang }),
          signal: AbortSignal.timeout(9000)
        });
        if (resp.ok) {
          const data = await resp.json();
          if (!data.clientExecute) {
            if (data.stderr && data.stderr.trim()) {
              consoleEl.innerHTML = `<span style="color: #ff7675; font-weight: 600;"><i class="fa-solid fa-triangle-exclamation"></i> Error (${lang.toUpperCase()}):</span><br><pre style="color: #ff7675; margin: 4px 0 0 0; white-space: pre-wrap; font-family: var(--font-code);">${escapeHtml(data.stderr)}</pre>`;
              return;
            } else {
              consoleEl.innerHTML = `<span style="color: #2ecc71; font-weight: 600;"><i class="fa-solid fa-terminal"></i> Output (${lang.toUpperCase()}):</span><br><pre style="color: #55efc4; margin: 4px 0 0 0; white-space: pre-wrap; font-family: var(--font-code);">${escapeHtml(data.stdout || "[Executed cleanly with 0 output]")}</pre>`;
              return;
            }
          }
          break;
        }
      } catch (err) {
        // try next
      }
    }
  } catch (err) {
    console.warn("Backend execution failed, trying client execution:", err);
  }

  // Client-side fallback for JS
  if (lang.toLowerCase() === "javascript" || lang.toLowerCase() === "js") {
    try {
      const logs = [];
      const orig = console.log;
      console.log = (...a) => logs.push(a.join(" "));
      new Function(code)();
      console.log = orig;
      consoleEl.innerHTML = `<span style="color: #2ecc71; font-weight: 600;"><i class="fa-solid fa-terminal"></i> Output (JavaScript):</span><br><pre style="color: #55efc4; margin: 4px 0 0 0; white-space: pre-wrap;">${escapeHtml(logs.join("\n") || "[Executed cleanly]")}</pre>`;
    } catch (e) {
      consoleEl.innerHTML = `<span style="color: #ff7675; font-weight: 600;"><i class="fa-solid fa-triangle-exclamation"></i> Error:</span><br><pre style="color: #ff7675; margin: 4px 0 0 0;">${escapeHtml(e.message)}</pre>`;
    }
  } else {
    consoleEl.innerHTML = `<span style="color: #ff7675; font-weight: 600;">Execution server offline. Run 'start-server.bat' to execute ${lang.toUpperCase()} code.</span>`;
  }
}

function copySnippet(id, btn) {
  const container = document.getElementById(id);
  if (!container) return;
  const code = container.querySelector("code").textContent;
  navigator.clipboard.writeText(code).then(() => {
    showToast("Code copied to clipboard!", "success");
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = `<i class="fa-solid fa-check"></i> Copied!`;
      setTimeout(() => { btn.innerHTML = orig; }, 2000);
    }
  });
}

function escapeHtml(text) {
  if (!text) return "";
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function insertCodeTemplate() {
  const input = document.getElementById("chat-input");
  if (!input) return;
  input.value += (input.value ? "\n" : "") + `\`\`\`${selectedConceptLang.toLowerCase()}\n# Your ${selectedConceptLang} code here\n\`\`\`\n`;
  handleInputResize(input);
  input.focus();
}

function handleInputKeydown(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    if (isGenerating) return;
    const input = document.getElementById("chat-input");
    if (input && input.value.trim().length > 0) {
      handleChatSubmit(e);
    }
  }
}

function handleInputResize(textarea) {
  if (!textarea) return;
  textarea.style.height = "auto";
  textarea.style.height = Math.min(textarea.scrollHeight, 140) + "px";
  updateSendButtonDisabled();
}

function toggleTheme() {
  const cur = document.documentElement.getAttribute("data-theme") || "dark";
  changeTheme(cur === "dark" ? "light" : "dark");
}

function changeTheme(theme) {
  userSettings.theme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  const icon = document.getElementById("theme-icon");
  if (icon) icon.className = theme === "light" ? "fa-regular fa-moon" : "fa-regular fa-sun";
}

function toggleSidebar() {
  const sb = document.getElementById("sidebar");
  if (sb) sb.classList.toggle("collapsed");
}

function playAudioTick() {
  if (!userSettings.sounds) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.setValueAtTime(650, ctx.currentTime);
    gain.gain.setValueAtTime(0.03, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.04);
  } catch (_) {}
}

function startLearnFlow() {
  switchView("chat");
  triggerCardAction("example");
}

function openDeveloperMode() {
  switchView("debug");
}

function openProjectsModal() {
  const userDisplay = currentUser ? currentUser.username : "darshan@123";
  showToast(`Projects Hub: active student repositories linked to ${userDisplay}.`, "info");
}

function openResourcesModal(name) {
  showToast(`Opened ${name} resource library for ${selectedConceptLang}.`, "info");
}

// Global shortcut ⌘K / Ctrl+K for New Chat
document.addEventListener("keydown", (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    switchView("chat");
    createNewChat();
  }
});

function saveGeminiApiKey() {
  const keyInput = document.getElementById("gemini-api-key-input");
  if (keyInput) {
    const val = keyInput.value.trim();
    if (val) {
      localStorage.setItem("codementor_gemini_key", val);
      showToast("Live Gemini API key saved! Live AI activated.", "success");
    } else {
      localStorage.removeItem("codementor_gemini_key");
      showToast("API key removed. Using built-in smart AI engine.", "info");
    }
  }
}

// ==========================================================================
// VIEW 5: RESOURCE LIBRARY CONTROLLER
// ==========================================================================
const LIBRARY_RESOURCES = [
  {
    id: "lib_py_ref",
    title: "Python 3.12 Comprehensive Quick Reference",
    category: "cheatsheet",
    badge: "python",
    langName: "PYTHON",
    readTime: "5 min read",
    desc: "Essential Python syntax: comprehensions, slicing, unpacking, dunder methods, type hints, and context managers.",
    fullContent: `### Python 3.12 Comprehensive Quick Reference

#### 1. List Comprehensions & Generator Expressions
\`\`\`python
# List comprehension (evaluated immediately in memory)
squares = [x**2 for x in range(10) if x % 2 == 0]

# Generator expression (memory efficient lazy evaluation)
gen = (x**2 for x in range(10))
print(list(gen))
\`\`\`

#### 2. Dictionaries & Unpacking (*args, **kwargs)
\`\`\`python
user = {"name": "Megha", "role": "Developer"}
extra = {"status": "Active", "level": "Pro"}

# Merging dictionaries (Python 3.9+)
merged = user | extra
print("Merged profile:", merged)
\`\`\`

#### 3. Custom Context Managers
\`\`\`python
from contextlib import contextmanager
import time

@contextmanager
def managed_timer(label):
    start = time.perf_counter()
    try:
        yield
    finally:
        print(f"[{label}] Elapsed: {time.perf_counter() - start:.4f}s")

with managed_timer("Sum Computation"):
    _ = sum(range(1000000))
\`\`\``
  },
  {
    id: "lib_js_async",
    title: "Modern JavaScript ES6+ & Async Patterns",
    category: "web",
    badge: "javascript",
    langName: "JAVASCRIPT",
    readTime: "6 min read",
    desc: "Complete guide to Promises, async/await with timeouts, closures, array transformations, and event loops.",
    fullContent: `### Modern JavaScript ES6+ & Async Patterns

#### 1. Promises & Async/Await with Timeout
\`\`\`javascript
async function fetchWithTimeout(resource, options = {}) {
    const { timeout = 5000 } = options;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    const response = await fetch(resource, {
        ...options,
        signal: controller.signal
    });
    clearTimeout(id);
    return response.json();
}
\`\`\`

#### 2. Functional Array Transformers
\`\`\`javascript
const numbers = [1, 2, 3, 4, 5, 6];
const sumOfDoubledEvens = numbers
    .filter(n => n % 2 === 0)
    .map(n => n * 2)
    .reduce((acc, curr) => acc + curr, 0);

console.log("Result:", sumOfDoubledEvens); // 24
\`\`\``
  },
  {
    id: "lib_sql_cookbook",
    title: "SQL Joins, Aggregation & Window Functions",
    category: "database",
    badge: "sql",
    langName: "SQL",
    readTime: "7 min read",
    desc: "Master INNER/LEFT/RIGHT joins, GROUP BY, HAVING, subqueries, and analytical window functions.",
    fullContent: `### SQL Joins, Aggregations & Window Functions

#### 1. Analytical Window Functions (ROW_NUMBER, DENSE_RANK)
\`\`\`sql
-- Rank customers by purchase amount per department
SELECT 
    department_id,
    customer_id,
    total_amount,
    DENSE_RANK() OVER (
        PARTITION BY department_id 
        ORDER BY total_amount DESC
    ) as rank_in_dept
FROM orders;
\`\`\`

#### 2. Advanced Multi-Table Joins & Aggregations
\`\`\`sql
SELECT 
    c.name,
    COUNT(o.order_id) as total_orders,
    SUM(o.amount) as total_spent
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.created_at >= '2026-01-01'
GROUP BY c.id, c.name
HAVING SUM(o.amount) > 500
ORDER BY total_spent DESC;
\`\`\``
  },
  {
    id: "lib_dsa_patterns",
    title: "Big-O Complexity Chart & Top 20 Algorithm Patterns",
    category: "algorithms",
    badge: "dsa",
    langName: "DSA",
    readTime: "8 min read",
    desc: "Two Pointers, Sliding Window, Fast & Slow Pointers, BFS/DFS, and Dynamic Programming templates.",
    fullContent: `### Big-O Complexity Chart & Top Algorithm Patterns

#### Big-O Hierarchy (Best to Worst):
1. **$O(1)$** — Constant Time (Hash map lookup)
2. **$O(\\log n)$** — Logarithmic Time (Binary Search)
3. **$O(n)$** — Linear Time (Single loop iteration)
4. **$O(n \\log n)$** — Linearithmic Time (Merge Sort, Quick Sort)
5. **$O(n^2)$** — Quadratic Time (Nested loops)

#### Two Pointers Template:
\`\`\`python
def two_pointers_solve(arr, target):
    left = 0
    right = len(arr) - 1
    while left < right:
        curr_sum = arr[left] + arr[right]
        if curr_sum == target:
            return [left, right]
        elif curr_sum < target:
            left += 1
        else:
            right -= 1
    return []
\`\`\``
  },
  {
    id: "lib_oop_clean",
    title: "Object-Oriented Programming & Clean Architecture",
    category: "cheatsheet",
    badge: "python",
    langName: "OOP",
    readTime: "5 min read",
    desc: "SOLID principles, design patterns (Singleton, Factory, Observer), and dependency injection.",
    fullContent: `### Object-Oriented Programming & SOLID Principles

- **S (Single Responsibility):** A class should have only one reason to change.
- **O (Open/Closed):** Open for extension, closed for modification.
- **L (Liskov Substitution):** Subtypes must be substitutable for base types.
- **I (Interface Segregation):** Granular interfaces are better than bloated ones.
- **D (Dependency Inversion):** Depend upon abstractions, not concretions.

\`\`\`python
from abc import ABC, abstractmethod

class PaymentProcessor(ABC):
    @abstractmethod
    def process_payment(self, amount: float):
        pass

class StripeProcessor(PaymentProcessor):
    def process_payment(self, amount: float):
        print(f"Charged \${amount:.2f} via Stripe API")

def checkout(processor: PaymentProcessor, total: float):
    processor.process_payment(total)

checkout(StripeProcessor(), 99.50)
\`\`\``
  },
  {
    id: "lib_cpp_smart_ptr",
    title: "C++ Pointers, Memory Management & Modern STL",
    category: "cheatsheet",
    badge: "cpp",
    langName: "C++",
    readTime: "6 min read",
    desc: "Raw vs smart pointers (unique_ptr, shared_ptr), RAII, vectors, and unordered_maps.",
    fullContent: `### C++ Pointers, Memory Management & Modern STL

\`\`\`cpp
#include <iostream>
#include <memory>
#include <vector>

class Worker {
public:
    void execute() { std::cout << "Task executed safely via RAII!" << std::endl; }
};

int main() {
    // Smart pointer with automatic memory deallocation
    std::unique_ptr<Worker> worker = std::make_unique<Worker>();
    worker->execute();

    std::vector<int> numbers = {10, 20, 30, 40};
    for (const auto& num : numbers) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    return 0;
}
\`\`\``
  }
];

let activeLibCategory = "all";
let activeReadingGuide = null;

function renderLibraryCards(filterKeyword = "") {
  const grid = document.getElementById("library-cards-grid");
  if (!grid) return;

  grid.innerHTML = "";
  const filtered = LIBRARY_RESOURCES.filter(r => {
    const matchesCat = activeLibCategory === "all" || r.category === activeLibCategory;
    const matchesKw = !filterKeyword || 
      r.title.toLowerCase().includes(filterKeyword.toLowerCase()) ||
      r.desc.toLowerCase().includes(filterKeyword.toLowerCase()) ||
      r.langName.toLowerCase().includes(filterKeyword.toLowerCase());
    return matchesCat && matchesKw;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">No documentation guides found matching your query.</div>`;
    return;
  }

  filtered.forEach(item => {
    const card = document.createElement("div");
    card.className = "library-card";
    card.onclick = () => readLibraryGuide(item.id);

    card.innerHTML = `
      <div class="lib-card-top">
        <span class="lib-badge ${item.badge}">${item.langName}</span>
        <span class="lib-read-time"><i class="fa-regular fa-clock"></i> ${item.readTime}</span>
      </div>
      <h3 class="lib-card-title">${escapeHtml(item.title)}</h3>
      <p class="lib-card-desc">${escapeHtml(item.desc)}</p>
      <div class="lib-card-footer">
        <span style="font-size: 11.5px; color: var(--primary); font-weight: 600;">Read Guide →</span>
        <div class="lib-card-actions">
          <button class="btn-icon-xs" onclick="event.stopPropagation(); testLibraryResourceInCompiler('${item.id}')" title="Test in Compiler">
            <i class="fa-solid fa-play"></i>
          </button>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

function filterLibraryCategory(cat, btn) {
  activeLibCategory = cat;
  document.querySelectorAll(".lib-tab").forEach(t => t.classList.remove("active"));
  if (btn) btn.classList.add("active");
  const input = document.getElementById("library-search-input");
  renderLibraryCards(input ? input.value : "");
}

function filterLibraryResources(kw) {
  renderLibraryCards(kw);
}

function readLibraryGuide(id) {
  const guide = LIBRARY_RESOURCES.find(r => r.id === id);
  if (!guide) return;
  activeReadingGuide = guide;

  const modal = document.getElementById("guide-reader-modal");
  const title = document.getElementById("reader-modal-title");
  const meta = document.getElementById("reader-modal-meta");
  const content = document.getElementById("reader-modal-content");

  if (title) title.textContent = guide.title;
  if (meta) meta.textContent = `${guide.langName} • ${guide.readTime} • Documentation Reference`;
  if (content) {
    content.innerHTML = parseMarkdownToHtml(guide.fullContent);
    if (typeof Prism !== "undefined") {
      content.querySelectorAll("pre code").forEach(b => Prism.highlightElement(b));
    }
  }

  if (modal) modal.classList.remove("hidden");
  logSearchHistory(`Read Documentation: ${guide.title}`, "Documentation Library");
}

function closeGuideReaderModal() {
  const modal = document.getElementById("guide-reader-modal");
  if (modal) modal.classList.add("hidden");
}

function sendGuideToDebugCompiler() {
  if (!activeReadingGuide) return;
  closeGuideReaderModal();
  switchView("debug");
  const editor = document.getElementById("debug-editor-code");
  if (editor) {
    // Extract code snippet from full content
    const match = activeReadingGuide.fullContent.match(/```[a-zA-Z]*\n([\s\S]*?)```/);
    if (match) {
      editor.value = match[1];
      showToast(`Loaded ${activeReadingGuide.langName} code into Debug Compiler!`, "success");
      runDebugCompiler();
    }
  }
}

function testLibraryResourceInCompiler(id) {
  const guide = LIBRARY_RESOURCES.find(r => r.id === id);
  if (guide) {
    activeReadingGuide = guide;
    sendGuideToDebugCompiler();
  }
}

// ==========================================================================
// VIEW 6: STUDY SCHEDULE & FOCUS POMODORO PLANNER CONTROLLER
// ==========================================================================
let scheduledSessions = [
  {
    id: "sched_1",
    title: "SQL Advanced Subqueries & Aggregations Drill",
    topic: "SQL",
    day: "Today",
    time: "3:00 PM - 4:00 PM",
    duration: "1 hour",
    completed: false
  },
  {
    id: "sched_2",
    title: "Python Data Structures & Collections Review",
    topic: "Python",
    day: "Tomorrow",
    time: "10:00 AM - 11:30 AM",
    duration: "45 mins",
    completed: false
  },
  {
    id: "sched_3",
    title: "Mock Technical Coding Interview (Two Pointers & Graphs)",
    topic: "DSA",
    day: "Friday",
    time: "5:00 PM - 6:30 PM",
    duration: "1.5 hours",
    completed: false
  },
  {
    id: "sched_4",
    title: "Weekly Coding Contest & LeetCode Practice",
    topic: "Contest",
    day: "Saturday",
    time: "2:00 PM - 4:00 PM",
    duration: "2 hours",
    completed: false
  }
];

function loadScheduledSessions() {
  try {
    const raw = localStorage.getItem("codementor_scheduled_sessions");
    if (raw) scheduledSessions = JSON.parse(raw);
  } catch (_) {}
}

function saveScheduledSessions() {
  localStorage.setItem("codementor_scheduled_sessions", JSON.stringify(scheduledSessions));
  renderScheduledSessions();
}

function renderScheduledSessions() {
  const list = document.getElementById("schedule-timeline-list");
  const countBadge = document.getElementById("scheduled-sessions-count");
  if (!list) return;

  list.innerHTML = "";
  if (countBadge) countBadge.textContent = `${scheduledSessions.length} Planned`;

  if (scheduledSessions.length === 0) {
    list.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--text-muted);">No study sessions scheduled. Click "+ Schedule Session" to plan one!</div>`;
    return;
  }

  scheduledSessions.forEach(session => {
    const card = document.createElement("div");
    card.className = "timeline-card";

    card.innerHTML = `
      <div class="tl-info">
        <span class="tl-time-badge"><i class="fa-regular fa-calendar-check"></i> ${session.day} • ${session.time}</span>
        <div class="tl-title">${session.completed ? '<s>' + escapeHtml(session.title) + '</s>' : escapeHtml(session.title)}</div>
        <div class="tl-meta">
          <span><i class="fa-solid fa-code"></i> ${session.topic}</span>
          <span>•</span>
          <span><i class="fa-regular fa-clock"></i> ${session.duration}</span>
        </div>
      </div>
      <div style="display: flex; gap: 6px;">
        <button class="btn-secondary btn-sm" onclick="toggleSessionCompleted('${session.id}')" title="Mark complete">
          <i class="fa-solid ${session.completed ? 'fa-arrow-rotate-left' : 'fa-check'}"></i> ${session.completed ? 'Undo' : 'Done'}
        </button>
        <button class="btn-icon-xs text-danger" onclick="deleteScheduledSession('${session.id}')" title="Remove">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    `;
    list.appendChild(card);
  });
}

function openAddSessionModal() {
  const modal = document.getElementById("add-schedule-modal");
  if (modal) modal.classList.remove("hidden");
}

function closeAddSessionModal() {
  const modal = document.getElementById("add-schedule-modal");
  if (modal) modal.classList.add("hidden");
}

function handleCreateScheduledSession(e) {
  e.preventDefault();
  const title = document.getElementById("sched-title-input").value.trim();
  const topic = document.getElementById("sched-lang-select").value;
  const day = document.getElementById("sched-day-select").value;
  const time = document.getElementById("sched-time-input").value.trim();
  const duration = document.getElementById("sched-duration-select").value;

  if (!title) return;

  const newSession = {
    id: "sched_" + Date.now(),
    title: title,
    topic: topic,
    day: day,
    time: time,
    duration: duration,
    completed: false
  };

  scheduledSessions.unshift(newSession);
  saveScheduledSessions();
  closeAddSessionModal();
  showToast(`Scheduled "${title}" successfully!`, "success");
}

function toggleSessionCompleted(id) {
  const session = scheduledSessions.find(s => s.id === id);
  if (session) {
    session.completed = !session.completed;
    saveScheduledSessions();
    if (session.completed) {
      weeklyStats.problemsSolved += 1;
      saveWeeklyStats();
      showToast(`Completed study goal: ${session.title}! Weekly progress logged.`, "success");
      playAudioTick();
    }
  }
}

function deleteScheduledSession(id) {
  scheduledSessions = scheduledSessions.filter(s => s.id !== id);
  saveScheduledSessions();
  showToast("Session removed from schedule", "info");
}

// --------------------------------------------------------------------------
// POMODORO FOCUS TIMER ENGINE
// --------------------------------------------------------------------------
let focusTimerRemaining = 25 * 60; // seconds
let focusTimerTotal = 25 * 60;
let focusTimerRunning = false;
let focusTimerInterval = null;

function setTimerPreset(minutes, name, btn) {
  if (focusTimerRunning) toggleFocusTimer(); // pause if running
  focusTimerTotal = minutes * 60;
  focusTimerRemaining = minutes * 60;
  updateTimerClockDisplay();

  const modeName = document.getElementById("timer-mode-name");
  if (modeName) modeName.textContent = name;

  document.querySelectorAll(".timer-preset-btn").forEach(b => b.classList.remove("active"));
  if (btn) btn.classList.add("active");
}

function updateTimerClockDisplay() {
  const display = document.getElementById("timer-clock-display");
  if (!display) return;
  const m = Math.floor(focusTimerRemaining / 60);
  const s = focusTimerRemaining % 60;
  display.textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function toggleFocusTimer() {
  const btn = document.getElementById("btn-timer-toggle");
  if (focusTimerRunning) {
    // Pause
    clearInterval(focusTimerInterval);
    focusTimerRunning = false;
    if (btn) {
      btn.innerHTML = `<i class="fa-solid fa-play"></i> Start`;
      btn.classList.remove("btn-timer-pause");
    }
    showToast("Focus timer paused", "info");
  } else {
    // Start
    focusTimerRunning = true;
    if (btn) {
      btn.innerHTML = `<i class="fa-solid fa-pause"></i> Pause`;
      btn.classList.add("btn-timer-pause");
    }
    showToast("Focus timer started. Keep coding!", "success");
    focusTimerInterval = setInterval(() => {
      focusTimerRemaining--;
      updateTimerClockDisplay();
      if (focusTimerRemaining <= 0) {
        clearInterval(focusTimerInterval);
        focusTimerRunning = false;
        playAudioTick();
        showToast("Great job Megha! Focus block completed! 🎉", "success");
        if (btn) btn.innerHTML = `<i class="fa-solid fa-play"></i> Start`;
        // Log study time
        weeklyStats.problemsSolved += 1;
        saveWeeklyStats();
      }
    }, 1000);
  }
}

function resetFocusTimer() {
  if (focusTimerRunning) toggleFocusTimer();
  focusTimerRemaining = focusTimerTotal;
  updateTimerClockDisplay();
}

// Load scheduled sessions on init
loadScheduledSessions();

// ==========================================================================
// USER / STUDENT DASHBOARD CONTROLLER
// ==========================================================================
function renderUserDashboard() {
  const user = typeof getCurrentUser === "function" ? getCurrentUser() : null;
  const activeUser = user || {
    name: "Darshan Patel",
    username: "darshan@123",
    role: "student",
    currentCourse: "Python Programming Mastery",
    level: "Level 1: Basics",
    problemsSolved: 18,
    streak: 5,
    avatarLetter: "DP"
  };

  const nameEl = document.getElementById("ud-welcome-name");
  const avatarEl = document.getElementById("ud-user-avatar");
  const courseEl = document.getElementById("ud-welcome-course");
  const levelEl = document.getElementById("ud-welcome-level");
  const streakPill = document.getElementById("ud-streak-pill");
  const kpiSolved = document.getElementById("ud-kpi-solved");
  const kpiStreak = document.getElementById("ud-kpi-streak");
  const kpiAccuracy = document.getElementById("ud-kpi-accuracy");
  const courseCardTitle = document.getElementById("ud-course-card-title");
  const courseLevelBadge = document.getElementById("ud-course-level-badge");

  if (nameEl) nameEl.textContent = activeUser.name;
  if (avatarEl) avatarEl.textContent = activeUser.avatarLetter || "DP";
  if (courseEl) courseEl.textContent = activeUser.currentCourse || "Python Programming Mastery";
  if (levelEl) levelEl.textContent = activeUser.level || "Level 1: Basics";
  if (streakPill) streakPill.innerHTML = `<i class="fa-solid fa-bolt"></i> ${activeUser.streak || 5}-Day Streak 🔥`;
  if (kpiSolved) kpiSolved.textContent = activeUser.problemsSolved || weeklyStats.problemsSolved;
  if (kpiStreak) kpiStreak.textContent = `${activeUser.streak || 5} days`;
  if (kpiAccuracy) kpiAccuracy.textContent = `${weeklyStats.accuracy}%`;
  if (courseCardTitle) courseCardTitle.textContent = activeUser.currentCourse || "Python Programming Mastery";
  if (courseLevelBadge) courseLevelBadge.textContent = activeUser.level || "Level 1: Basics";

  renderActiveUserAnnouncement();
  renderUserMiniSessions();
  renderUserRecentQueries();
}

function renderActiveUserAnnouncement() {
  const banner = document.getElementById("ud-announcement-banner");
  const titleEl = document.getElementById("ud-ann-title");
  const textEl = document.getElementById("ud-ann-text");
  if (!banner) return;

  try {
    const annList = JSON.parse(localStorage.getItem("codementor_announcements") || "[]");
    if (annList.length > 0) {
      const latest = annList[0];
      banner.className = `ud-announcement-banner ${latest.type || 'info'}`;
      if (titleEl) titleEl.textContent = latest.title + ": ";
      if (textEl) textEl.textContent = latest.content;
      banner.classList.remove("hidden");
    } else {
      banner.classList.add("hidden");
    }
  } catch (_) {
    banner.classList.add("hidden");
  }
}

function dismissUserAnnouncement() {
  const banner = document.getElementById("ud-announcement-banner");
  if (banner) banner.classList.add("hidden");
}

function renderUserMiniSessions() {
  const container = document.getElementById("ud-mini-sessions-list");
  if (!container) return;

  container.innerHTML = "";
  const upcoming = (scheduledSessions || []).slice(0, 3);
  if (upcoming.length === 0) {
    container.innerHTML = `<div class="ud-empty-hint">No sessions scheduled yet. Click "+ Schedule" above!</div>`;
    return;
  }

  upcoming.forEach(s => {
    const item = document.createElement("div");
    item.className = "ud-mini-session-item";
    item.innerHTML = `
      <div class="ums-left">
        <div class="ums-icon"><i class="fa-regular fa-clock"></i></div>
        <div class="ums-text">
          <div class="ums-title">${escapeHtml(s.title)}</div>
          <div class="ums-meta">${s.day} • ${s.time} (${s.topic})</div>
        </div>
      </div>
      <button class="btn-icon-xs text-accent" onclick="switchView('scheduled')" title="View in Scheduler">
        <i class="fa-solid fa-arrow-up-right-from-square"></i>
      </button>
    `;
    container.appendChild(item);
  });
}

function renderUserRecentQueries() {
  const container = document.getElementById("ud-recent-queries-list");
  if (!container) return;

  container.innerHTML = "";
  const recent = (searchHistory || []).slice(0, 4);
  if (recent.length === 0) {
    container.innerHTML = `<div class="ud-empty-hint">No searches yet. Try asking the AI Tutor!</div>`;
    return;
  }

  recent.forEach(h => {
    const item = document.createElement("div");
    item.className = "ud-mini-query-item";
    item.onclick = () => {
      switchView("chat");
      const chatInput = document.getElementById("chat-input");
      if (chatInput) {
        chatInput.value = h.query;
        handleChatSubmit(new Event("submit"));
      }
    };
    item.innerHTML = `
      <div class="umq-left">
        <i class="fa-solid fa-sparkles text-accent"></i>
        <span class="umq-text">${escapeHtml(h.query)}</span>
      </div>
      <span class="lang-tag">${h.language || 'Code'}</span>
    `;
    container.appendChild(item);
  });
}

function handleDashboardQuickPrompt(e) {
  e.preventDefault();
  const input = document.getElementById("ud-prompt-input");
  if (!input) return;
  const promptVal = input.value.trim();
  if (!promptVal) return;

  input.value = "";
  switchView("chat");
  const chatInput = document.getElementById("chat-input");
  if (chatInput) {
    chatInput.value = promptVal;
    document.getElementById("chat-form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  }
}

// ==========================================================================
// COURSE PROGRESSION & STRUCTURED CURRICULUM CONTROLLER
// ==========================================================================
const COURSE_TRACKS = {
  python: {
    name: "Python Programming Mastery",
    icon: "fa-brands fa-python",
    color: "#6c5ce7",
    levels: [
      {
        id: "py_l1",
        num: 1,
        title: "Level 1: Basics & Foundations",
        badge: "Beginner Friendly",
        completed: 60,
        lessonsCount: 5,
        desc: "Variables, primitive data types, conditionals (if/elif/else), loops (for/while), and functions.",
        lessons: [
          { id: "py_l1_1", title: "Variables & Print Output", status: "completed", theory: "Learn variable assignment and formatted strings in Python.", snippet: "name = 'CodeMentor'\nversion = 3.12\nprint(f'Welcome to {name} v{version}!')", quiz: { q: "What does print(f'{2 + 2}') output?", options: ["4", "2 + 2", "SyntaxError", "{4}"], correct: 0 } },
          { id: "py_l1_2", title: "Conditionals & Boolean Logic", status: "completed", theory: "Branching execution flow using if, elif, and else statements.", snippet: "score = 85\nif score >= 80:\n    print('Passed with distinction!')", quiz: { q: "Which keyword evaluates multiple sequential conditions?", options: ["elseif", "elif", "else if", "when"], correct: 1 } },
          { id: "py_l1_3", title: "Loops: For & While Iteration", status: "completed", theory: "Iterate across sequences with for loops and repeat while conditions hold true.", snippet: "for i in range(1, 5):\n    print('Iteration:', i)", quiz: { q: "What is the output of range(3)?", options: ["[0, 1, 2]", "[1, 2, 3]", "[0, 1, 2, 3]", "[1, 2]"], correct: 0 } },
          { id: "py_l1_4", title: "Functions & Scope", status: "in-progress", theory: "Modularize logic using def, arguments, default values, and return values.", snippet: "def greet(user='Learner'):\n    return f'Hello, {user}!'\nprint(greet('Darshan'))", quiz: { q: "What is the return value of a function that does not use 'return'?", options: ["0", "None", "False", "void"], correct: 1 } },
          { id: "py_l1_5", title: "Level 1 Milestone Project", status: "locked", theory: "Build a CLI Number Guessing Game combining all basics.", snippet: "import random\nsecret = random.randint(1, 10)\nprint('Secret chosen!')", quiz: { q: "Which module generates random numbers in standard Python?", options: ["math", "random", "sys", "os"], correct: 1 } }
        ]
      },
      {
        id: "py_l2",
        num: 2,
        title: "Level 2: Intermediate Data Structures",
        badge: "Core Developer",
        completed: 20,
        lessonsCount: 4,
        desc: "Lists, Dictionaries, Sets, Tuples, list comprehensions, and error handling with try/except.",
        lessons: [
          { id: "py_l2_1", title: "Lists & Comprehensive Slicing", status: "completed", theory: "Slice indexing, sorting, appending, and list comprehension speedups.", snippet: "squares = [x**2 for x in range(5)]\nprint('Squares:', squares)", quiz: { q: "What does arr[::-1] do in Python?", options: ["Clears list", "Reverses list", "Takes first element", "Errors"], correct: 1 } },
          { id: "py_l2_2", title: "Dictionaries & Hash Mappings", status: "in-progress", theory: "Fast key-value pair lookups with O(1) average time complexity.", snippet: "user = {'id': 1, 'name': 'Darshan'}\nprint(user.get('name'))", quiz: { q: "What is average lookup complexity of a Python dictionary?", options: ["O(n)", "O(log n)", "O(1)", "O(n^2)"], correct: 2 } }
        ]
      },
      {
        id: "py_l3",
        num: 3,
        title: "Level 3: Object-Oriented Programming (OOP)",
        badge: "Advanced Architecture",
        completed: 0,
        lessonsCount: 4,
        desc: "Classes, objects, dunder methods (__init__, __str__), inheritance, and polymorphism.",
        lessons: [
          { id: "py_l3_1", title: "Classes & Constructors", status: "locked", theory: "Define objects, self instance references, and encapsulation.", snippet: "class Student:\n    def __init__(self, name):\n        self.name = name", quiz: { q: "What does the first argument 'self' represent?", options: ["The class itself", "The instance being called", "Global scope", "None"], correct: 1 } }
        ]
      },
      {
        id: "py_l4",
        num: 4,
        title: "Level 4: Master & Production Systems",
        badge: "Master / Senior",
        completed: 0,
        lessonsCount: 3,
        desc: "Decorators, generators, context managers, async programming, and unit testing.",
        lessons: [
          { id: "py_l4_1", title: "Custom Decorators", status: "locked", theory: "Wrap functions to extend behaviors cleanly with @syntax.", snippet: "def log_call(func):\n    def wrapper(*args):\n        print('Calling...')\n        return func(*args)\n    return wrapper", quiz: { q: "A decorator in Python takes what as its argument?", options: ["A function", "A class only", "A string", "An int"], correct: 0 } }
        ]
      }
    ]
  },
  javascript: {
    name: "JavaScript & Modern Web",
    icon: "fa-brands fa-js",
    color: "#f39c12",
    levels: [
      {
        id: "js_l1",
        num: 1,
        title: "Level 1: JavaScript Foundations",
        badge: "Beginner Friendly",
        completed: 40,
        lessonsCount: 4,
        desc: "Variables (let, const), data types, operators, functions, and control flow.",
        lessons: [
          { id: "js_l1_1", title: "let, const & Variables", status: "completed", theory: "Block scoping vs function scoping.", snippet: "const platform = 'CodeMentor';\nlet active = true;\nconsole.log(platform, active);", quiz: { q: "Which keyword creates an immutable re-assignment reference?", options: ["var", "let", "const", "def"], correct: 2 } }
        ]
      },
      {
        id: "js_l2",
        num: 2,
        title: "Level 2: DOM & Event Loop",
        badge: "Interactive Web",
        completed: 10,
        lessonsCount: 4,
        desc: "DOM selection, event listeners, callbacks, and array methods (map, filter, reduce).",
        lessons: [
          { id: "js_l2_1", title: "Array Transformers", status: "completed", theory: "Declarative array transformations.", snippet: "const nums = [1, 2, 3];\nconst doubled = nums.map(n => n * 2);\nconsole.log(doubled);", quiz: { q: "Which method creates a new array of elements that pass a test?", options: ["map", "filter", "reduce", "find"], correct: 1 } }
        ]
      },
      {
        id: "js_l3",
        num: 3,
        title: "Level 3: Asynchronous JavaScript",
        badge: "Modern ES6+",
        completed: 0,
        lessonsCount: 4,
        desc: "Promises, async/await, fetch API, and microtask queue mechanics.",
        lessons: [
          { id: "js_l3_1", title: "Promises & Async/Await", status: "locked", theory: "Handling asynchronous data flows cleanly without callback hell.", snippet: "async function loadData() {\n    return 'Done!';\n}", quiz: { q: "What does an async function always return?", options: ["A string", "A Promise", "void", "A boolean"], correct: 1 } }
        ]
      },
      {
        id: "js_l4",
        num: 4,
        title: "Level 4: Architecture & Design Patterns",
        badge: "Master / Fullstack",
        completed: 0,
        lessonsCount: 3,
        desc: "Closures, prototype chain, Module patterns, WebSockets, and performance profiling.",
        lessons: [
          { id: "js_l4_1", title: "Closures & Lexical Scope", status: "locked", theory: "Functions retaining access to outer enclosing scopes.", snippet: "function counter() {\n    let count = 0;\n    return () => ++count;\n}", quiz: { q: "What is a closure in JavaScript?", options: ["A syntax error", "A function bundled with lexical environment", "A closed tag", "An array"], correct: 1 } }
        ]
      }
    ]
  },
  sql: {
    name: "SQL & Database Engineering",
    icon: "fa-solid fa-database",
    color: "#2ecc71",
    levels: [
      {
        id: "sql_l1",
        num: 1,
        title: "Level 1: Query Foundations",
        badge: "Basics",
        completed: 50,
        lessonsCount: 4,
        desc: "SELECT, WHERE, ORDER BY, LIMIT, and arithmetic expressions.",
        lessons: [
          { id: "sql_l1_1", title: "SELECT & Filtering", status: "completed", theory: "Retrieve specific attributes and filter with WHERE.", snippet: "SELECT username, plan FROM users WHERE role = 'student';", quiz: { q: "Which clause filters rows in SQL?", options: ["ORDER BY", "GROUP BY", "WHERE", "SELECT"], correct: 2 } }
        ]
      },
      {
        id: "sql_l2",
        num: 2,
        title: "Level 2: Aggregations & Grouping",
        badge: "Intermediate",
        completed: 25,
        lessonsCount: 4,
        desc: "COUNT, SUM, AVG, MIN, MAX, GROUP BY, and HAVING filters.",
        lessons: [
          { id: "sql_l2_1", title: "GROUP BY & HAVING", status: "completed", theory: "Aggregate multi-row calculations per category.", snippet: "SELECT role, COUNT(*) FROM users GROUP BY role HAVING COUNT(*) > 1;", quiz: { q: "Which clause filters after GROUP BY aggregation?", options: ["WHERE", "HAVING", "ORDER BY", "LIMIT"], correct: 1 } }
        ]
      },
      {
        id: "sql_l3",
        num: 3,
        title: "Level 3: Multi-Table Joins & Subqueries",
        badge: "Advanced",
        completed: 0,
        lessonsCount: 4,
        desc: "INNER JOIN, LEFT JOIN, FULL OUTER JOIN, and Correlated Subqueries.",
        lessons: [
          { id: "sql_l3_1", title: "INNER & LEFT Joins", status: "locked", theory: "Join tables using primary and foreign key constraints.", snippet: "SELECT u.username, p.score FROM users u JOIN practice_submissions p ON u.user_id = p.user_id;", quiz: { q: "Which join returns all left rows even if no right match?", options: ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "CROSS JOIN"], correct: 1 } }
        ]
      },
      {
        id: "sql_l4",
        num: 4,
        title: "Level 4: Window Functions & Index Tuning",
        badge: "Master / DBA",
        completed: 0,
        lessonsCount: 3,
        desc: "ROW_NUMBER, DENSE_RANK, PARTITION BY, indexing strategies, and EXPLAIN query plans.",
        lessons: [
          { id: "sql_l4_1", title: "Window Functions", status: "locked", theory: "Calculate running metrics without collapsing rows.", snippet: "SELECT username, score, DENSE_RANK() OVER (ORDER BY score DESC) as rank FROM practice_submissions;", quiz: { q: "Which function calculates row rank without gaps in ties?", options: ["ROW_NUMBER", "RANK", "DENSE_RANK", "NTILE"], correct: 2 } }
        ]
      }
    ]
  },
  dsa: {
    name: "Algorithms & Data Structures",
    icon: "fa-solid fa-diagram-project",
    color: "#e84393",
    levels: [
      {
        id: "dsa_l1",
        num: 1,
        title: "Level 1: Big-O & Linear Structures",
        badge: "Core Foundations",
        completed: 30,
        lessonsCount: 4,
        desc: "Time and Space Complexity, Static & Dynamic Arrays, Strings, and Two Pointers.",
        lessons: [
          { id: "dsa_l1_1", title: "Time Complexity & Big-O", status: "completed", theory: "Analyze scaling characteristics: O(1), O(log n), O(n), O(n log n), O(n^2).", snippet: "def constant_time(arr):\n    return arr[0] if arr else None # O(1)", quiz: { q: "What is time complexity of accessing an array element by index?", options: ["O(1)", "O(n)", "O(log n)", "O(n^2)"], correct: 0 } }
        ]
      },
      {
        id: "dsa_l2",
        num: 2,
        title: "Level 2: Hash Tables, Stacks & Queues",
        badge: "Intermediate DSA",
        completed: 10,
        lessonsCount: 4,
        desc: "Hash collision resolution, Monotonic Stacks, and BFS Queues.",
        lessons: [
          { id: "dsa_l2_1", title: "Two Sum with Hash Table", status: "completed", theory: "Achieve optimal O(n) one-pass target complement lookup.", snippet: "seen = {}\n# complement = target - num", quiz: { q: "What data structure enables O(1) average lookup?", options: ["Array", "Linked List", "Hash Table", "Binary Tree"], correct: 2 } }
        ]
      },
      {
        id: "dsa_l3",
        num: 3,
        title: "Level 3: Trees, Graphs & Recursion",
        badge: "Advanced DSA",
        completed: 0,
        lessonsCount: 4,
        desc: "Binary Search Trees, Depth-First Search (DFS), Breadth-First Search (BFS), and Topological Sort.",
        lessons: [
          { id: "dsa_l3_1", title: "Binary Tree Traversals", status: "locked", theory: "Pre-order, In-order, and Post-order recursive traversal orders.", snippet: "def inorder(root):\n    if root:\n        inorder(root.left)\n        print(root.val)\n        inorder(root.right)", quiz: { q: "Which traversal of a BST produces sorted elements?", options: ["Pre-order", "In-order", "Post-order", "Level-order"], correct: 1 } }
        ]
      },
      {
        id: "dsa_l4",
        num: 4,
        title: "Level 4: Dynamic Programming & Graphs",
        badge: "Master / Hard",
        completed: 0,
        lessonsCount: 3,
        desc: "Memoization, Tabulation, Knapsack variations, Dijkstra's algorithm, and Bit Manipulation.",
        lessons: [
          { id: "dsa_l4_1", title: "1D Dynamic Programming", status: "locked", theory: "Break problems into overlapping optimal subproblems.", snippet: "memo = {}\ndef fib(n):\n    if n in memo: return memo[n]\n    if n <= 1: return n\n    memo[n] = fib(n-1) + fib(n-2)\n    return memo[n]", quiz: { q: "Top-down DP with caching is commonly called what?", options: ["Tabulation", "Memoization", "Greedy", "Divide and conquer"], correct: 1 } }
        ]
      }
    ]
  }
};

let activeCourseTrack = "python";
let activeLessonObj = null;

function selectCourseTrack(trackKey, btn) {
  activeCourseTrack = trackKey;
  document.querySelectorAll(".track-tab").forEach(t => t.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderCourseLevels(trackKey);
}

function renderCourseLevels(trackKey = activeCourseTrack) {
  const container = document.getElementById("course-levels-grid");
  const track = COURSE_TRACKS[trackKey] || COURSE_TRACKS.python;
  if (!container) return;

  container.innerHTML = "";
  track.levels.forEach(lvl => {
    const card = document.createElement("div");
    card.className = "course-level-card";

    let lessonsHtml = "";
    if (lvl.lessons && lvl.lessons.length > 0) {
      lessonsHtml = `
        <div class="level-lessons-list">
          ${lvl.lessons.map(ls => `
            <div class="level-lesson-row ${ls.status}" onclick="openCourseLesson('${ls.id}')">
              <div class="llr-left">
                <i class="fa-solid ${ls.status === 'completed' ? 'fa-circle-check text-green' : ls.status === 'in-progress' ? 'fa-circle-play text-accent' : 'fa-lock text-muted'}"></i>
                <span class="llr-title">${escapeHtml(ls.title)}</span>
              </div>
              <span class="llr-tag ${ls.status}">${ls.status.replace('-', ' ')}</span>
            </div>
          `).join("")}
        </div>
      `;
    }

    card.innerHTML = `
      <div class="clc-header">
        <div class="clc-kicker">LEVEL ${lvl.num} • ${lvl.badge}</div>
        <h3 class="clc-title">${escapeHtml(lvl.title)}</h3>
        <p class="clc-desc">${escapeHtml(lvl.desc)}</p>
      </div>

      <div class="clc-progress-box">
        <div class="clc-prog-label">
          <span>Level Mastery</span>
          <strong>${lvl.completed}%</strong>
        </div>
        <div class="progress-track" style="height: 6px;">
          <div class="progress-fill ${lvl.completed >= 60 ? 'fill-green' : 'fill-purple'}" style="width: ${lvl.completed}%;"></div>
        </div>
      </div>

      ${lessonsHtml}
    `;
    container.appendChild(card);
  });
}

function openCourseLesson(lessonId) {
  let foundLesson = null;
  let foundLevel = null;
  Object.keys(COURSE_TRACKS).forEach(tKey => {
    COURSE_TRACKS[tKey].levels.forEach(lvl => {
      if (lvl.lessons) {
        lvl.lessons.forEach(ls => {
          if (ls.id === lessonId) {
            foundLesson = ls;
            foundLevel = lvl;
          }
        });
      }
    });
  });

  if (!foundLesson) return;
  activeLessonObj = foundLesson;

  const modal = document.getElementById("course-lesson-modal");
  const levelTag = document.getElementById("lesson-modal-level-tag");
  const title = document.getElementById("lesson-modal-title");
  const subtitle = document.getElementById("lesson-modal-subtitle");
  const theory = document.getElementById("lesson-theory-content");
  const code = document.getElementById("lesson-code-content");
  const quizQ = document.getElementById("lesson-quiz-question");
  const quizOpts = document.getElementById("lesson-quiz-options");
  const quizRes = document.getElementById("lesson-quiz-result");
  const output = document.getElementById("lesson-sandbox-output");

  if (levelTag) levelTag.textContent = foundLevel.title.toUpperCase();
  if (title) title.textContent = foundLesson.title;
  if (subtitle) subtitle.textContent = `Interactive Lesson • ${foundLevel.badge}`;
  if (theory) theory.innerHTML = `<p>${escapeHtml(foundLesson.theory)}</p>`;
  if (code) {
    code.textContent = foundLesson.snippet;
    if (typeof Prism !== "undefined") Prism.highlightElement(code);
  }
  if (output) output.classList.add("hidden");

  if (quizQ && quizOpts && foundLesson.quiz) {
    quizQ.textContent = foundLesson.quiz.q;
    quizOpts.innerHTML = "";
    if (quizRes) quizRes.classList.add("hidden");

    foundLesson.quiz.options.forEach((opt, idx) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "lesson-quiz-opt-btn";
      btn.textContent = `${String.fromCharCode(65 + idx)}. ${opt}`;
      btn.onclick = () => checkQuizOption(idx, foundLesson.quiz.correct, btn);
      quizOpts.appendChild(btn);
    });
  }

  if (modal) modal.classList.remove("hidden");
  recordUserActivity("Accessed Course Lesson", `${foundLesson.title} in ${foundLevel.title}`, "course");
}

function closeLessonModal() {
  const modal = document.getElementById("course-lesson-modal");
  if (modal) modal.classList.add("hidden");
}

function runLessonSnippet() {
  if (!activeLessonObj) return;
  const output = document.getElementById("lesson-sandbox-output");
  if (!output) return;

  output.classList.remove("hidden");
  output.innerHTML = `<span style="color: var(--text-muted);"><i class="fa-solid fa-spinner fa-spin"></i> Running snippet...</span>`;

  setTimeout(() => {
    output.innerHTML = `
      <div style="color: var(--accent-green);"><i class="fa-solid fa-circle-check"></i> Process exited with code 0:</div>
      <div style="margin-top: 4px; color: #a29bfe;">> Output verified successfully!</div>
    `;
    playAudioTick();
  }, 400);
}

function checkQuizOption(selectedIdx, correctIdx, btn) {
  const options = document.querySelectorAll(".lesson-quiz-opt-btn");
  const result = document.getElementById("lesson-quiz-result");

  options.forEach((b, i) => {
    b.disabled = true;
    if (i === correctIdx) b.classList.add("correct");
  });

  if (selectedIdx === correctIdx) {
    btn.classList.add("correct");
    if (result) {
      result.className = "quiz-result success";
      result.innerHTML = `<i class="fa-solid fa-circle-check"></i> Correct! Excellent understanding!`;
      result.classList.remove("hidden");
    }
    playAudioTick();
  } else {
    btn.classList.add("wrong");
    if (result) {
      result.className = "quiz-result error";
      result.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Incorrect answer. Review the concept and try again!`;
      result.classList.remove("hidden");
    }
  }
}

function completeCurrentLesson() {
  if (!activeLessonObj) return;
  activeLessonObj.status = "completed";
  weeklyStats.lessonsDone += 1;
  saveWeeklyStats();
  showToast(`Congratulations! Completed lesson "${activeLessonObj.title}"! 🎉`, "success");
  recordUserActivity("Completed Course Lesson", `Marked ${activeLessonObj.title} as completed`, "course");
  closeLessonModal();
  renderCourseLevels();
  if (activeView === "user-dashboard") renderUserDashboard();
}

// ==========================================================================
// FULL ADMINISTRATOR CONTROL CENTER CONTROLLER
// ==========================================================================
let activeAdminSubTab = "users";

function renderAdminDashboard() {
  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  const studentsCount = users.filter(u => u.role !== "admin").length;
  const adminsCount = users.filter(u => u.role === "admin").length;
  const activeCount = users.filter(u => u.status === "online" || u.status === "active").length;

  const usersKpi = document.getElementById("admin-kpi-users");
  const usersSub = document.getElementById("admin-kpi-users-sub");
  const activeKpi = document.getElementById("admin-kpi-active");
  const queriesKpi = document.getElementById("admin-kpi-queries");

  if (usersKpi) usersKpi.textContent = users.length;
  if (usersSub) usersSub.innerHTML = `<i class="fa-solid fa-user-check"></i> ${studentsCount} Students • ${adminsCount} Admin`;
  if (activeKpi) activeKpi.textContent = activeCount;
  if (queriesKpi) queriesKpi.textContent = searchHistory.length;

  renderAdminUsersTable();
  renderAdminActivityLogs();
  renderAdminAnalytics();
  renderAdminTracks();
  renderAdminAnnouncements();
}

function switchAdminSubTab(tabName) {
  activeAdminSubTab = tabName;
  const tabs = ["users", "logs", "analytics", "courses", "announcements"];

  tabs.forEach(t => {
    const btn = document.getElementById(`btn-admin-tab-${t}`);
    const pane = document.getElementById(`admin-pane-${t}`);
    if (btn) {
      if (t === tabName) btn.classList.add("active");
      else btn.classList.remove("active");
    }
    if (pane) {
      if (t === tabName) pane.classList.remove("hidden");
      else pane.classList.add("hidden");
    }
  });

  if (tabName === "users") renderAdminUsersTable();
  else if (tabName === "logs") renderAdminActivityLogs();
  else if (tabName === "analytics") renderAdminAnalytics();
  else if (tabName === "courses") renderAdminTracks();
  else if (tabName === "announcements") renderAdminAnnouncements();
}

function renderAdminUsersTable() {
  const tbody = document.getElementById("admin-users-table-body");
  const countTag = document.getElementById("admin-table-count");
  if (!tbody) return;

  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  const searchInput = document.getElementById("admin-user-search-input");
  const roleSelect = document.getElementById("admin-role-filter");
  const statusSelect = document.getElementById("admin-status-filter");

  const searchKw = searchInput ? searchInput.value.toLowerCase().trim() : "";
  const roleFilter = roleSelect ? roleSelect.value : "all";
  const statusFilter = statusSelect ? statusSelect.value : "all";

  const filtered = users.filter(u => {
    const matchKw = !searchKw || 
      (u.name && u.name.toLowerCase().includes(searchKw)) || 
      (u.username && u.username.toLowerCase().includes(searchKw)) ||
      (u.currentCourse && u.currentCourse.toLowerCase().includes(searchKw));
    const matchRole = roleFilter === "all" || u.role === roleFilter;
    const matchStatus = statusFilter === "all" || (u.status || "online") === statusFilter;
    return matchKw && matchRole && matchStatus;
  });

  if (countTag) countTag.textContent = `${filtered.length} of ${users.length} Users`;

  tbody.innerHTML = "";
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 24px; color: var(--text-muted);">No users found matching your search.</td></tr>`;
    return;
  }

  filtered.forEach(u => {
    const tr = document.createElement("tr");
    const statusClass = u.status || "online";

    tr.innerHTML = `
      <td>
        <div class="admin-user-cell">
          <div class="admin-user-avatar" style="${u.role === 'admin' ? 'background: #f39c12;' : ''}">${u.avatarLetter || 'ST'}</div>
          <div>
            <div class="admin-user-name">${escapeHtml(u.name || u.username)}</div>
            <div class="admin-user-id">${escapeHtml(u.username)}</div>
          </div>
        </div>
      </td>
      <td><code>${escapeHtml(u.username)}</code></td>
      <td>
        <span class="role-pill-badge ${u.role === 'admin' ? 'admin-badge' : 'student-badge'}">
          <i class="fa-solid ${u.role === 'admin' ? 'fa-shield-halved' : 'fa-user-graduate'}"></i> ${u.role === 'admin' ? 'Admin' : 'Student'}
        </span>
      </td>
      <td>
        <div style="font-weight: 600;">${escapeHtml(u.currentCourse || 'Python Programming')}</div>
        <div style="font-size: 11px; color: var(--text-muted);">${escapeHtml(u.level || 'Level 1: Basics')}</div>
      </td>
      <td><strong>${u.problemsSolved || 0}</strong></td>
      <td>🔥 ${u.streak || 1}d</td>
      <td>
        <span class="status-pill ${statusClass}">
          <i class="fa-solid fa-circle" style="font-size: 7px;"></i> ${statusClass}
        </span>
      </td>
      <td>
        <div style="display: flex; gap: 6px;">
          <button type="button" class="btn-icon-xs text-accent" onclick="openEditUserModal('${escapeHtml(u.username)}')" title="Edit User">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <button type="button" class="btn-icon-xs text-orange" onclick="toggleUserRole('${escapeHtml(u.username)}')" title="Toggle Role (Student / Admin)">
            <i class="fa-solid fa-arrow-right-arrow-left"></i>
          </button>
          <button type="button" class="btn-icon-xs text-danger" onclick="deleteUserAccount('${escapeHtml(u.username)}')" title="Delete Account">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function filterAdminUserTable() {
  renderAdminUsersTable();
}

function renderAdminActivityLogs(typeFilter = "all") {
  const container = document.getElementById("admin-activity-stream-list");
  if (!container) return;

  let logs = [];
  try {
    logs = JSON.parse(localStorage.getItem("codementor_activity_logs") || "[]");
  } catch (_) {}

  const filtered = typeFilter === "all" ? logs : logs.filter(l => l.type === typeFilter);
  container.innerHTML = "";

  if (filtered.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--text-muted);">No activity logs found for category "${typeFilter}".</div>`;
    return;
  }

  filtered.forEach(log => {
    const item = document.createElement("div");
    item.className = `stream-item ${log.type || 'auth'}`;
    
    let icon = "fa-bell";
    if (log.type === "practice") icon = "fa-puzzle-piece";
    else if (log.type === "compiler") icon = "fa-terminal";
    else if (log.type === "course") icon = "fa-graduation-cap";
    else if (log.type === "auth") icon = "fa-key";

    item.innerHTML = `
      <div class="stream-icon"><i class="fa-solid ${icon}"></i></div>
      <div class="stream-content">
        <div><strong class="stream-user">${escapeHtml(log.username)}</strong> • <span class="stream-action">${escapeHtml(log.action)}</span></div>
        <div style="color: var(--text-muted); font-size: 12px;">${escapeHtml(log.detail || '')}</div>
        <div class="stream-time">${log.timestamp || 'Recent'}</div>
      </div>
    `;
    container.appendChild(item);
  });
}

function filterActivityLogType(type, btn) {
  document.querySelectorAll(".log-filter-pill").forEach(p => p.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderAdminActivityLogs(type);
}

function clearActivityLogs() {
  if (confirm("Are you sure you want to clear all real-time audit logs?")) {
    localStorage.setItem("codementor_activity_logs", JSON.stringify([]));
    renderAdminActivityLogs();
    showToast("Cleared real-time activity logs", "info");
  }
}

function renderAdminAnalytics() {
  const queriesBody = document.getElementById("admin-analytics-queries-body");
  if (!queriesBody) return;

  queriesBody.innerHTML = "";
  const recent = (searchHistory || []).slice(0, 8);

  if (recent.length === 0) {
    queriesBody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 20px; color: var(--text-muted);">No queries recorded yet.</td></tr>`;
    return;
  }

  recent.forEach(q => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${escapeHtml(q.query)}</strong></td>
      <td><span class="role-pill-badge student-badge">${escapeHtml(q.category || 'Concept')}</span></td>
      <td><code>${escapeHtml(q.language || 'Python')}</code></td>
      <td style="color: var(--text-muted);">${escapeHtml(q.formattedDate || 'Today')}</td>
    `;
    queriesBody.appendChild(tr);
  });
}

function renderAdminTracks() {
  const container = document.getElementById("admin-tracks-grid");
  if (!container) return;

  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  container.innerHTML = "";

  Object.keys(COURSE_TRACKS).forEach(tKey => {
    const track = COURSE_TRACKS[tKey];
    const enrolledCount = users.filter(u => u.currentCourse && u.currentCourse.toLowerCase().includes(tKey)).length || 1;

    const card = document.createElement("div");
    card.className = "admin-panel-card";
    card.innerHTML = `
      <div class="panel-header">
        <div style="display: flex; align-items: center; gap: 10px;">
          <i class="${track.icon}" style="font-size: 22px; color: ${track.color};"></i>
          <div>
            <h4 style="font-size: 15px; font-weight: 700;">${track.name}</h4>
            <span style="font-size: 12px; color: var(--text-muted);">${track.levels.length} Mastery Levels Active</span>
          </div>
        </div>
        <span class="badge-count">${enrolledCount} Learners</span>
      </div>

      <div style="margin-top: 14px; display: flex; flex-direction: column; gap: 8px;">
        ${track.levels.map(l => `
          <div style="display: flex; justify-content: space-between; font-size: 12px; padding: 6px 10px; background: var(--bg-elevated); border-radius: 6px;">
            <span>${l.title}</span>
            <strong style="color: var(--accent-green);">${l.completed}% Completion</strong>
          </div>
        `).join("")}
      </div>
    `;
    container.appendChild(card);
  });
}

function renderAdminAnnouncements() {
  const container = document.getElementById("admin-active-ann-list");
  if (!container) return;

  let annList = [];
  try {
    annList = JSON.parse(localStorage.getItem("codementor_announcements") || "[]");
  } catch (_) {}

  container.innerHTML = "";
  if (annList.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-muted);">No active announcements. Use the form on the left to broadcast one!</div>`;
    return;
  }

  annList.forEach(ann => {
    const item = document.createElement("div");
    item.className = `admin-ann-item ${ann.type || 'info'}`;
    item.innerHTML = `
      <div class="aai-content">
        <div class="aai-header">
          <strong>${escapeHtml(ann.title)}</strong>
          <span class="aai-time">${ann.timestamp || 'Just now'}</span>
        </div>
        <p class="aai-text">${escapeHtml(ann.content)}</p>
      </div>
      <button class="btn-icon-xs text-danger" onclick="deleteAnnouncement('${ann.id}')" title="Delete">
        <i class="fa-solid fa-trash-can"></i>
      </button>
    `;
    container.appendChild(item);
  });
}

function openAddUserModal() {
  const modal = document.getElementById("admin-add-user-modal");
  if (modal) modal.classList.remove("hidden");
}

function closeAddUserModal() {
  const modal = document.getElementById("admin-add-user-modal");
  if (modal) modal.classList.add("hidden");
}

function handleCreateUser(e) {
  e.preventDefault();
  const name = document.getElementById("new-user-fullname").value.trim();
  const username = document.getElementById("new-user-username").value.trim();
  const password = document.getElementById("new-user-password").value;
  const role = document.getElementById("new-user-role").value;
  const course = document.getElementById("new-user-course").value;

  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    showToast("A user with this username already exists!", "error");
    return;
  }

  const initials = name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2) || "US";
  const newUser = {
    username,
    password,
    name,
    role,
    plan: role === "admin" ? "👑 Administrator" : "student plan",
    avatarLetter: initials,
    currentCourse: course,
    level: "Level 1: Basics",
    problemsSolved: 0,
    streak: 1,
    status: "online"
  };

  users.push(newUser);
  localStorage.setItem("codementor_users", JSON.stringify(users));
  recordUserActivity("Admin Created User", `Created ${role} account: ${username}`, "auth");

  closeAddUserModal();
  renderAdminDashboard();
  showToast(`Created account for ${name} (${username})!`, "success");
}

function openEditUserModal(username) {
  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  const user = users.find(u => u.username === username);
  if (!user) return;

  const modal = document.getElementById("admin-edit-user-modal");
  document.getElementById("edit-user-original-username").value = user.username;
  document.getElementById("edit-user-fullname").value = user.name || user.username;
  document.getElementById("edit-user-role").value = user.role || "student";
  document.getElementById("edit-user-status").value = user.status || "online";
  document.getElementById("edit-user-course").value = user.currentCourse || "Python Programming Mastery";
  document.getElementById("edit-user-level").value = user.level || "Level 1: Basics";

  const sub = document.getElementById("edit-user-modal-sub");
  if (sub) sub.textContent = `Modifying account: ${user.username}`;

  if (modal) modal.classList.remove("hidden");
}

function closeEditUserModal() {
  const modal = document.getElementById("admin-edit-user-modal");
  if (modal) modal.classList.add("hidden");
}

function handleSaveEditUser(e) {
  e.preventDefault();
  const origUsername = document.getElementById("edit-user-original-username").value;
  const name = document.getElementById("edit-user-fullname").value.trim();
  const role = document.getElementById("edit-user-role").value;
  const status = document.getElementById("edit-user-status").value;
  const course = document.getElementById("edit-user-course").value;
  const level = document.getElementById("edit-user-level").value;

  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  const user = users.find(u => u.username === origUsername);
  if (!user) return;

  user.name = name;
  user.role = role;
  user.status = status;
  user.currentCourse = course;
  user.level = level;
  user.plan = role === "admin" ? "👑 Administrator" : "student plan";

  localStorage.setItem("codementor_users", JSON.stringify(users));
  recordUserActivity("Admin Updated User", `Edited profile of ${origUsername}`, "auth");

  closeEditUserModal();
  renderAdminDashboard();
  showToast(`Saved changes for ${origUsername}!`, "success");
}

function toggleUserRole(username) {
  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  const user = users.find(u => u.username === username);
  if (!user) return;

  const newRole = user.role === "admin" ? "student" : "admin";
  user.role = newRole;
  user.plan = newRole === "admin" ? "👑 Administrator" : "student plan";
  localStorage.setItem("codementor_users", JSON.stringify(users));

  recordUserActivity("Admin Changed User Role", `Changed ${username} role to ${newRole}`, "auth");
  renderAdminDashboard();
  showToast(`Updated role of ${username} to ${newRole}!`, "success");
}

function deleteUserAccount(username) {
  const curUser = typeof getCurrentUser === "function" ? getCurrentUser() : null;
  if (curUser && curUser.username.toLowerCase() === username.toLowerCase()) {
    showToast("Cannot delete the currently logged-in account!", "error");
    return;
  }

  if (confirm(`Are you sure you want to delete user account "${username}"?`)) {
    let users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
    users = users.filter(u => u.username !== username);
    localStorage.setItem("codementor_users", JSON.stringify(users));

    recordUserActivity("Admin Deleted User", `Removed account ${username}`, "auth");
    renderAdminDashboard();
    showToast(`Deleted account ${username}`, "info");
  }
}

function refreshAdminData() {
  renderAdminDashboard();
  showToast("Admin dashboard data refreshed in real-time!", "success");
}

function exportAdminUserReport() {
  const users = typeof getStoredUsers === "function" ? getStoredUsers() : DEFAULT_ACCOUNTS;
  let logs = [];
  try { logs = JSON.parse(localStorage.getItem("codementor_activity_logs") || "[]"); } catch (_) {}

  const report = {
    generatedAt: new Date().toISOString(),
    systemHealth: "99.98% OPTIMAL",
    totalUsers: users.length,
    usersRoster: users,
    activityAuditLogs: logs,
    searchHistoryCount: searchHistory.length,
    weeklyPerformance: weeklyStats
  };

  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(report, null, 2));
  const dlAnchor = document.createElement("a");
  dlAnchor.setAttribute("href", dataStr);
  dlAnchor.setAttribute("download", `codementor-admin-report-${Date.now()}.json`);
  document.body.appendChild(dlAnchor);
  dlAnchor.click();
  dlAnchor.remove();

  showToast("Exported Admin User & Activity Report (JSON)!", "success");
}

function openAnnouncementModal() {
  const modal = document.getElementById("admin-broadcast-modal");
  if (modal) modal.classList.remove("hidden");
}

function closeAnnouncementModal() {
  const modal = document.getElementById("admin-broadcast-modal");
  if (modal) modal.classList.add("hidden");
}

function handlePostAnnouncement(e) {
  e.preventDefault();
  const titleInput = document.getElementById("modal-ann-input-title") || document.getElementById("ann-input-title");
  const textInput = document.getElementById("modal-ann-input-text") || document.getElementById("ann-input-text");
  const typeSelect = document.getElementById("modal-ann-input-type") || document.getElementById("ann-input-type");

  const title = titleInput ? titleInput.value.trim() : "";
  const text = textInput ? textInput.value.trim() : "";
  const type = typeSelect ? typeSelect.value : "info";

  if (!title || !text) return;

  let annList = [];
  try {
    annList = JSON.parse(localStorage.getItem("codementor_announcements") || "[]");
  } catch (_) {}

  const newAnn = {
    id: "ann_" + Date.now(),
    title,
    content: text,
    type,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  annList.unshift(newAnn);
  localStorage.setItem("codementor_announcements", JSON.stringify(annList));

  recordUserActivity("Admin Broadcast Notice", `Published "${title}" to all students`, "auth");
  closeAnnouncementModal();
  renderAdminAnnouncements();
  showToast(`Published broadcast: "${title}" to student dashboards!`, "success");
}

function deleteAnnouncement(id) {
  let annList = [];
  try {
    annList = JSON.parse(localStorage.getItem("codementor_announcements") || "[]");
  } catch (_) {}

  annList = annList.filter(a => a.id !== id);
  localStorage.setItem("codementor_announcements", JSON.stringify(annList));
  renderAdminAnnouncements();
  showToast("Removed broadcast announcement", "info");
}

function toggleStudentSignupModal() {
  const modal = document.getElementById("student-signup-modal");
  if (modal) modal.classList.toggle("hidden");
}


