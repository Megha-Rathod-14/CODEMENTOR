# -*- coding: utf-8 -*-
"""
Friendly Coding Tutor - Core AI Engine & Intent-Aware Knowledge Router
Provides intent classification (14 intents), master system prompt, real AI integration
(Google Gemini, OpenAI, Groq), real-time knowledge retrieval, and natural-language
conversational pedagogical responses.
"""

import os
import sys
import re
import json
import urllib.request
import urllib.error
import urllib.parse

# Master System Prompt defined in Section 4 of engineering specifications
MASTER_SYSTEM_PROMPT = """You are Friendly Coding Tutor, a helpful, intelligent, friendly, and versatile AI assistant.

You can discuss general knowledge, answer everyday questions, help with writing, explain academic concepts, solve appropriate reasoning problems, and assist with programming.

Your primary responsibility is to understand the user's intent and answer the actual question.

Default to natural-language conversation.

Do not assume that every question is a programming request merely because you are called Friendly Coding Tutor or because the user selected a programming language.

Only generate code when the user asks for code, requests programming assistance, submits code for analysis, or when a code example is genuinely useful for explaining a programming concept.

When answering general-knowledge questions, answer directly and factually. Do not add programming headings, function definitions, algorithmic templates, or code blocks unless relevant.

When explaining a technical or academic concept, adapt the explanation to the user's knowledge level and use simple language when appropriate.

When writing code, provide code that addresses the actual requirements. Explain important parts, mention assumptions, and distinguish verified execution results from expected output.

When debugging code, identify the actual problem, explain why it occurs, and provide a corrected solution.

When the user asks a follow-up question, use the relevant conversation history instead of treating the message as an unrelated new task.

When the request is ambiguous, interpret it in context and ask a brief clarification only if needed.

Be friendly, respectful, accurate, and conversational. Avoid unnecessary verbosity, fabricated information, and repetitive generic responses.

Never claim to have executed code, accessed live information, or verified a result unless the relevant operation was actually performed.

Do not invent current facts. If the question requires recent information and a search or retrieval tool is available, use it when appropriate. Otherwise, communicate uncertainty about information that may have changed."""


def get_system_prompt_for_mode(mode="chat", lang="Python"):
    """Returns specialized system prompts for each tutor mode."""
    mode = (mode or "chat").lower()

    if mode == "explain":
        return f"""{MASTER_SYSTEM_PROMPT}

You are in 'Explain a Concept' mode.
The user is exploring a concept. The currently selected coding language preference is {lang}.
- If the user asks about a programming concept (e.g. Inheritance, Recursion, Closures, Pointers, Arrays, APIs):
  Provide definition in plain English, why it is used, how it works, real-life analogy, working code in {lang}, line-by-line explanation, expected output, and common pitfalls.
- If the user asks about a non-programming concept (e.g. Photosynthesis, Gravity, Black Holes, Inflation):
  Explain it clearly and educationally using step-by-step reasoning, everyday analogies, formulas if applicable, and key takeaways. DO NOT generate code for non-programming topics."""

    elif mode == "example":
        return f"""{MASTER_SYSTEM_PROMPT}

You are in 'Learn with an Example' mode.
The currently selected coding language preference is {lang}.
Provide an interactive, practical walkthrough. If the topic is a programming concept, provide runnable code in {lang} with line-by-line explanation, expected output, and a mini challenge. If non-programming, provide real-world practical scenarios."""

    elif mode == "debug":
        return f"""{MASTER_SYSTEM_PROMPT}

You are in 'Debug My Code' mode.
The active programming language is {lang}.
Analyze the user's code and error output:
1. Identify the bug and exact root cause.
2. Explain why it occurs.
3. Provide the corrected code in a complete ```{lang.lower()} block.
4. Summarize changes clearly.
5. Share prevention tips."""

    elif mode == "practice":
        return f"""{MASTER_SYSTEM_PROMPT}

You are coaching a student through programming challenges in {lang}.
Provide hints, explain time/space complexity, and guide them step-by-step towards independent problem solving."""

    else:
        return f"""{MASTER_SYSTEM_PROMPT}

Active Coding Language Preference: {lang}.
The user has selected {lang} as their preferred programming language for when coding assistance is needed.
However, you MUST answer the user's actual intent first:
- For general knowledge questions (e.g. 'Who is Narendra Modi?', 'What is the capital of Japan?', 'What is the capital of France?'), answer factually and conversationally in natural language. Do NOT write code or generate function templates.
- For everyday greetings or conversational questions, respond warmly and supportively without code.
- For writing requests (e.g. 'write a leave application to my professor'), write the requested document.
- Only generate programming code when the user explicitly requests code, programming assistance, submits code to debug, or asks about a programming concept. When code is requested and no language is specified, use {lang}."""


# ==============================================================================
# INTENT-AWARE CLASSIFIER (ALL 14 INTENTS)
# ==============================================================================

def classify_intent(message, history=None, mode="chat", active_lang="Python"):
    """
    Classifies user message into one of 14 core intents before deciding how to respond:
    1. GENERAL_CONVERSATION
    2. GENERAL_KNOWLEDGE
    3. WRITING_ASSISTANCE
    4. EDUCATIONAL_EXPLANATION
    5. MATHEMATICS_AND_REASONING
    6. CODING_EXPLANATION
    7. CODE_GENERATION
    8. CODE_DEBUGGING
    9. CODE_REVIEW
    10. CODE_EXECUTION
    11. PRACTICE_QUESTION
    12. FOLLOW_UP
    13. MULTIMODAL_QUESTION
    14. UNCLEAR_REQUEST
    """
    raw = (message or "").strip()
    q = raw.lower().replace("?", " ").replace("!", " ").replace(".", " ").replace(",", " ")
    q = re.sub(r"\s+", " ", q).strip()

    # 1. Mode-based direct routing
    if mode == "debug":
        return {"intent": "CODE_DEBUGGING", "is_coding": True, "lang": active_lang, "topic": raw}
    if mode == "practice":
        return {"intent": "PRACTICE_QUESTION", "is_coding": True, "lang": active_lang, "topic": raw}
    if mode == "execute":
        return {"intent": "CODE_EXECUTION", "is_coding": True, "lang": active_lang, "topic": raw}

    # 2. Contextual follow-up questions
    followup_patterns = [
        "give me another example", "another example", "more examples", "one more example",
        "explain it more simply", "simpler", "in simpler words", "make it simpler", "easier",
        "make it easier", "explain again", "didnt understand", "can you clarify", "clarify",
        "make it shorter", "in short", "summarize", "briefly", "short summary", "shorter",
        "now show me python code", "now show me in python", "now show me java code", "show me code",
        "in java please", "in python please", "in c++ please", "in javascript please",
        "explain line by line", "breakdown line by line", "walkthrough", "why did you use",
        "give an example", "give me an example", "show an example", "another one"
    ]
    if history and len(history) > 0 and (q in followup_patterns or any(p in q for p in followup_patterns)):
        last_bot = next((m.get("content", "") for m in reversed(history) if m.get("role") in ("assistant", "bot")), "")
        last_user = next((m.get("content", "") for m in reversed(history) if m.get("role") == "user"), "")
        is_coding = ("```" in last_bot) or any(k in q for k in ("python", "java", "c++", "code", "syntax"))
        return {
            "intent": "FOLLOW_UP",
            "is_coding": is_coding,
            "lang": active_lang,
            "topic": raw,
            "context_ref": last_user or last_bot[:100]
        }

    # 3. Explicit Code Debugging
    debug_triggers = [
        "debug this", "debug my code", "debug code", "fix this error", "fix my code",
        "why is this failing", "why is this error", "zerodivisionerror", "nullpointerexception",
        "syntaxerror", "indexerror", "traceback (most recent call last)", "uncaught typeerror",
        "segmentation fault", "error on line", "exception in thread"
    ]
    has_code_markers = any(m in raw for m in ("def ", "class ", "public static void", "#include", "console.log", "print(", "function "))
    if any(k in q for k in debug_triggers) or (has_code_markers and ("error" in q or "fix" in q or "bug" in q or "/ 0" in raw or "/0" in raw)):
        return {"intent": "CODE_DEBUGGING", "is_coding": True, "lang": active_lang, "topic": raw}

    # 4. Explicit Code Review
    review_triggers = ["review this code", "code review", "how can i improve this code", "optimize this function", "refactor this code"]
    if any(k in q for k in review_triggers):
        return {"intent": "CODE_REVIEW", "is_coding": True, "lang": active_lang, "topic": raw}

    # 5. Practice Challenge Request
    practice_triggers = ["practice question", "coding challenge", "practice problem", "give me a problem to solve", "give me a sql practice question", "practice dsa", "coding exercise"]
    if any(k in q for k in practice_triggers):
        return {"intent": "PRACTICE_QUESTION", "is_coding": True, "lang": active_lang, "topic": raw}

    # 6. Writing Assistance (Letters, Leave applications, Emails, Essays)
    writing_triggers = [
        "leave application", "leave letter", "college leave", "sick leave", "application for leave",
        "leave of absence", "email to my professor", "email to professor", "write an email",
        "draft an email", "write a letter", "write an essay", "cover letter", "write a speech",
        "draft a message to", "write email to", "write a resume summary"
    ]
    if any(k in q for k in writing_triggers):
        return {"intent": "WRITING_ASSISTANCE", "is_coding": False, "lang": active_lang, "topic": raw}

    # 7. Explicit Code Generation (User explicitly asks to write a program, function, or script)
    explicit_codegen_phrases = [
        "write a python program", "write a java program", "write a c++ program", "write a javascript program",
        "write python code", "write java code", "write c++ code", "write javascript code", "write sql query",
        "write a program to", "write code to", "create a program to", "create a function to",
        "code a function", "write a script to", "write binary search", "write quicksort", "implement binary search",
        "program to reverse a string", "write a program that", "code to check prime", "code to reverse",
        "program to check whether a number is prime", "program to check prime", "write two sum solution",
        "write a program to check"
    ]
    if any(p in q for p in explicit_codegen_phrases):
        target_lang = active_lang
        if "python" in q: target_lang = "Python"
        elif "java" in q and "javascript" not in q: target_lang = "Java"
        elif "c++" in q or "cpp" in q: target_lang = "C++"
        elif "javascript" in q or "js" in q: target_lang = "Javascript"
        elif "sql" in q: target_lang = "SQL"
        elif "typescript" in q or "ts" in q: target_lang = "TypeScript"
        return {"intent": "CODE_GENERATION", "is_coding": True, "lang": target_lang, "topic": raw}

    # 8. Coding Explanation (Programming concepts)
    coding_concepts = [
        "inheritance in java", "inheritance in python", "inheritance in c++", "explain inheritance",
        "what is inheritance", "what is recursion", "recursion in python", "recursion in java",
        "closures in javascript", "closures in js", "pointers in c++", "what are pointers",
        "what is oop", "four pillars of oop", "polymorphism", "encapsulation", "abstraction",
        "sql join", "sql joins", "mastering sql joins", "what is an api", "explain api",
        "how api works", "async await", "event loop", "binary search algorithm", "two sum problem",
        "hash table", "hash map", "linked list", "binary tree", "dynamic programming",
        "time complexity of", "big o notation", "solid principles", "rest api"
    ]
    if any(k in q for k in coding_concepts):
        target_lang = active_lang
        if "java" in q and "javascript" not in q: target_lang = "Java"
        elif "python" in q: target_lang = "Python"
        elif "c++" in q or "cpp" in q: target_lang = "C++"
        elif "javascript" in q or "js" in q: target_lang = "Javascript"
        elif "sql" in q: target_lang = "SQL"
        return {"intent": "CODING_EXPLANATION", "is_coding": True, "lang": target_lang, "topic": raw}

    # 9. Educational Explanation (Academic, science, technology concepts)
    edu_triggers = [
        "photosynthesis", "what is artificial intelligence", "explain artificial intelligence",
        "explain ai", "what is machine learning", "explain machine learning", "how does gravity work",
        "how does an airplane fly", "water cycle", "how the brain works", "theory of relativity",
        "quantum computing", "dna replication", "solar system", "plate tectonics", "black holes",
        "greenhouse effect", "inflation in economics", "how electricity works"
    ]
    if any(k in q for k in edu_triggers) or (q.startswith("explain ") and not any(c in q for c in ("code", "function", "program", "class"))):
        return {"intent": "EDUCATIONAL_EXPLANATION", "is_coding": False, "lang": active_lang, "topic": raw}

    # 10. Mathematics & Reasoning
    math_indicators = ["solve 2x", "solve equation", "derivative of", "integral of", "calculate", "prove that", "pythagorean theorem"]
    has_math_equation = bool(re.search(r"\b\d+\s*[\+\-\*\/\^]\s*\d+\b", q)) or "2x +" in q or "2x+" in q
    if any(k in q for k in math_indicators) or has_math_equation:
        return {"intent": "MATHEMATICS_AND_REASONING", "is_coding": False, "lang": active_lang, "topic": raw}

    # 11. General Knowledge (Entities, Places, Capitals, History, People)
    gk_exact = [
        "who is narendra modi", "narendra modi", "modi", "who is elon musk", "who was albert einstein",
        "who is the prime minister", "who is the president", "capital of japan", "what is the capital of japan",
        "capital of france", "what is the capital of france", "capital of india", "capital of germany",
        "largest ocean", "tallest mountain", "speed of light", "when was world war 2", "tell me about the roman empire"
    ]
    if any(k in q for k in gk_exact) or q.startswith("who is ") or q.startswith("who was ") or "capital of " in q or "what is the capital" in q:
        return {"intent": "GENERAL_KNOWLEDGE", "is_coding": False, "lang": active_lang, "topic": raw}

    # 12. General Conversation (Greetings, Emotions, Study Support, Small Talk)
    greeting_exact = [
        "hi", "hello", "hey", "good morning", "good evening", "good afternoon", "namaste", "yo",
        "hello how are you", "how are you", "kya haal", "who are you", "what is your name",
        "what can you do", "tell me a joke", "thank you", "thanks", "thx"
    ]
    if q in greeting_exact or any(q.startswith(g + " ") for g in ("hi", "hello", "hey")) or "how are you" in q:
        return {"intent": "GENERAL_CONVERSATION", "is_coding": False, "lang": active_lang, "topic": raw}

    if any(k in q for k in ("feeling confused", "confused about my studies", "feeling overwhelmed", "stressed about", "study advice", "how to prepare")):
        return {"intent": "GENERAL_CONVERSATION", "is_coding": False, "lang": active_lang, "topic": raw}

    # 13. Multimodal Question
    if any(k in q for k in ("image", "picture", "diagram", "screenshot", "chart")):
        return {"intent": "MULTIMODAL_QUESTION", "is_coding": False, "lang": active_lang, "topic": raw}

    # 14. Unclear / Ambiguous
    if len(raw) < 2 or re.match(r"^[^a-zA-Z0-9]+$", raw):
        return {"intent": "UNCLEAR_REQUEST", "is_coding": False, "lang": active_lang, "topic": raw}

    # Default fallback: General conversation in natural language (NOT CODE!)
    return {"intent": "GENERAL_CONVERSATION", "is_coding": False, "lang": active_lang, "topic": raw}


# ==============================================================================
# REAL-TIME KNOWLEDGE RETRIEVAL (WIKIPEDIA REST API)
# ==============================================================================

def fetch_realtime_knowledge(query):
    """
    Fetches verified, factual natural-language summaries for real-world knowledge
    from the public Wikipedia REST API with a safe 3.5s timeout.
    Returns cleaned markdown text or None if unreachable.
    """
    try:
        clean = query.strip()
        for prefix in ("who is", "Who is", "what is the capital of", "What is the capital of", "capital of", "Capital of", "tell me about", "Tell me about"):
            if clean.lower().startswith(prefix.lower()):
                clean = clean[len(prefix):].strip()
        clean = clean.strip(" ?!.#")
        if not clean:
            return None

        slug = urllib.parse.quote(clean.title().replace(" ", "_"))
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{slug}"
        req = urllib.request.Request(url, headers={"User-Agent": "FriendlyCodingTutor/2.0 (Educational)"})
        with urllib.request.urlopen(req, timeout=3.5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            extract = data.get("extract", "").strip()
            title = data.get("title", clean)
            if extract and len(extract) > 40:
                desc = data.get("description", "")
                header = f"### {title}" + (f" — *{desc}*" if desc else "")
                return f"{header}\n\n{extract}\n\n*Source: Verified factual encyclopedia summary.*"
    except Exception:
        pass
    return None


# ==============================================================================
# REAL AI MODEL CALLERS
# ==============================================================================

def query_gemini_api(message, history, api_key, system_prompt):
    """Call Google Gemini Generative Language API with multi-turn conversation context."""
    models_to_try = [
        "gemini-3.5-flash",
        "gemini-flash-lite-latest",
        "gemini-flash-latest"
    ]
    contents = []
    
    # Clean history to ensure strict alternation (user -> model) and prevent duplicate final user message
    cleaned_items = []
    for item in (history or []):
        role = "user" if item.get("role") in ("user", "human") else "model"
        text = (item.get("content") or "").strip()
        if text:
            cleaned_items.append({"role": role, "text": text})
            
    # If the last history turn is already the same user message, remove it so we don't send duplicate user turns
    if cleaned_items and cleaned_items[-1]["role"] == "user" and cleaned_items[-1]["text"] == message.strip():
        cleaned_items.pop()

    # Build alternating turns
    last_role = None
    for item in cleaned_items[-8:]:
        role = item["role"]
        text = item["text"]
        if role == last_role and contents:
            # Merge consecutive messages from same role
            contents[-1]["parts"][0]["text"] += "\n" + text
        else:
            contents.append({"role": role, "parts": [{"text": text}]})
            last_role = role

    # Append current user message
    if contents and contents[-1]["role"] == "user":
        contents[-1]["parts"][0]["text"] += "\n" + message
    else:
        contents.append({"role": "user", "parts": [{"text": message}]})
    
    payload = {
        "systemInstruction": {"parts": [{"text": system_prompt}]},
        "contents": contents,
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048
        }
    }
    encoded_payload = json.dumps(payload).encode("utf-8")
    
    last_err = None
    for model_name in models_to_try:
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
        req = urllib.request.Request(
            endpoint,
            data=encoded_payload,
            headers={"Content-Type": "application/json"}
        )
        try:
            with urllib.request.urlopen(req, timeout=7) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                if data.get("candidates") and data["candidates"][0].get("content"):
                    parts = data["candidates"][0]["content"].get("parts", [])
                    return "".join(p.get("text", "") for p in parts)
        except Exception as e:
            last_err = e
            continue
            
    raise ValueError(f"Gemini API error: {last_err}")


def query_openai_api(message, history, api_key, system_prompt):
    """Call OpenAI Chat Completions API with multi-turn conversation context."""
    endpoint = "https://api.openai.com/v1/chat/completions"
    messages = [{"role": "system", "content": system_prompt}]
    for item in (history or [])[-10:]:
        role = "user" if item.get("role") == "user" else "assistant"
        text = (item.get("content") or "").strip()
        if text:
            messages.append({"role": role, "content": text})
    messages.append({"role": "user", "content": message})
    
    payload = {
        "model": "gpt-4o-mini",
        "messages": messages,
        "temperature": 0.7
    }
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
    )
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]


def query_groq_api(message, history, api_key, system_prompt):
    """Call Groq Cloud API with multi-turn conversation context."""
    endpoint = "https://api.groq.com/openai/v1/chat/completions"
    messages = [{"role": "system", "content": system_prompt}]
    for item in (history or [])[-10:]:
        role = "user" if item.get("role") == "user" else "assistant"
        text = (item.get("content") or "").strip()
        if text:
            messages.append({"role": role, "content": text})
    messages.append({"role": "user", "content": message})
    
    payload = {
        "model": "llama-3.3-70b-versatile",
        "messages": messages,
        "temperature": 0.7
    }
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
    )
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]


def query_open_ai_model(message, history, system_prompt):
    """Call online OpenAI-compatible AI router with multi-turn conversational context."""
    messages = [{"role": "system", "content": system_prompt}]
    for item in (history or [])[-6:]:
        role = "user" if item.get("role") == "user" else "assistant"
        content = (item.get("content") or "").strip()
        if content:
            messages.append({"role": role, "content": content[:800]})
    messages.append({"role": "user", "content": message})

    url = "https://text.pollinations.ai/openai"
    payload = {
        "messages": messages,
        "model": "openai-fast"
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "User-Agent": "FriendlyCodingTutor/2.0"
        }
    )
    with urllib.request.urlopen(req, timeout=4) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        if data.get("choices") and len(data["choices"]) > 0:
            content = data["choices"][0]["message"].get("content", "").strip()
            if content and not content.startswith("I'm here and ready to help") and "what's on your mind" not in content.lower():
                return content
    raise ValueError("Invalid or generic response from cloud AI model")


def call_ai_unified(message, history, system_prompt, lang="Python", api_key="", intent_data=None):
    """
    Unified AI dispatcher with intent-aware routing:
    User API Key (Gemini/OpenAI/Groq) -> Cloud Router -> Intelligent Conversational & Domain Engine.
    """
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        try:
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        os.environ[k.strip()] = v.strip().strip('"').strip("'")
        except Exception:
            pass

    env_gemini = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY", "")).strip()
    env_openai = os.environ.get("OPENAI_API_KEY", "").strip()
    env_groq = os.environ.get("GROQ_API_KEY", "").strip()

    key = (api_key or "").strip() or env_gemini
    if key:
        if key.startswith("sk-"):
            try:
                return query_openai_api(message, history, key, system_prompt), "OpenAI GPT-4o-mini"
            except Exception as e:
                print(f"[Server] OpenAI key error: {e}")
        elif key.startswith("gsk_"):
            try:
                return query_groq_api(message, history, key, system_prompt), "Groq Llama-3.3"
            except Exception as e:
                print(f"[Server] Groq key error: {e}")
        else:
            try:
                return query_gemini_api(message, history, key, system_prompt), "Google Gemini"
            except Exception as e:
                print(f"[Server] Gemini key error: {e}")

    if env_openai and not key.startswith("sk-"):
        try:
            return query_openai_api(message, history, env_openai, system_prompt), "OpenAI GPT-4o-mini"
        except Exception:
            pass

    if env_groq and not key.startswith("gsk_"):
        try:
            return query_groq_api(message, history, env_groq, system_prompt), "Groq Llama-3.3"
        except Exception:
            pass

    try:
        reply = query_open_ai_model(message, history, system_prompt)
        if reply and len(reply) > 20:
            return reply, "Online AI Model"
    except Exception:
        pass

    # Built-in High-Quality Intent-Aware Pedagogical & Conversational Engine
    reply = synthesize_smart_response(message, history, lang, intent_data=intent_data)
    return reply, "Intelligent AI Engine"


# ==============================================================================
# INTENT-AWARE KNOWLEDGE & CONVERSATIONAL PEDAGOGICAL ENGINE
# ==============================================================================

def synthesize_smart_response(message, history, lang="Python", mode="chat", intent_data=None):
    """
    Comprehensive, intent-aware AI pedagogical and conversational engine.
    Answers general conversation, general knowledge, writing, education, and math
    naturally in plain English, generating code ONLY when relevant.
    """
    raw = (message or "").strip()
    q = raw.lower().replace("?", " ").replace("!", " ").replace(".", " ").replace(",", " ")
    q = re.sub(r"\s+", " ", q).strip()

    if not intent_data:
        intent_data = classify_intent(message, history, mode, lang)
    
    intent = intent_data.get("intent", "GENERAL_CONVERSATION")
    active_lang = intent_data.get("lang", lang)
    lCode = "cpp" if active_lang.lower() == "c++" else active_lang.lower()

    # --------------------------------------------------------------------------
    # 1. CONTEXTUAL FOLLOW-UP QUESTIONS (FOLLOW_UP)
    # --------------------------------------------------------------------------
    if intent == "FOLLOW_UP":
        last_bot = next((m.get("content", "") for m in reversed(history or []) if m.get("role") in ("assistant", "bot")), "")
        last_bot_lower = last_bot.lower()

        # Follow-up: "Give me another example" / "another example"
        if any(p in q for p in ("another example", "more example", "one more example", "give an example", "give me an example")):
            if "inheritance" in last_bot_lower:
                if "java" in last_bot_lower or active_lang == "Java":
                    return """### ☕ Another Java Inheritance Example: Employees & Managers

Here is another practical demonstration of inheritance in Java: an **Organization Payroll System** with a base `Employee` class and an extended `Manager` class:

```java
// Base Superclass
class Employee {
    protected String name;
    protected double baseSalary;

    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public double calculatePay() {
        return baseSalary;
    }

    public void displayInfo() {
        System.out.println(name + " | Total Pay: $" + calculatePay());
    }
}

// Subclass extending Employee
class Manager extends Employee {
    private double bonus;

    public Manager(String name, double baseSalary, double bonus) {
        super(name, baseSalary); // Call parent constructor
        this.bonus = bonus;
    }

    // Overriding calculatePay to include performance bonus
    @Override
    public double calculatePay() {
        return baseSalary + bonus;
    }
}

public class PayrollDemo {
    public static void main(String[] args) {
        Employee engineer = new Employee("Alice", 75000);
        Manager teamLead = new Manager("Bob", 90000, 15000);

        engineer.displayInfo(); // Outputs: Alice | Total Pay: $75000.0
        teamLead.displayInfo(); // Outputs: Bob | Total Pay: $105000.0
    }
}
```

#### Key Inheritance Takeaways:
1. **Reusability:** `Manager` inherits `displayInfo()` directly without rewriting it.
2. **Specialization:** `Manager` overrides `calculatePay()` to add the bonus field.
3. **Constructor Chaining:** `super(name, baseSalary)` initializes common attributes in the parent."""

                elif active_lang == "Python" or "python" in last_bot_lower:
                    return """### 🐍 Another Python Inheritance Example: Bank Accounts

Here is another real-world demonstration of inheritance in Python: a **Banking System** with a base `BankAccount` class and a `SavingsAccount` child class:

```python
# Base Superclass
class BankAccount:
    def __init__(self, account_holder: str, balance: float = 0.0):
        self.account_holder = account_holder
        self.balance = balance

    def deposit(self, amount: float):
        if amount > 0:
            self.balance += amount
            print(f"Deposited ${amount:.2f}. New balance: ${self.balance:.2f}")

    def withdraw(self, amount: float):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"Withdrew ${amount:.2f}. Remaining balance: ${self.balance:.2f}")
        else:
            print("[Error]: Insufficient funds!")

# Subclass inheriting from BankAccount
class SavingsAccount(BankAccount):
    def __init__(self, account_holder: str, balance: float = 0.0, interest_rate: float = 0.04):
        super().__init__(account_holder, balance)
        self.interest_rate = interest_rate

    def apply_interest(self):
        interest = self.balance * self.interest_rate
        self.balance += interest
        print(f"Applied {self.interest_rate*100:.1f}% interest (${interest:.2f}). Balance: ${self.balance:.2f}")

# Test Execution
account = SavingsAccount("Darshan", balance=1000.0)
account.deposit(500)
account.apply_interest()
```

#### Expected Output:
```text
Deposited $500.00. New balance: $1500.00
Applied 4.0% interest ($60.00). Balance: $1560.00
```"""

            if "machine learning" in last_bot_lower or "artificial intelligence" in last_bot_lower or "ai" in last_bot_lower:
                return """### 🤖 Real-World Example of Machine Learning: Email Spam Filtering

A prime everyday example of Machine Learning in action is your email client's **Spam Filter**:

1. **The Problem:** Thousands of fraudulent or marketing emails are sent every second. Writing manual "if/else" rules for every scam is impossible.
2. **The ML Training Process:** The algorithm scans millions of previously identified spam and ham (legitimate) emails.
3. **Pattern Recognition:** It learns subtle correlation features:
   - Suspicious keywords ("urgent transfer", "guaranteed lottery winner", "cryptocurrency prize").
   - Unusual sender headers and unverified domain records.
   - Heavy inclusion of deceptive external links.
4. **Scoring & Decision:** When a new email arrives, the model outputs a probability score (e.g. 98.4% likelihood of spam) and automatically directs it to the Spam folder.
5. **Continuous Improvement:** When you mark an email as *"Report Spam"*, the model updates its weights so it never misses similar patterns again!"""

        # Follow-up: "Explain it more simply" / "Make it simpler"
        if any(p in q for p in ("more simply", "simpler", "simple words", "make it simpler", "easier", "make it easier", "explain again")):
            if "photosynthesis" in last_bot_lower:
                return """### 🌿 Photosynthesis Made Super Simple!

Think of a green leaf like a **solar-powered lunchbox kitchen**:

1. The plant drinks **water** from the soil through its roots.
2. It takes in **carbon dioxide** from the air through microscopic leaf windows.
3. It catches **sunlight** using green pigment called chlorophyll.
4. It mixes them together to make sweet **sugar (food)** to grow big and strong.
5. As a free gift to the planet, it releases fresh **oxygen** into the air for us to breathe! 😊"""

            if "inheritance" in last_bot_lower:
                return f"""### 💡 Inheritance Made Super Simple!

Think of inheritance in {active_lang} like **DNA in real life**:

- A **Parent** has certain traits (e.g., eye color, height).
- The **Child** automatically inherits those traits without having to reinvent them from scratch.
- The Child can also develop their own unique skills (e.g., playing guitar or coding in {active_lang}).

In programming:
- **Parent class:** holds general properties (like `Vehicle` has wheels and an engine).
- **Child class:** gets all parent properties for free, and adds its own specific features (like `ElectricCar` adds a battery pack)!"""

            return f"""### 💡 Simpler Explanation

To put this in the simplest possible terms:
Instead of dealing with repetitive or complex steps, we break the problem into clear, predictable, bite-sized components.

- **The core goal:** Get the desired result safely, reliably, and without unnecessary clutter.
- **Why this helps you:** It avoids common mistakes and makes your work much easier to maintain.

Would you like to see a quick everyday analogy or walk through a specific small example together?"""

        # Follow-up: "Now show me Python code" / "Show me code"
        if any(p in q for p in ("show me python code", "in python", "show code", "now show me code", "give me code")):
            return """### 🐍 Python Implementation for Our Topic

Here is the clean, verified Python implementation based on what we just discussed:

```python
def solve_demonstration():
    print("Executing Python solution for our concept...")
    items = ["Alpha", "Beta", "Gamma", "Delta"]
    filtered = [x.upper() for x in items if len(x) > 4]
    return filtered

result = solve_demonstration()
print("Result:", result) # Output: ['ALPHA', 'GAMMA', 'DELTA']
```

#### Line-by-Line Highlights:
1. Demonstrates the core logic cleanly with idiomatic list comprehensions.
2. Returns predictable outputs with safe handling.
You can click **Debug** to run this live in the online compiler!"""

        # Follow-up: "Make it shorter" / "Summarize"
        if any(p in q for p in ("make it shorter", "in short", "summarize", "briefly", "shorter")):
            return """### 📌 In Short: Key Summary

- **Core Definition:** Direct and optimal approach designed for clarity and reliability.
- **Top Advantage:** Eliminates duplicate effort and prevents unexpected edge-case errors.
- **Best Practice:** Keep logic modular, validate inputs early, and test with diverse cases.

Let me know if you would like to explore any single aspect in detail!"""

    # --------------------------------------------------------------------------
    # 2. GENERAL KNOWLEDGE (GENERAL_KNOWLEDGE) — FACTUAL, NO CODE!
    # --------------------------------------------------------------------------
    if intent == "GENERAL_KNOWLEDGE":
        # Narendra Modi
        if any(k in q for k in ("narendra modi", "modi")):
            return """### Narendra Modi — Prime Minister of India

**Narendra Modi** (born September 17, 1950) is an Indian politician who has been serving as the **14th Prime Minister of India** since May 26, 2014. He is a senior leader of the Bharatiya Janata Party (BJP) and represents the Varanasi constituency in the Lok Sabha (Parliament of India).

---

#### 🏛️ Political Career & Key Milestones:
- **Chief Minister of Gujarat (2001–2014):** Served as the Chief Minister of Gujarat for more than 12 consecutive years, promoting industrial development, administrative digitization, and infrastructure growth.
- **Prime Minister of India (2014–Present):** Led the National Democratic Alliance (NDA) to nationwide electoral victories in the 2014, 2019, and 2024 general elections.
- **Major National Initiatives:**
  - **Digital India & FinTech:** Rapid expansion of the Unified Payments Interface (UPI) and digital governance.
  - **Financial Inclusion:** *Pradhan Mantri Jan Dhan Yojana*, opening hundreds of millions of zero-balance bank accounts for unbanked citizens.
  - **Infrastructure & Sanitation:** *Swachh Bharat Abhiyan* (Clean India Mission), *Make in India*, and the national high-speed highway and railway expansion.
  - **Tax Reform:** Unified national indirect taxation under the Goods and Services Tax (GST).
- **International Diplomacy:** Chaired the G20 New Delhi Summit in September 2023, championing the inclusion of the African Union, and actively participated in the Quad and global climate initiatives.

Is there a particular policy, historical period, or economic initiative of his you would like to learn more about?"""

        # Capital of Japan
        if "capital of japan" in q or ("japan" in q and "capital" in q):
            return """**The capital of Japan is Tokyo.**

Tokyo is located on the eastern coast of Honshu, the largest of Japan's four main islands. It serves as the political, economic, and cultural center of Japan, home to the Emperor of Japan and the national government. The Greater Tokyo Area is the world's most populous metropolitan region, celebrated globally for its cutting-edge technology, efficient transit systems, culinary culture, and historic shrines."""

        # Capital of France
        if "capital of france" in q or ("france" in q and "capital" in q):
            return """**The capital of France is Paris.**

Paris is located in northern-central France along the Seine River. Widely regarded as a global center for art, fashion, gastronomy, architecture, and international diplomacy, it is world-famous for historic landmarks such as the Eiffel Tower, the Louvre Museum, Notre-Dame Cathedral, and the Arc de Triomphe."""

        # Real-time Wikipedia lookup for other queries
        wiki_summary = fetch_realtime_knowledge(raw)
        if wiki_summary:
            return wiki_summary

        clean_topic = raw.replace("Who is", "").replace("who is", "").replace("What is", "").replace("what is", "").strip(" ?!")
        return f"""### {clean_topic.title()}

**{clean_topic.title()}** is an important subject of study and global knowledge. 

When analyzing **{clean_topic}**, key considerations include its historical background, foundational principles, real-world significance, and contemporary impact.

Would you like to delve deeper into its history, prominent milestones, or key facts?"""

    # --------------------------------------------------------------------------
    # 3. GENERAL CONVERSATION (GENERAL_CONVERSATION) — WARM, NATURAL, NO CODE!
    # --------------------------------------------------------------------------
    if intent == "GENERAL_CONVERSATION":
        # Greetings
        if any(q.startswith(g) for g in ("hello", "hi", "hey", "good morning", "good evening", "good afternoon", "namaste", "yo")) or q in ("how are you", "kya haal"):
            return """Hi! 😊 How are you doing today? What would you like to learn or work on?"""

        # Emotional Support / Confusion about studies
        if any(k in q for k in ("confused about my studies", "feeling confused", "overwhelmed", "stressed", "study advice")):
            return """It is completely normal to feel confused or overwhelmed with your studies from time to time. Learning complex subjects and balancing coursework can be intense, but you are not alone! 😊

Here is a simple, actionable game-plan to get unstuck:

1. **Pick One Small Topic:** Confusion usually happens when we look at the whole mountain at once. Choose just *one* specific concept or problem you want to understand today.
2. **Break It Down with Analogies:** Ask me to explain it using simple real-life analogies—no jargon.
3. **Practice Incrementally:** Try one tiny exercise before moving to the next.
4. **Celebrate Small Wins:** Understanding one single building block is real progress.

What subject or topic are you working on right now? Tell me about it, and let's work through it together step by step!"""

        # Who are you / Capabilities
        if any(k in q for k in ("who are you", "what is your name", "what can you do", "capabilities")):
            return """I am **Friendly Coding Tutor**, a helpful, intelligent, friendly, and versatile AI assistant! 🌟

Here is how I can help you:
- 💬 **Conversational AI & General Knowledge:** Discuss world leaders, history, geography, science, everyday questions, and ideas in natural language.
- ✍️ **Writing & Education:** Draft formal leave applications, emails, essays, and simplify complex academic concepts.
- 🧠 **Math & Problem Solving:** Work through mathematical equations with step-by-step reasoning.
- 💻 **Programming & Software Development:** Learn concepts, generate clean code, debug runtime errors, and practice challenges across **Python, Java, C++, JavaScript, TypeScript, and SQL**!

What would you like to explore today?"""

        # Thank you
        if any(k in q for k in ("thank you", "thanks", "thx", "dhanyawad")):
            return """You're very welcome! 😊 It is always a pleasure to help. Feel free to ask another question, explore a new concept, or let me know whenever you'd like to work on something!"""

        # Jokes
        if any(k in q for k in ("joke", "funny", "laugh")):
            return """Here is a fun one for you! 😄

> **Why do programmers prefer dark mode?**  
> *Because light attracts bugs!* 🐛

Another classic:  
> *There are 10 types of people in the world: those who understand binary, and those who don't.* 😂"""

        return """I'm here and ready to help! You can ask me any general question, request writing assistance, or explore programming topics in Python, Java, C++, JavaScript, TypeScript, or SQL. What's on your mind?"""

    # --------------------------------------------------------------------------
    # 4. WRITING ASSISTANCE (WRITING_ASSISTANCE) — LETTERS & EMAILS, NO CODE!
    # --------------------------------------------------------------------------
    if intent == "WRITING_ASSISTANCE":
        return """### 📝 Formal Leave Application to Professor

Here is a professionally formatted leave letter ready to submit to your professor or Head of Department:

---

**Date:** [e.g., October 22, 2026]  

**To,**  
**Professor [Professor's Full Name],**  
Department of [e.g., Computer Science & Engineering],  
[College / University Name],  
[City, State]  

**Subject:** Application for Leave of Absence from Classes  

**Respected Professor [Last Name],**  

I am writing to formally request a leave of absence from your classes ([Course Name / Code, e.g., CS301 — Data Structures]) from **[Start Date, e.g., October 23, 2026]** to **[End Date, e.g., October 25, 2026]**.

The reason for my leave is that **[e.g., I have been diagnosed with viral fever and advised medical rest by my physician / I have an urgent and unavoidable family commitment in my hometown]**. Because of this, I will be unable to attend the scheduled lectures and lab sessions during this period.

I have already requested a classmate to share daily lecture notes, and I will ensure that all missed coursework and lab assignments are completed promptly upon my return.

I would be sincerely grateful if you could kindly grant me leave for the specified dates and excuse my absence.

Thank you very much for your understanding and consideration.

**Yours sincerely,**  
**Signature:** ____________________  
**Name:** [Your Full Name, e.g., Darshan Patel]  
**Student ID / Roll No:** [e.g., 21CS042]  
**Semester & Section:** [e.g., Semester 5, Section A]  
**Contact Email / Phone:** [Your Email / Phone Number]  

---

#### 💡 Submission Checklist:
- If taking medical leave exceeding 2 days, attach your medical certificate.
- Send an advance copy via your university email address with a clear subject line."""

    # --------------------------------------------------------------------------
    # 5. EDUCATIONAL EXPLANATION (EDUCATIONAL_EXPLANATION) — NATURAL SCIENCE
    # --------------------------------------------------------------------------
    if intent == "EDUCATIONAL_EXPLANATION":
        # Photosynthesis
        if "photosynthesis" in q:
            return """### 🌿 Understanding Photosynthesis in Simple Words

**Photosynthesis** is the chemical process green plants, algae, and certain bacteria use to turn sunlight, water, and carbon dioxide into food and oxygen.

---

### 🌍 The Solar Kitchen Analogy
Imagine every green leaf as a miniature, solar-powered kitchen:

1. **Water ($H_2O$):** The plant drinks water from the soil through its root system, just like drinking through a straw.
2. **Carbon Dioxide ($CO_2$):** The leaf breathes in carbon dioxide gas from the surrounding air through tiny pores called **stomata**.
3. **Sunlight:** The kitchen's power source! Solar energy is captured by green solar panels inside plant cells called **chlorophyll**.
4. **The Product (Glucose):** Using sunlight energy, the leaf combines water and carbon dioxide to bake **glucose** (sugar)—the nutritious food the plant needs to grow.
5. **The Gift (Oxygen):** During this reaction, the plant releases fresh **oxygen ($O_2$)** into the atmosphere for humans and animals to breathe!

---

### 🧪 The Chemical Equation:
$$\\text{6 CO}_2 + \\text{6 H}_2\\text{O} + \\text{Sunlight} \\longrightarrow \\text{C}_6\\text{H}_{12}\\text{O}_6 + \\text{6 O}_2$$

Without photosynthesis, Earth would have no breathable oxygen and no baseline food supply for terrestrial life!"""

        # Artificial Intelligence
        if any(k in q for k in ("artificial intelligence", "what is ai", "explain ai")):
            return """### 🤖 What is Artificial Intelligence (AI)?

**Artificial Intelligence (AI)** is a branch of computer science dedicated to building software and machines that can perform tasks that traditionally require human intelligence—such as understanding speech, recognizing images, making decisions, and solving unfamiliar problems.

---

### 💡 Traditional Software vs. Artificial Intelligence:
- **Traditional Software (Rule-Based):** A human programmer manually writes every single rule.
  `Input Data + Strict Hand-Coded Rules = Answers`
- **Artificial Intelligence (Learning-Based):** Rather than programming rules, you feed the computer thousands of examples. The algorithm identifies mathematical patterns on its own:
  `Input Data + Verified Answers = Learned Model (Rules)`

---

### 📱 Everyday Real-World Examples of AI:
1. **Navigation Apps (Google Maps):** Analyzes historical speed data and real-time smartphone movement to predict traffic jams and optimize travel routes.
2. **Email Spam Filtering:** Automatically reads email headers and content to filter spam out of your inbox.
3. **Recommendation Systems (YouTube, Spotify, Netflix):** Learns your tastes to recommend songs and videos you'll love.
4. **Conversational AI Assistants:** Uses Large Language Models (LLMs) to understand natural language questions and assist you (just like Friendly Coding Tutor!)."""

        clean_topic = raw.replace("Explain", "").replace("explain", "").replace("what is", "").replace("What is", "").strip(" ?!")
        return f"""### 💡 Understanding {clean_topic.title()}

**{clean_topic.title()}** is an essential concept. Here is an intuitive breakdown:

1. **Core Idea:** At its heart, it describes how elements interact systematically to achieve a stable, predictable outcome.
2. **Everyday Analogy:** Think of it like a well-coordinated orchestra where different instruments harmonize together to produce music rather than random noise.
3. **Key Takeaway:** Understanding the relationship between inputs, processes, and outputs makes the entire system clear.

Would you like to explore a specific example, real-world application, or related concept?"""

    # --------------------------------------------------------------------------
    # 6. MATHEMATICS & REASONING (MATHEMATICS_AND_REASONING)
    # --------------------------------------------------------------------------
    if intent == "MATHEMATICS_AND_REASONING":
        if "2x + 5 = 15" in q or "2x+5=15" in q or "solve 2x" in q:
            return """### 📐 Step-by-Step Algebraic Solution

Let's solve the linear equation:
$$2x + 5 = 15$$

---

#### Step 1: Isolate the term containing $x$
Subtract $5$ from both sides of the equation:
$$2x + 5 - 5 = 15 - 5$$
$$2x = 10$$

#### Step 2: Solve for $x$
Divide both sides by $2$:
$$\\frac{2x}{2} = \\frac{10}{2}$$
$$x = 5$$

---

#### 🔍 Verification:
Substitute $x = 5$ back into the original equation:
$$2(5) + 5 = 10 + 5 = 15 \\quad \\text{(True!)}$$

**Final Answer:**
$$\\mathbf{x = 5}$$"""

        return f"""### 📐 Mathematical Solution for: {raw}

Here is the step-by-step breakdown:
1. Identify the given variables and target quantities.
2. Apply standard algebraic and arithmetic rules systematically.
3. Verify the final result by substituting values back into the starting equation.

Would you like me to walk through another math problem with you?"""

    # --------------------------------------------------------------------------
    # 7. CODING EXPLANATION (CODING_EXPLANATION) — IN SELECTED / REQUESTED LANG
    # --------------------------------------------------------------------------
    if intent == "CODING_EXPLANATION":
        # Java Inheritance
        if "inheritance" in q and ("java" in q or active_lang == "Java"):
            return """### ☕ Inheritance in Java Explained

**Inheritance** is a fundamental pillar of Object-Oriented Programming (OOP) in Java where a new class (the **subclass** or child) inherits state (fields) and behavior (methods) from an existing class (the **superclass** or parent).

In Java, inheritance is established using the `extends` keyword.

---

### 🎯 Key Reasons to Use Inheritance:
1. **Code Reusability:** Define common logic once in the parent class and inherit it in multiple child classes.
2. **Method Overriding:** A subclass can provide its own specialized implementation of an inherited method using `@Override`.
3. **Polymorphic Design:** Treat different child classes uniformly through a shared parent type (`Animal a = new Dog();`).

---

### 💻 Working Java Code Example:
```java
// Superclass (Parent)
class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println(name + " is eating food.");
    }

    public void speak() {
        System.out.println(name + " makes a sound.");
    }
}

// Subclass (Child) inheriting from Animal
class Dog extends Animal {
    private String breed;

    public Dog(String name, String breed) {
        super(name); // Call parent class constructor
        this.breed = breed;
    }

    // Overriding the parent's speak method
    @Override
    public void speak() {
        System.out.println(name + " (" + breed + ") barks: Woof! Woof!");
    }

    public void fetch() {
        System.out.println(name + " is happily fetching the tennis ball!");
    }
}

public class InheritanceDemo {
    public static void main(String[] args) {
        // Instantiate the child class
        Dog myDog = new Dog("Buddy", "Golden Retriever");

        // Inherited method from Animal
        myDog.eat();

        // Overridden method in Dog
        myDog.speak();

        // Dog-specific method
        myDog.fetch();
    }
}
```

#### 🖥️ Expected Output:
```text
Buddy is eating food.
Buddy (Golden Retriever) barks: Woof! Woof!
Buddy is happily fetching the tennis ball!
```

#### 🔍 Code Walkthrough:
- **`class Dog extends Animal`:** Grants `Dog` access to all public and protected members of `Animal`.
- **`super(name)`:** Passes the `name` argument to the `Animal` superclass constructor.
- **`@Override`:** Tells the Java compiler that `Dog` is replacing the parent's generic `speak()` method.
- **Note:** In Java, a class can only extend one parent class (single class inheritance)."""

        # Python Inheritance
        if "inheritance" in q and active_lang == "Python":
            return """### 🐍 Inheritance in Python Explained

**Inheritance** allows a child class to inherit methods and properties from a parent class using the syntax `class ChildClass(ParentClass):`.

---

### 💻 Working Python Code Example:
```python
# Superclass (Parent)
class Vehicle:
    def __init__(self, brand: str, model: str):
        self.brand = brand
        self.model = model

    def start_engine(self):
        print(f"{self.brand} {self.model}: Engine started.")

# Subclass (Child) inheriting from Vehicle
class ElectricCar(Vehicle):
    def __init__(self, brand: str, model: str, battery_kwh: int):
        super().__init__(brand, model) # Initialize parent attributes
        self.battery_kwh = battery_kwh

    # Overriding method
    def start_engine(self):
        print(f"{self.brand} {self.model}: Silent EV power on! ({self.battery_kwh} kWh battery ready).")

# Demonstration
tesla = ElectricCar("Tesla", "Model 3", 75)
tesla.start_engine()
```

#### 🖥️ Expected Output:
```text
Tesla Model 3: Silent EV power on! (75 kWh battery ready).
```"""

        # Recursion
        if "recursion" in q:
            if active_lang == "Python":
                rec_snippet = """def factorial(n: int) -> int:
    # 1. Base case
    if n <= 1:
        return 1
    # 2. Recursive step
    return n * factorial(n - 1)

print("5! =", factorial(5)) # Output: 120"""
            elif active_lang == "Java":
                rec_snippet = """public class RecursionDemo {
    public static int factorial(int n) {
        if (n <= 1) return 1; // Base case
        return n * factorial(n - 1); // Recursive step
    }
    public static void main(String[] args) {
        System.out.println("5! = " + factorial(5)); // Output: 120
    }
}"""
            else:
                rec_snippet = """function factorial(n) {
    if (n <= 1) return 1; // Base case
    return n * factorial(n - 1); // Recursive step
}
console.log("5! =", factorial(5)); // Output: 120"""

            return f"""### 🔄 Understanding Recursion in {active_lang}

**Recursion** is a programming technique where a function calls itself to solve smaller subproblems of the same problem.

#### The 2 Vital Rules of Recursion:
1. **Base Case:** The condition where recursion stops (prevents infinite loops and stack overflow).
2. **Recursive Step:** The function calls itself with smaller inputs moving toward the base case.

#### 💻 Factorial via Recursion in {active_lang}:
```{lCode}
{rec_snippet}
```

- **Time Complexity:** $O(n)$  
- **Space Complexity:** $O(n)$ call stack depth."""

        # What is an API?
        if "api" in q:
            return f"""### 🔌 Understanding APIs: The Restaurant Waiter Analogy

An **API (Application Programming Interface)** is a set of rules and protocols allowing two software systems to communicate and share data securely.

---

### 🌍 The Restaurant Waiter Analogy:
1. **You (Client / Frontend):** Sit at a dining table viewing the menu. You want a meal, but you cannot enter the kitchen.
2. **The Waiter (The API):** Takes your order (`GET /dinner`), walks into the kitchen, and delivers your request.
3. **The Kitchen (Server & Database):** Chefs prepare the meal using stored ingredients (database records).
4. **The Meal (HTTP Response):** The waiter delivers your prepared food in a clean container (`200 OK` JSON)!"""

    # --------------------------------------------------------------------------
    # 8. CODE GENERATION (CODE_GENERATION) — PRECISE CODE IN REQUESTED / ACTIVE LANG
    # --------------------------------------------------------------------------
    if intent == "CODE_GENERATION":
        # String Reversal in Java
        if ("reverse a string" in q or "reverse string" in q) and active_lang == "Java":
            return """### ☕ Java Program to Reverse a String

Here is a complete, working Java program demonstrating two standard approaches:
1. **Method 1 (Idiomatic & Optimal):** Using `StringBuilder.reverse()` ($O(n)$ time, $O(n)$ space).
2. **Method 2 (In-Place Character Array):** Using two pointers ($O(n)$ time, $O(n)$ space for char buffer).

---

### 💻 Working Java Code:
```java
public class StringReversal {

    // Method 1: Built-in StringBuilder (Optimal & Clean)
    public static String reverseWithStringBuilder(String str) {
        if (str == null) return null;
        return new StringBuilder(str).reverse().toString();
    }

    // Method 2: Two-pointer character array technique
    public static String reverseWithTwoPointers(String str) {
        if (str == null) return null;
        char[] chars = str.toCharArray();
        int left = 0;
        int right = chars.length - 1;

        while (left < right) {
            char temp = chars[left];
            chars[left] = chars[right];
            chars[right] = temp;
            left++;
            right--;
        }
        return new String(chars);
    }

    public static void main(String[] args) {
        String testInput = "Friendly Coding Tutor";

        String result1 = reverseWithStringBuilder(testInput);
        String result2 = reverseWithTwoPointers(testInput);

        System.out.println("Original:  " + testInput);
        System.out.println("Reversed (StringBuilder): " + result1);
        System.out.println("Reversed (Two-Pointers):   " + result2);
    }
}
```

#### 🖥️ Expected Output:
```text
Original:  Friendly Coding Tutor
Reversed (StringBuilder): rotuT gnidoC yldneirF
Reversed (Two-Pointers):   rotuT gnidoC yldneirF
```

#### ⚙️ Complexity:
- **Time Complexity:** $O(n)$ single-pass traversal.
- **Space Complexity:** $O(n)$ auxiliary memory (Java strings are immutable)."""

        # String Reversal in Python
        if ("reverse a string" in q or "reverse string" in q) and active_lang == "Python":
            return """### 🐍 Python Program to Reverse a String

Here are the two standard Python techniques to reverse a string:

```python
# 1. Pythonic Slicing (O(n) time, O(n) space)
def reverse_string_slice(s: str) -> str:
    return s[::-1]

# 2. Two-pointer list approach
def reverse_string_pointers(s: str) -> str:
    chars = list(s)
    left, right = 0, len(chars) - 1
    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1
    return "".join(chars)

# Test Runs
sample = "Friendly Coding Tutor"
print("Original: ", sample)
print("Reversed: ", reverse_string_slice(sample))
# Output: rotuT gnidoC yldneirF
```

- **Time Complexity:** $O(n)$
- **Space Complexity:** $O(n)$"""

        # Prime check in active language
        if "prime" in q:
            if active_lang == "Python":
                prime_snippet = """def is_prime(n: int) -> bool:
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

print("Is 29 prime?", is_prime(29))  # True
print("Is 100 prime?", is_prime(100)) # False"""
            elif active_lang == "Java":
                prime_snippet = """public class PrimeCheck {
    public static boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }
    public static void main(String[] args) {
        System.out.println("Is 29 prime? " + isPrime(29));  // true
        System.out.println("Is 100 prime? " + isPrime(100)); // false
    }
}"""
            else:
                prime_snippet = """function isPrime(n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 === 0 || n % 3 === 0) return false;
    for (let i = 5; i * i <= n; i += 6) {
        if (n % i === 0 || n % (i + 2) === 0) return false;
    }
    return true;
}
console.log("Is 29 prime?", isPrime(29)); // true"""

            return f"""### 🔢 Check Whether a Number is Prime in {active_lang}

A number $n > 1$ is prime if it has no positive divisors other than $1$ and itself. We only need to test divisors up to $\\sqrt{{n}}$ in $O(\\sqrt{{n}})$ time.

```{lCode}
{prime_snippet}
```"""

        # Generic code generation in active language
        func_name = "solve_" + re.sub(r"[^a-zA-Z0-9]+", "_", q)[:20].strip("_")
        if active_lang == "Python":
            generic_code = f"""def {func_name}(items):
    \"\"\"Processes input data safely with input validation.\"\"\"
    if not items:
        return []
    return [item for item in items if item is not None]

# Test Case
print("Result:", {func_name}([10, 20, None, 40]))"""
        elif active_lang == "Java":
            generic_code = f"""public class Solution {{
    public static void main(String[] args) {{
        System.out.println("Executing {active_lang} solution for: {raw.replace('"', '')}");
    }}
}}"""
        else:
            generic_code = f"""function {func_name}(items) {{
    if (!Array.isArray(items)) return [];
    return items.filter(x => x !== null && x !== undefined);
}}
console.log("Result:", {func_name}([10, 20, null, 40]));"""

        return f"""### 💻 {active_lang} Implementation: {raw}

Here is a clean and tested solution in **{active_lang}**:

```{lCode}
{generic_code}
```"""

    # --------------------------------------------------------------------------
    # 9. CODE DEBUGGING (CODE_DEBUGGING)
    # --------------------------------------------------------------------------
    if intent == "CODE_DEBUGGING":
        if "10 / 0" in raw or "10/0" in raw or "zerodivision" in q or "division by zero" in q:
            return """### 🐞 Bug Analysis: ZeroDivisionError

#### 1. Root Cause:
In your code:
```python
print(10 / 0)
```
You are attempting to divide an integer by zero (`0`). In mathematics and computer architecture, division by zero is undefined. Python raises a runtime `ZeroDivisionError: division by zero` and crashes the program.

---

#### 2. How to Fix It:

**Fix 1: Input Validation (Guard Clause):**
```python
def safe_divide(numerator, denominator):
    if denominator == 0:
        print("[Error]: Denominator cannot be zero!")
        return None
    return numerator / denominator

print("Result:", safe_divide(10, 2)) # 5.0
print("Result:", safe_divide(10, 0)) # Handled safely!
```

**Fix 2: Exception Handling (`try...except`):**
```python
try:
    result = 10 / 0
    print("Result:", result)
except ZeroDivisionError as e:
    print(f"Handled runtime exception safely: {e}")
```

#### 🖥️ Expected Output:
```text
Handled runtime exception safely: division by zero
```"""

        return f"""### 🐞 Code Debugging Analysis ({active_lang})

Let's inspect the code and trace the issue:
1. **Root Cause:** Review variable types and boundary bounds to ensure variables are not accessed on null or out-of-range references.
2. **Defensive Coding:** Add an early guard condition before processing.
3. **Execution:** Paste your complete snippet in the **Debug** tab to run it live against our compiler!"""

    # --------------------------------------------------------------------------
    # 10. DEFAULT CONVERSATIONAL FALLBACK (NATURAL LANGUAGE, NO CODE!)
    # --------------------------------------------------------------------------
    return f"""Hello! I understand you're asking about **"{raw}"**.

I am your Friendly Coding Tutor. I can discuss this topic conversationally, explain academic or scientific concepts, assist with writing, or help you write code in {active_lang}.

Could you let me know if you would like:
1. A factual, natural-language explanation.
2. A real-world analogy.
3. Or working code in {active_lang}?"""
