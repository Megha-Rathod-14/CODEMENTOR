-- ============================================================================
-- CodeMentor AI - Database Schema (SQL)
-- Compatible with SQLite, PostgreSQL, and MySQL
-- Default User: Megha@143 (password: 123456)
-- ============================================================================

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150),
    role VARCHAR(20) DEFAULT 'student',
    plan VARCHAR(50) DEFAULT 'student plan',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Conversations Table
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    concept_language VARCHAR(50) DEFAULT 'Python',
    mode VARCHAR(50) DEFAULT 'Chat',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 3. Messages Table
CREATE TABLE IF NOT EXISTS messages (
    message_id VARCHAR(50) PRIMARY KEY,
    conversation_id VARCHAR(50) NOT NULL,
    sender VARCHAR(20) NOT NULL CHECK (sender IN ('user', 'assistant')),
    content TEXT NOT NULL,
    code_snippet TEXT,
    language VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE
);

-- 4. Search and Query History Table (Requested History in Settings)
CREATE TABLE IF NOT EXISTS search_history (
    history_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    query_text TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    concept_language VARCHAR(50) DEFAULT 'Python',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 5. Practice Questions & Code Submissions Table
CREATE TABLE IF NOT EXISTS practice_submissions (
    submission_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    question_title VARCHAR(255) NOT NULL,
    concept_language VARCHAR(50) NOT NULL,
    submitted_code TEXT NOT NULL,
    score INT NOT NULL CHECK (score >= 0 AND score <= 100),
    rating VARCHAR(20) NOT NULL,
    feedback TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 6. Weekly Performance & Progress Table (Matches Image 2)
CREATE TABLE IF NOT EXISTS weekly_performance (
    stat_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    problems_solved INT DEFAULT 42,
    problems_this_week INT DEFAULT 8,
    lessons_done INT DEFAULT 18,
    lessons_in_progress INT DEFAULT 3,
    current_streak_days INT DEFAULT 7,
    accuracy_percentage INT DEFAULT 84,
    accuracy_delta INT DEFAULT 6,
    total_focus_minutes INT DEFAULT 272, -- 4h 32m
    week_start_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 7. Skill Map Table (Matches Image 2 Progress)
CREATE TABLE IF NOT EXISTS skill_map (
    skill_id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    skill_name VARCHAR(50) NOT NULL,
    proficiency_percentage INT NOT NULL CHECK (proficiency_percentage >= 0 AND proficiency_percentage <= 100),
    color_hex VARCHAR(20) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================================================
-- SEED DATA FOR USER & ADMIN SIDES
-- User: darshan@123 (password: 456789)
-- Admin: megha@1409 (password: 123456)
-- Legacy User: Megha@143 (password: 123456)
-- ============================================================================

INSERT INTO users (user_id, username, password_hash, full_name, role, plan)
VALUES 
    ('usr_darshan_001', 'darshan@123', '456789', 'Darshan Patel', 'student', 'student plan'),
    ('usr_admin_001', 'megha@1409', '123456', 'Megha (Admin)', 'admin', 'administrator'),
    ('usr_megha_001', 'Megha@143', '123456', 'Megha Sharma', 'student', 'student plan')
ON CONFLICT(username) DO NOTHING;

-- Initial Search History Records for Darshan
INSERT INTO search_history (history_id, user_id, query_text, category, concept_language)
VALUES 
    ('sh_d01', 'usr_darshan_001', 'Explain recursion vs iteration with diagrams', 'Concept Explanation', 'Python'),
    ('sh_d02', 'usr_darshan_001', 'Fix index out of range error in list iteration', 'Code Debugging', 'Python'),
    ('sh_d03', 'usr_darshan_001', 'Write a two-pointer algorithm in JavaScript', 'Learn with Example', 'JavaScript'),
    ('sh_d04', 'usr_darshan_001', 'Explain SQL inner join vs left join with examples', 'Concept Explanation', 'SQL')
ON CONFLICT(history_id) DO NOTHING;

-- Initial Weekly Performance for Darshan
INSERT INTO weekly_performance (stat_id, user_id, problems_solved, problems_this_week, lessons_done, lessons_in_progress, current_streak_days, accuracy_percentage, accuracy_delta, total_focus_minutes, week_start_date)
VALUES ('wp_d01', 'usr_darshan_001', 42, 8, 18, 3, 7, 84, 6, 272, '2026-06-10')
ON CONFLICT(stat_id) DO NOTHING;

-- Initial Skill Map for Darshan
INSERT INTO skill_map (skill_id, user_id, skill_name, proficiency_percentage, color_hex)
VALUES 
    ('sk_d01', 'usr_darshan_001', 'Python', 90, '#6c5ce7'),
    ('sk_d02', 'usr_darshan_001', 'Java', 70, '#f39c12'),
    ('sk_d03', 'usr_darshan_001', 'SQL', 80, '#2ecc71'),
    ('sk_d04', 'usr_darshan_001', 'DSA', 50, '#e84393')
ON CONFLICT(skill_id) DO NOTHING;
