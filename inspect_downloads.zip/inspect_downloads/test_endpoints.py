import urllib.request
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

def run_tests():
    print("--- 1. Testing GET /api/status ---")
    with urllib.request.urlopen("http://localhost:5000/api/status") as r:
        data = json.loads(r.read().decode("utf-8"))
        print("Status 200 OK. Compilers:", data.get("compilers"))

    print("\n--- 2. Testing SPA Clean URL /explain-concept ---")
    with urllib.request.urlopen("http://localhost:5000/explain-concept") as r:
        html = r.read().decode("utf-8")
        print(f"HTTP {r.status}, Title present: {'Friendly Coding Tutor' in html}, View present: {'view-explain' in html}")

    print("\n--- 3. Testing POST /api/explain ---")
    req = urllib.request.Request(
        "http://localhost:5000/api/explain",
        data=json.dumps({"topic": "Inheritance in Python", "language": "Python", "level": "Intermediate"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Explain status: {res.get('status')}, Engine: {res.get('engine')}, Has code: {bool(res.get('extractedCode'))}")
        lines = res.get("explanation", "").split("\n")
        print("Preview:", lines[0] if lines else "")

    print("\n--- 4. Testing POST /api/example ---")
    req = urllib.request.Request(
        "http://localhost:5000/api/example",
        data=json.dumps({"topic": "Arrays in Python", "language": "Python", "level": "Beginner"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Example status: {res.get('status')}, Engine: {res.get('engine')}, Has code: {bool(res.get('extractedCode'))}")

    print("\n--- 5. Testing POST /api/execute (Python) ---")
    req = urllib.request.Request(
        "http://localhost:5000/api/execute",
        data=json.dumps({"code": "print('Native Python Output: 42')", "lang": "Python"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Python execution: stdout='{res.get('stdout', '').strip()}', stderr='{res.get('stderr', '').strip()}'")

    print("\n--- 6. Testing POST /api/execute (Java) ---")
    java_code = "public class Solution { public static void main(String[] args) { System.out.println(\"Java 25 Native Output: SUCCESS\"); } }"
    req = urllib.request.Request(
        "http://localhost:5000/api/execute",
        data=json.dumps({"code": java_code, "lang": "Java"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Java execution: stdout='{res.get('stdout', '').strip()}', stderr='{res.get('stderr', '').strip()}'")

    print("\n--- 7. Testing POST /api/debug-ai ---")
    buggy_code = "def divide(a, b):\n    return a / b\nprint(divide(10, 0))"
    req = urllib.request.Request(
        "http://localhost:5000/api/debug-ai",
        data=json.dumps({"code": buggy_code, "lang": "Python", "errorOutput": "ZeroDivisionError: division by zero"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Debug AI status: {res.get('status')}, Fixed code present: {bool(res.get('fixedCode'))}")

    print("\n--- 8. Testing POST /api/practice/grade ---")
    sol = "def two_sum(nums, target):\n    return [0, 1]"
    req = urllib.request.Request(
        "http://localhost:5000/api/practice/grade",
        data=json.dumps({
            "language": "Python",
            "code": sol,
            "testCases": [{"input": [[2, 7, 11, 15], 9], "expected": [0, 1]}],
            "problemTitle": "Two Sum"
        }).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        res = json.loads(r.read().decode("utf-8"))
        print(f"Practice Grade: score={res.get('score')}, passed={res.get('passed')}, passedTests={res.get('passedTests')}")

    print("\n=== ALL ENDPOINTS VERIFIED SUCCESSFULLY ===")

if __name__ == "__main__":
    run_tests()
